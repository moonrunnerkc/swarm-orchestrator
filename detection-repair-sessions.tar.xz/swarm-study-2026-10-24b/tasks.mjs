// The development set's exposed tasks, re-exported unchanged from their published modules.
import { tasks as block1 } from "/Users/brad/.cache/swarm-heldout-2026-10-22/sealed/heldout-tasks.mjs";
import { tasks as block2 } from "/Users/brad/.cache/swarm-heldout-2026-10-23/sealed/heldout-tasks.mjs";
import { tasks as block3 } from "/Users/brad/.cache/swarm-heldout-2026-10-23c/sealed/heldout-tasks.mjs";

const ids = [
  "ufo-feature-filter-query",
  "ufo-bugfix-base-prefix-boundary",
  "p-limit-bugfix-limit-function-clear-queue",
  "svgo-bugfix-remove-scripts-anchor-bypass",
];
export const tasks = [...block1, ...block2, ...block3].filter((task) => ids.includes(task.id));
