#!/usr/bin/env node

// Re-derivation for swarm-orchestrator evidence bundles.
//
// verify.mjs checks that a bundle is what it says it is. This script asks a harder question of
// the same bytes: would a third party, applying the rules this tool applies, reach the verdicts
// the bundle records? Every gate status is recomputed from the recorded exit code and output
// under the parser rule the record names; every ratchet decision is recomputed from the
// measures it recorded on each side; every bond verdict from its observation; every claim from
// its predicate and the record it cites; and the gate runs are held to the criteria sealed
// before the loop. Where a rule cannot be applied from the bundle alone, an inspection's own
// findings for one, or an output the record truncated, it says so by name rather than agreeing.
//
// Dependency-free, importing only node: builtins and verify.mjs beside it.
//
//   node rederive.mjs <bundle directory>
//
// Exit 0: every verdict that could be re-derived agrees with the recorded one. Exit 1: at
// least one disagrees, named. Verdicts that could not be re-derived are listed and do not
// decide the exit code, since an absence of re-derivation is not a disagreement.

import { createHash } from "node:crypto";

function sortedJson(value) {
  return JSON.stringify(value, (_key, inner) =>
    inner !== null && typeof inner === "object" && !Array.isArray(inner)
      ? Object.fromEntries(Object.entries(inner).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)))
      : inner,
  );
}

/**
 * What makes a recorded instrument untrusted (instrument-identity-v1). Mirrors
 * `instrumentChanges` in src/gates/instrument-identity.ts, written again here so the decision a
 * record carries is re-derived from the digests it recorded rather than taken from the run. The
 * closure itself was followed by the harness; this checks what follows from what it recorded.
 */
function instrumentChanges(instrument) {
  if (
    instrument === null ||
    typeof instrument !== "object" ||
    instrument.rule !== "instrument-identity-v1"
  )
    return ["instrument record under an unknown rule"];
  const changed = [];
  for (const file of instrument.files ?? [])
    if (file.reference !== file.current) changed.push(file.path);
  for (const dependency of instrument.dependencies ?? [])
    if (
      dependency.reference !== dependency.current &&
      dependency.currentSource !== "registry" &&
      dependency.currentSource !== "absent"
    )
      changed.push(`dependency ${dependency.name}`);
  for (const runner of instrument.installed ?? []) {
    if (runner.found === null) continue;
    if (runner.expected !== null && runner.found !== runner.expected)
      changed.push(`installed ${runner.name} ${runner.found} (lockfile ${runner.expected})`);
    if (!runner.linked) changed.push(`installed ${runner.name} executable link`);
  }
  if (instrument.complete !== true) changed.push("instrument closure not followed to its end");
  if (instrument.before !== undefined) {
    const { before: _before, ...rest } = instrument;
    const now = `sha256:${createHash("sha256").update(sortedJson(rest)).digest("hex")}`;
    if (now !== instrument.before) changed.push("the instrument changed while the check ran");
  }
  return changed;
}

function notApplicable(observation) {
  if (observation.unavailable !== null && observation.unavailable !== undefined)
    return "not-applicable";
  if (observation.exitCode === 127) return "not-applicable";
  return null;
}

function counter(text, name) {
  // nosemgrep: javascript.lang.security.audit.detect-non-literal-regexp.detect-non-literal-regexp - name is one of the counter names this file calls with, never input. Mirrors src/gates/parsers.ts.
  const found = new RegExp(`^[#ℹ]\\s+${name}\\s+(\\d+)\\s*$`, "m").exec(text)?.[1];
  return found === undefined ? null : Number(found);
}

/**
 * The status the named parser rule reads out of an observation. Mirrors src/gates/parsers.ts
 * and src/gates/default-gates.ts, rule for rule; the parity test in that tree holds the two
 * to each other.
 */
function readStatus(parser, observation) {
  const status = readParsedStatus(parser, observation);
  // A pass reported under an instrument the change altered is the project's report, not evidence.
  if (
    status === "passed" &&
    observation.instrument !== undefined &&
    instrumentChanges(observation.instrument).length > 0
  )
    return "not-applicable";
  return status;
}

function readParsedStatus(parser, observation) {
  const unavailable = notApplicable(observation);
  if (unavailable !== null) return unavailable;
  const stdout = observation.stdout ?? "";
  const stderr = observation.stderr ?? "";
  switch (parser) {
    case "exit-code":
      return observation.exitCode === 0 ? "passed" : "failed";
    case "no-output":
      if (observation.exitCode !== 0) return "failed";
      return stdout.trim().length === 0 ? "passed" : "failed";
    case "inspection":
      try {
        JSON.parse(stdout);
      } catch {
        return "failed";
      }
      return observation.exitCode === 0 ? "passed" : "failed";
    case "structured-test-output":
      return structuredTestStatus(observation);
    case "test-output": {
      if (stdout.trimStart().startsWith("{")) return structuredTestStatus(observation);
      const text = `${stdout}\n${stderr}`;
      if (/^TAP version \d+/m.test(text) || counter(text, "tests") !== null) {
        const plan = /^\s*1\.\.(\d+)\s*$/m.exec(text)?.[1];
        const tests = counter(text, "tests") ?? (plan === undefined ? null : Number(plan));
        const fail = counter(text, "fail");
        const failed = observation.exitCode !== 0 || (fail ?? 0) > 0;
        const pass = counter(text, "pass");
        const executed =
          pass ??
          (tests === null
            ? null
            : tests - (counter(text, "skipped") ?? 0) - (counter(text, "todo") ?? 0));
        if (!failed && (tests === 0 || executed === 0)) return "not-applicable";
        return failed ? "failed" : "passed";
      }
      const summary = /^\s*Tests\s+(.+?)\s*$/m.exec(text)?.[1] ?? "";
      if (/\(\d+\)/.test(summary)) {
        const failedCount = /(\d+)\s+failed/.exec(summary)?.[1];
        const failed = observation.exitCode !== 0 || Number(failedCount ?? 0) > 0;
        return failed ? "failed" : "passed";
      }
      return observation.exitCode === 0 ? "passed" : "failed";
    }
    default:
      return null;
  }
}

/**
 * The per-test outcomes of a structured report, or null where it is not a complete one. A title
 * repeated in one file is named by its occurrence, as src/gates/runner-results.ts names it.
 */
function structuredPoints(observation) {
  if (observation.outputTruncated || (observation.stdout ?? "").length > 4000000) return null;
  try {
    const report = JSON.parse(observation.stdout);
    let tests;
    if (report.schema === "swarm.pytest.v1") {
      if (!Array.isArray(report.tests) || report.tests.length > 100000) return null;
      tests = report.tests.map((test) => ({
        id: test.id,
        status: test.status,
        identity: test.id,
        cause: typeof test.message === "string" ? test.message : "",
      }));
    } else {
      for (const field of ["numTotalTests", "numPassedTests", "numFailedTests", "numPendingTests"])
        if (!Number.isInteger(report[field]) || report[field] < 0) return null;
      tests = report.testResults.flatMap((file) => {
        if (typeof file.name !== "string") throw new Error("file absent");
        const seen = new Map();
        return file.assertionResults.map((test) => {
          if (
            typeof test.fullName !== "string" ||
            !["passed", "failed", "pending", "skipped", "todo"].includes(test.status)
          )
            throw new Error("invalid point");
          const count = (seen.get(test.fullName) ?? 0) + 1;
          seen.set(test.fullName, count);
          return {
            id: `${file.name}:${test.fullName}${count === 1 ? "" : `#${count}`}`,
            identity: `${file.name}:${test.fullName}`,
            cause: Array.isArray(test.failureMessages) ? test.failureMessages.join("\n") : "",
            status: ["passed", "failed"].includes(test.status) ? test.status : "skipped",
          };
        });
      });
      if (
        report.numTotalTests !== tests.length ||
        report.numPassedTests !== tests.filter((test) => test.status === "passed").length ||
        report.numFailedTests !== tests.filter((test) => test.status === "failed").length ||
        report.numPendingTests !== tests.filter((test) => test.status === "skipped").length
      )
        return null;
    }
    if (
      tests.some(
        (test) =>
          typeof test.id !== "string" ||
          !test.id ||
          !["passed", "failed", "skipped", "error"].includes(test.status),
      ) ||
      new Set(tests.map((test) => test.id)).size !== tests.length
    )
      return null;
    return tests;
  } catch {
    return null;
  }
}

/** Structured results carry outcomes, never extra ratchet authority. */
function structuredTestStatus(observation) {
  const tests = structuredPoints(observation);
  if (tests === null)
    return observation.outputTruncated || (observation.stdout ?? "").length > 4000000
      ? "not-applicable"
      : observation.exitCode === 0
        ? "not-applicable"
        : "failed";
  const executed = tests.filter((test) => test.status !== "skipped");
  if (!executed.length) return "not-applicable";
  return observation.exitCode !== 0 || executed.some((test) => test.status !== "passed")
    ? "failed"
    : "passed";
}

/**
 * The tests a run names as failed and passed, under the title-only identity records were
 * attributed with through 1.0.7 (failure-identity v1). Kept so those records re-derive under the
 * rule that wrote them; it is not a rule new records are judged by, and an inheritance it proves
 * is not re-established by it (SV-24).
 */
function namedTestsV1(observation) {
  const stdout = observation.stdout ?? "";
  if (stdout.trimStart().startsWith("{")) {
    const points = structuredPoints(observation);
    if (points === null) return null;
    return {
      failed: points.filter((p) => p.status === "failed" || p.status === "error").map((p) => p.id),
      passed: points.filter((p) => p.status === "passed").map((p) => p.id),
    };
  }
  const text = `${stdout}\n${observation.stderr ?? ""}`;
  if (!/^TAP version \d+/m.test(text)) {
    const plain = stripColour(text);
    const summary = /^\s*Test Files\s+(.+)$/m.exec(plain)?.[1];
    if (summary === undefined) return null;
    const failed = [];
    for (const line of plain.split("\n")) {
      const named = /^\s*FAIL\s+(\S.*?)\s*$/.exec(line)?.[1];
      if (named && !failed.includes(named)) failed.push(named);
    }
    if (failed.length === 0 && /\d+\s+failed/.test(summary)) return null;
    return { failed, passed: [] };
  }
  const failed = [];
  const passed = [];
  for (const line of text.split("\n")) {
    const point = /^(\s*)(not ok|ok)\s+\d+\s+-\s+(.+?)\s*$/.exec(line);
    if (point === null) continue;
    if (/#\s*(TODO|SKIP)\b/i.test(point[3])) continue;
    const id = `${point[1].length}:${point[3].replace(/\s+#.*$/, "")}`;
    (point[2] === "ok" ? passed : failed).push(id);
  }
  return { failed, passed };
}

const escapeCharacter = String.fromCharCode(27);

function stripColour(text) {
  return text
    .split(escapeCharacter)
    .map((part, index) => (index === 0 ? part : part.replace(/^\[[0-9;]*[A-Za-z]/, "")))
    .join("");
}

function cause(text) {
  return stripColour(text)
    .replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?/g, "<timestamp>")
    .replace(/\b\d+(?:\.\d+)?\s?(?:ms|s|sec|secs|seconds)\b/g, "<duration>")
    .trim()
    .slice(0, 2000);
}

/** The directory every TAP failure location in the texts shares. */
function locationRoot(texts) {
  const files = [];
  for (const text of texts)
    for (const line of text.split("\n")) {
      const found = /^\s*location:\s*'([^']+)'\s*$/.exec(line)?.[1];
      if (found !== undefined) files.push(found.replace(/^file:\/\//, "").replace(/:\d+:\d+$/, ""));
    }
  if (files.length === 0) return "";
  let shared = files[0].split("/").slice(0, -1);
  for (const file of files.slice(1)) {
    const parts = file.split("/").slice(0, -1);
    let length = 0;
    while (length < shared.length && shared[length] === parts[length]) length++;
    shared = shared.slice(0, length);
  }
  return shared.length === 0 ? "" : `${shared.join("/")}/`;
}

const causeFields = ["failureType", "error", "code", "name", "expected", "actual", "operator"];

/** Node's TAP read under failure-identity v2: a failure named by its location, depth and title. */
function tapTests(text, truncated, root) {
  const lines = text.split("\n");
  const failed = [];
  const passed = [];
  const causes = {};
  let leafFailures = 0;
  for (let index = 0; index < lines.length; index++) {
    const point = /^(\s*)(not ok|ok)\s+\d+\s+-\s+(.+?)\s*$/.exec(lines[index]);
    if (point === null) continue;
    if (/#\s*(TODO|SKIP)\b/i.test(point[3])) continue;
    const depth = point[1].length;
    const title = point[3].replace(/\s+#.*$/, "");
    const yaml = [];
    if (/^\s*---\s*$/.test(lines[index + 1] ?? ""))
      for (
        let inner = index + 2;
        inner < lines.length && !/^\s*\.\.\.\s*$/.test(lines[inner]);
        inner++
      )
        yaml.push(lines[inner]);
    if (point[2] === "ok") {
      passed.push(`${depth}:${title}`);
      continue;
    }
    let location = null;
    let type = null;
    const kept = [];
    let block = null;
    // Keys sit two spaces inside the point; deeper lines belong to the key above them.
    const inner = " ".repeat(depth + 2);
    for (const line of yaml) {
      const key =
        line.startsWith(inner) && line[inner.length] !== " "
          ? /^(\w+):\s*(.*)$/.exec(line.slice(inner.length))
          : null;
      if (key !== null) block = key[1];
      const value = key === null ? null : key[2].replace(/^'(.*)'$/, "$1");
      if (key !== null && key[1] === "location" && location === null)
        location = value.replace(/^file:\/\//, "");
      if (key !== null && key[1] === "type" && type === null) type = value;
      if (block !== null && causeFields.includes(block)) kept.push(line.trim());
    }
    if (type !== "suite") leafFailures++;
    const relative =
      location !== null && root.length > 0 && location.startsWith(root)
        ? location.slice(root.length)
        : location;
    const id = relative === null ? `${depth}:${title}` : `${relative} › ${depth}:${title}`;
    failed.push(id);
    causes[id] = cause(kept.join("\n"));
  }
  const counter = (name) => {
    for (const line of lines) {
      const match = /^[#ℹ]\s+(\w+)\s+(\d+)\s*$/.exec(line);
      if (match !== null && match[1] === name) return Number(match[2]);
    }
    return null;
  };
  const fail = counter("fail");
  const complete =
    !truncated &&
    lines.some((line) => /^1\.\.\d+\s*$/.test(line)) &&
    (counter("cancelled") ?? 0) === 0 &&
    (fail === null || fail === leafFailures);
  return { failed, passed, causes, complete };
}

/** Node's spec reporter under failure-identity v2. Mirrors `specPoints` in failure-attribution.ts. */
function specTests(raw, truncated) {
  const lines = stripColour(raw).split("\n");
  const passed = [];
  const failed = [];
  const causes = {};
  const summary = lines.findIndex((line) => /^\u2716 failing tests:\s*$/.test(line));
  for (let index = 0; index < lines.length; index++) {
    if (summary !== -1 && index >= summary) break;
    const pass = /^(\s*)\u2714 (.+?) \(\d+(?:\.\d+)?ms\)\s*$/.exec(lines[index]);
    if (pass !== null) passed.push(`${pass[1].length}:${pass[2]}`);
  }
  if (summary !== -1)
    for (let index = summary + 1; index < lines.length; index++) {
      const location = /^test at (.+:\d+:\d+)\s*$/.exec(lines[index])?.[1];
      const title = /^\s*\u2716 (.+?) \(\d+(?:\.\d+)?ms\)\s*$/.exec(lines[index + 1] ?? "")?.[1];
      if (location === undefined || title === undefined) continue;
      const kept = [];
      for (let inner = index + 2; inner < lines.length; inner++) {
        if (/^test at /.test(lines[inner])) break;
        if (/^\s+at /.test(lines[inner]) || lines[inner].trim().length === 0) continue;
        kept.push(lines[inner].trim());
      }
      const id = `${location} \u203a 0:${title}`;
      failed.push(id);
      causes[id] = cause(kept.join("\n"));
    }
  const count = (name) => {
    for (const line of lines) {
      const match = /^\u2139\s+(\w+)\s+(\d+)\s*$/.exec(line);
      if (match !== null && match[1] === name) return Number(match[2]);
    }
    return null;
  };
  const fail = count("fail");
  return {
    failed,
    passed,
    causes,
    complete:
      !truncated && fail !== null && fail === failed.length && (count("cancelled") ?? 0) === 0,
  };
}

/** A run's tests under failure-identity v2, or null where it names none. */
function namedTestsV2(observation, sharedRoot) {
  const stdout = observation.stdout ?? "";
  const root = sharedRoot ?? locationRoot([`${stdout}\n${observation.stderr ?? ""}`]);
  if (stdout.trimStart().startsWith("{")) {
    const points = structuredPoints(observation);
    if (points === null) return null;
    const failing = points.filter((p) => p.status === "failed" || p.status === "error");
    const causes = {};
    for (const p of failing) causes[p.identity] = cause(p.cause ?? "");
    return {
      failed: failing.map((p) => p.identity),
      passed: points.filter((p) => p.status === "passed").map((p) => p.identity),
      causes,
      complete: true,
    };
  }
  const text = `${stdout}\n${observation.stderr ?? ""}`;
  if (/^TAP version \d+/m.test(text))
    return tapTests(text, observation.outputTruncated === true, root);
  if (/^\u2716 failing tests:\s*$/m.test(text) || /^\u2139\s+tests\s+\d+\s*$/m.test(text))
    return specTests(text, observation.outputTruncated === true);
  const plain = stripColour(text);
  const summary = /^\s*Test Files\s+(.+)$/m.exec(plain)?.[1];
  if (summary === undefined) return null;
  const lines = plain.split("\n");
  const failed = [];
  const causes = {};
  for (let index = 0; index < lines.length; index++) {
    const named = /^\s*FAIL\s+(\S.*?)\s*$/.exec(lines[index])?.[1];
    if (!named) continue;
    failed.push(named);
    const next = lines.slice(index + 1).find((line) => line.trim().length > 0) ?? "";
    causes[named] = /^\s*FAIL\s/.test(next) ? "" : cause(next);
  }
  if (failed.length === 0 && /\d+\s+failed/.test(summary)) return null;
  const counted = /(\d+)\s+failed/.exec(/^\s*Tests\s+(.+)$/m.exec(plain)?.[1] ?? "")?.[1];
  return {
    failed,
    passed: [],
    causes,
    complete: counted === undefined || Number(counted) <= failed.length,
  };
}

function comparableOutput(observation) {
  return stripColour(
    `${observation.exitCode}\n${observation.stdout ?? ""}\n${observation.stderr ?? ""}`,
  )
    .replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?/g, "<timestamp>")
    .replace(/\b\d{1,2}:\d{2}:\d{2}(?:\.\d+)?\b/g, "<clock>")
    .replace(/\b\d+(?:\.\d+)?\s?(?:ms|s|sec|secs|seconds|m|min)\b/g, "<duration>")
    .split("\n")
    .map((line) => line.replace(/\s+$/, ""))
    .join("\n");
}

/** Why a failed reading failed under v1: title identities, as sets. */
function attributionV1(failing, parser, baseObservation) {
  if (baseObservation === undefined || readStatus(parser, baseObservation) !== "failed")
    return { attribution: "new", newFailures: [] };
  const patched = namedTestsV1(failing);
  const base = namedTestsV1(baseObservation);
  if (patched !== null && base !== null && patched.failed.length > 0) {
    const newFailures = patched.failed.filter((id) => !base.failed.includes(id));
    return newFailures.length === 0
      ? { attribution: "inherited", newFailures: [] }
      : { attribution: "new", newFailures };
  }
  return comparableOutput(failing) === comparableOutput(baseObservation)
    ? { attribution: "inherited", newFailures: [] }
    : { attribution: "unattributed", newFailures: [] };
}

function tally(ids) {
  const found = new Map();
  for (const id of ids) found.set(id, (found.get(id) ?? 0) + 1);
  return found;
}

/**
 * Why a failed reading failed under failure-identity v2: identities that tell same-titled tests
 * apart, counted, with their causes, from two complete runs. Mirrors `attributeFailure` in
 * src/gates/failure-attribution.ts.
 */
function attributionV2(failing, parser, baseObservation) {
  if (baseObservation === undefined || readStatus(parser, baseObservation) !== "failed")
    return { attribution: "new", newFailures: [] };
  if (failing.outputTruncated === true || baseObservation.outputTruncated === true)
    return { attribution: "unattributed", newFailures: [] };
  const texts = [failing, baseObservation].map((one) => `${one.stdout ?? ""}\n${one.stderr ?? ""}`);
  const root = texts.every((text) => /^TAP version \d+/m.test(text)) ? locationRoot(texts) : "";
  const patched = namedTestsV2(failing, root);
  const base = namedTestsV2(baseObservation, root);
  if (patched !== null && base !== null && patched.failed.length > 0) {
    const before = tally(base.failed);
    const after = tally(patched.failed);
    const newFailures = [...after]
      .filter(([id, count]) => count > (before.get(id) ?? 0))
      .map(([id]) => id)
      .sort();
    if (newFailures.length > 0) return { attribution: "new", newFailures };
    const repeated = [...after, ...before].some(([, count]) => count > 1);
    const changed = [...after.keys()].some((id) => patched.causes[id] !== base.causes[id]);
    return patched.complete && base.complete && !repeated && !changed
      ? { attribution: "inherited", newFailures: [] }
      : { attribution: "unattributed", newFailures: [] };
  }
  if (patched !== null || base !== null) return { attribution: "unattributed", newFailures: [] };
  return comparableOutput(failing) === comparableOutput(baseObservation)
    ? { attribution: "inherited", newFailures: [] }
    : { attribution: "unattributed", newFailures: [] };
}

/** Why a failed reading failed, under the rule the record names. */
function attribution(check, failing) {
  return check.attributionRule === "failure-identity-v2"
    ? attributionV2(failing, check.parser, check.baseObservation)
    : attributionV1(failing, check.parser, check.baseObservation);
}

/**
 * The status a check must carry given its own, base-configuration, base-tests and base readings.
 * A pass whose base-written tests fail against the patch's source, in a way the base does not
 * fail, is withheld with those tests named. Mirrors `weakenedUnderBaseTests` in
 * src/gates/independent-verification.ts.
 */
function expectedStatus(check) {
  const decided = expectedStatusBeforeTests(check);
  if (decided === null) return null;
  if (check.baseTestsObservation === undefined) return { ...decided, weakened: [] };
  const within = (observation, instrument) =>
    instrument === undefined ? observation : { ...observation, instrument };
  const underTests = readStatus(
    check.parser,
    within(check.baseTestsObservation, check.baseTestsInstrument),
  );
  if (underTests !== check.baseTestsStatus) return null;
  if (decided.status !== "passed" || underTests !== "failed") return { ...decided, weakened: [] };
  const derived = attributionV2(check.baseTestsObservation, check.parser, check.baseObservation);
  if (derived.attribution === "inherited") return { ...decided, weakened: [] };
  const baseFailed =
    check.baseObservation !== undefined &&
    readStatus(check.parser, check.baseObservation) === "failed";
  const weakened = baseFailed
    ? derived.newFailures
    : [...new Set(namedTestsV2(check.baseTestsObservation)?.failed ?? [])].sort();
  return { status: "not-applicable", regressed: decided.regressed, weakened };
}

function expectedStatusBeforeTests(check) {
  const within = (observation, instrument) =>
    instrument === undefined ? observation : { ...observation, instrument };
  const reported = readStatus(check.parser, check.observation);
  const own = readStatus(check.parser, within(check.observation, check.instrument));
  // What the runner said is kept where the instrument rule withheld it, and must be what it said.
  if (own !== reported ? check.reportedStatus !== reported : check.reportedStatus !== undefined)
    return null;
  if (check.configurationObservation === undefined) return { status: own, regressed: [] };
  const underBase = readStatus(
    check.parser,
    within(check.configurationObservation, check.configurationInstrument),
  );
  if (underBase !== check.configurationStatus) return null;
  if (reported !== "passed") return { status: own, regressed: [] };
  // Measured again under the base's instrument and passed there: that reading stands.
  if (underBase === "passed") return { status: "passed", regressed: [] };
  const v2 = check.attributionRule === "failure-identity-v2";
  const points = v2
    ? namedTestsV2(check.configurationObservation)
    : namedTestsV1(check.configurationObservation);
  const base =
    check.baseObservation === undefined
      ? null
      : v2
        ? namedTestsV2(check.baseObservation)
        : namedTestsV1(check.baseObservation);
  const title = (id) => (id.includes(" › ") ? id.slice(id.indexOf(" › ") + 3) : id);
  const regressed =
    points === null || base === null
      ? []
      : v2
        ? points.failed.filter(
            (id) =>
              base.passed.filter((one) => one === id || one === title(id)).length === 1 &&
              !base.failed.some((one) => one === id || title(one) === title(id)),
          )
        : points.failed.filter((id) => base.passed.includes(id) && !base.failed.includes(id));
  return {
    status: underBase === "failed" && regressed.length > 0 ? "failed" : "not-applicable",
    regressed,
  };
}

const sameList = (a, b) => JSON.stringify([...(a ?? [])]) === JSON.stringify([...(b ?? [])]);

/**
 * Derive new captured-check results; undefined preserves older aggregate-only records.
 *
 * A record that carries `attribution` or a base-configuration reading is judged by the rule that
 * wrote them: every failed check's attribution is recomputed from its readings and must match,
 * a check the patch's runner configuration alone passed must carry the status the base's
 * configuration decides, and only a proven inherited failure is left out of the dimension. A
 * record without them is judged by the rule it was written under, which read any failure the base
 * shared as inherited and left the dimension unmeasured. Records from 1.0.3 to 1.0.5 that read
 * such a failure as a regression pass do not re-derive, and should not: that pass was not shown.
 */
function capturedRegression(checks) {
  if (!Array.isArray(checks) || !checks.some((check) => check.observation !== undefined))
    return undefined;
  try {
    const attributed = checks.some(
      (check) => check.attribution !== undefined || check.configurationObservation !== undefined,
    );
    for (const check of checks) {
      if (
        check.observation === undefined ||
        typeof check.id !== "string" ||
        !["passed", "failed", "not-applicable"].includes(check.status) ||
        (check.optionalAbsence !== undefined && typeof check.optionalAbsence !== "boolean") ||
        (check.optionalAbsence === true &&
          (check.status !== "not-applicable" ||
            typeof check.observation.unavailable !== "string" ||
            check.observation.exitCode !== 0 ||
            check.observation.stdout !== "" ||
            check.observation.stderr !== "")) ||
        !["blocking", "advisory"].includes(check.severity)
      )
        return null;
      const expected = expectedStatus(check);
      if (expected === null || expected.status !== check.status) return null;
      if (!sameList(expected.weakened, check.weakenedTests ?? [])) return null;
      if (
        check.configurationObservation !== undefined &&
        !sameList(expected.regressed, check.regressedUnderBaseConfiguration ?? [])
      )
        return null;
      if (!attributed) {
        if (
          check.inheritedFromBase === true &&
          (!check.baseObservation || readStatus(check.parser, check.baseObservation) !== "failed")
        )
          return null;
        continue;
      }
      if (check.status !== "failed") {
        if (check.attribution !== undefined || check.inheritedFromBase === true) return null;
        continue;
      }
      const failing =
        (check.regressedUnderBaseConfiguration ?? []).length > 0
          ? check.configurationObservation
          : check.observation;
      const derived = attribution(check, failing);
      if (
        derived.attribution !== check.attribution ||
        (check.inheritedFromBase === true) !== (derived.attribution === "inherited") ||
        !sameList(derived.newFailures, check.newFailures ?? [])
      )
        return null;
    }
    const inherited = (check) =>
      check.status === "failed" &&
      (attributed ? check.attribution === "inherited" : check.inheritedFromBase === true);
    if (
      checks.some(
        (check) =>
          check.status === "failed" &&
          !inherited(check) &&
          !(attributed && check.attribution === "unattributed"),
      )
    )
      return "fail";
    if (
      checks.some(
        (check) =>
          check.severity === "blocking" &&
          check.status !== "passed" &&
          check.optionalAbsence !== true &&
          !(attributed && inherited(check)),
      )
    )
      return "unmeasured";
    return checks.some((check) => check.status === "passed") ? "pass" : "unmeasured";
  } catch {
    return null;
  }
}


export { readStatus };

import { readdirSync, readFileSync, realpathSync } from "node:fs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import {
  evaluateClaim,
  goalSelectionConformance,
  indexCitedRecords,
  readControllerHistory,
  recomputeBondVerdict,
  sealConformance,
  sha256,
} from "./verify.mjs";

/**
 * Whether a vacuous oracle bond refuses to certify.
 *
 * Mirrors `bondRefusesCertification` in src/gates/certification.ts, which is where the decision
 * lives. A verifier that carried its own opinion of the policy would agree with the tool by
 * coincidence rather than by construction, so the parity test in that tree holds the two to each
 * other over a table of cases.
 */
export const bondRefusesCertification = true;

/**
 * The fields the policy reads, and the words each of them may carry.
 *
 * A field carrying a word the policy does not know is as unreadable as an absent one, and it is
 * the more dangerous of the two: `not-recorded` in a field a rule tests for one specific value
 * reads as "not that value" and lets the record certify. So the vocabulary is checked rather than
 * assumed, and only for the fields the policy actually reads, since holding a record to a rule
 * nothing applies would refuse it for a field no verdict depends on.
 *
 * `no-change` is the passes' word for the agent having written nothing, kept apart from
 * `unmeasured` because a run with nothing to measure and a run the harness could not measure are
 * different findings. Neither is `pass`, so neither certifies.
 */
const verdictVocabulary = {
  regression: ["pass", "fail", "unmeasured", "no-change"],
  task: ["accepted", "rejected", "unjudged", "vacuous"],
  oracleReach: ["reached", "unreached", "unmeasured"],
  oracleBond: ["held", "vacuous", "unshown", "not-bonded"],
};

const fieldsTheVerdictPolicyReads = ["regression", "task", "oracleReach"];

/**
 * Every reason a recorded `swarm ci` verdict holds for not certifying, named.
 *
 * Mirrors `reasonsToRefuse` in src/gates/certification.ts, rule for rule. `verified` is the
 * absence of these and nothing else, which is what lets a third party recompute it from the
 * record instead of trusting the run that wrote it.
 */
export function refusalsToCertify(verdict) {
  const reasons = [];
  if (verdict.regression !== "pass") reasons.push("regression-not-pass");
  if (verdict.task !== "accepted") reasons.push("task-not-accepted");
  if (verdict.oracleReach === "unreached") reasons.push("oracle-did-not-reach-the-change");
  if (bondRefusesCertification && verdict.oracleBond === "vacuous") {
    reasons.push("oracle-bond-vacuous");
  }
  return reasons;
}

/**
 * The bond a row's own mutants imply, so the measurement is checkable and not only the verdict
 * that reads it.
 *
 * Gate 3a re-derived whether `verified` follows from `oracleBond`, and nothing asked whether
 * `oracleBond` follows from the mutants recorded beside it. A measurement nobody can recompute is
 * the same shape of claim as a green nobody can recompute.
 *
 * Worst finding first, which is the rule a run applies. One mutant the oracle accepted on a line
 * it ran is a demonstrated gap whatever the others did, so `vacuous` outranks `held`: the refusals
 * establish that the oracle can fail and say nothing about the line it passed over. Below that a
 * refusal outranks an absence of evidence, and no mutant at all means nothing was asked.
 */
export function rederiveOracleBond(mutants) {
  const recorded = mutants ?? [];
  if (recorded.length === 0) {
    return "not-bonded";
  }
  if (recorded.some((one) => one.verdict === "vacuous")) {
    return "vacuous";
  }
  return recorded.some((one) => one.verdict === "held") ? "held" : "unshown";
}

/**
 * The verdict a recorded `swarm ci` result implies, or the fields that stop it implying one.
 *
 * A green claim nobody can recompute is exactly what gate 3a exists to bar, so a record claiming
 * `verified` has to carry every field the policy reads, in words the policy knows: a field nobody
 * recorded could have held the reason that refuses it.
 *
 * A refusal is different, and reading it the same way was a defect in this check rather than in
 * the records. The reasons are monotone in the fields present, so a record whose present fields
 * already hold one has a determinate verdict whatever is missing: nothing a later field could say
 * takes a reason back. Demanding every field of a refusal too reported 94 of 129 recorded verdicts
 * as impossible to check when 89 of them were determinate.
 */
export function rederiveCiVerdict(verdict) {
  const regression = capturedRegression(verdict.checks);
  if (regression !== undefined && regression !== verdict.regression)
    return {
      rederived: false,
      missing: ["consistent captured regression"],
      reasons: [],
      verified: null,
    };
  if (verdict.certificationPolicy === "goal-obligations-v1") {
    const obligations = verdict.goalAcceptance?.obligations;
    if (
      !Array.isArray(obligations) ||
      obligations.length === 0 ||
      !verdictVocabulary.regression.includes(verdict.regression) ||
      obligations.some((entry) => !["accepted", "rejected", "unjudged"].includes(entry.status))
    )
      return {
        rederived: false,
        missing: ["goalAcceptance.obligations"],
        reasons: [],
        verified: null,
      };
    const challenges = verdict.challenges;
    if (
      challenges !== undefined &&
      (!["off", "report", "required"].includes(challenges.policy) ||
        typeof challenges.satisfied !== "boolean")
    )
      return { rederived: false, missing: ["challenges"], reasons: [], verified: null };
    const challengesUnmet = challenges?.policy === "required" && challenges.satisfied !== true;
    const verified =
      verdict.regression === "pass" &&
      obligations.every((entry) => entry.status === "accepted") &&
      !challengesUnmet;
    return {
      rederived: true,
      missing: [],
      reasons: verified
        ? []
        : [
            ...(challengesUnmet ? ["challenges-unmet"] : []),
            ...(verdict.regression === "pass" &&
            obligations.every((entry) => entry.status === "accepted")
              ? []
              : ["goal-obligations-or-regression-refused"]),
          ],
      verified,
    };
  }
  if (verdict.certificationPolicy === "required-obligations-v1") {
    const obligations = verdict.acceptance?.obligations;
    if (
      !Array.isArray(obligations) ||
      obligations.length === 0 ||
      !verdictVocabulary.regression.includes(verdict.regression) ||
      obligations.some(
        (entry) =>
          !["required", "advisory"].includes(entry.severity) ||
          !["accepted", "rejected", "unjudged", "not-applicable"].includes(entry.status),
      )
    )
      return { rederived: false, missing: ["acceptance.obligations"], reasons: [], verified: null };
    const accepted = obligations.every(
      (obligation) =>
        obligation.severity === "advisory" ||
        ["accepted", "not-applicable"].includes(obligation.status),
    );
    const verified = verdict.regression === "pass" && accepted;
    return {
      rederived: true,
      missing: [],
      reasons: verified ? [] : ["required-obligations-or-regression-refused"],
      verified,
    };
  }
  const read = bondRefusesCertification
    ? [...fieldsTheVerdictPolicyReads, "oracleBond"]
    : fieldsTheVerdictPolicyReads;
  const missing = read.filter((name) => !verdictVocabulary[name].includes(verdict[name]));
  const reasons = refusalsToCertify(verdict);
  if (reasons.length > 0) {
    return { rederived: true, missing, reasons, verified: false };
  }
  if (missing.length > 0) {
    return { rederived: false, missing, reasons: [], verified: null };
  }
  return { rederived: true, missing: [], reasons, verified: true };
}

/**
 * The violations the ratchet's rules find in a decision's own before-and-after measures.
 * Assertions are compared only where no re-specification was cleared, because the allowance
 * a cleared specification earns is computed from the files and not recorded as a number.
 */
export function rederiveRatchet(payload) {
  const violations = [];
  const skipped = [];
  const before = payload.measures?.before ?? {};
  const after = payload.measures?.after ?? {};
  for (const [gateId, status] of Object.entries(payload.gates?.before ?? {})) {
    if (status !== "passed") continue;
    const now = payload.gates?.after?.[gateId];
    if (now === undefined) continue;
    if (now !== "passed") violations.push("gate-regressed");
  }
  if (after.testsDeclared < before.testsDeclared) violations.push("tests-declared-decreased");
  if (
    (payload.respecification ?? []).length === 0 &&
    (payload.newSpecifications ?? []).length === 0
  ) {
    if (after.assertions < before.assertions) violations.push("assertions-decreased");
  } else {
    skipped.push("assertions-decreased");
  }
  if (after.skipMarkers > before.skipMarkers) violations.push("skip-markers-increased");
  if (
    before.testsCollected !== null &&
    after.testsCollected !== null &&
    before.testsCollected !== undefined &&
    after.testsCollected !== undefined &&
    (payload.newSpecifications ?? []).length === 0 &&
    after.testsCollected < before.testsCollected
  ) {
    violations.push("tests-collected-decreased");
  }
  if (
    before.changedLineCoverage !== null &&
    after.changedLineCoverage !== null &&
    before.changedLineCoverage !== undefined &&
    after.changedLineCoverage !== undefined &&
    after.changedLineCoverage < before.changedLineCoverage
  ) {
    violations.push("changed-line-coverage-decreased");
  }
  return { violations: [...new Set(violations)], skipped };
}

function loadBundle(directory) {
  const manifest = JSON.parse(readFileSync(join(directory, "manifest.json"), "utf8"));
  const records = readFileSync(join(directory, "ledger.jsonl"), "utf8")
    .split("\n")
    .filter((line) => line.trim().length > 0)
    .map((line) => JSON.parse(line));
  const payloads = new Map();
  for (const file of readdirSync(join(directory, "blobs"))) {
    const bytes = readFileSync(join(directory, "blobs", file), "utf8");
    payloads.set(sha256(bytes), JSON.parse(bytes));
  }
  let dag = null;
  try {
    dag = JSON.parse(readFileSync(join(directory, "dag.json"), "utf8"));
  } catch {
    dag = null;
  }
  return { manifest, records, payloads, dag };
}

export function rederiveBundle(directory, log = console.log) {
  const { manifest, records, payloads, dag } = loadBundle(directory);
  const lines = [];
  let disagreements = 0;
  let agreements = 0;
  let notRederived = 0;
  const say = (mark, text) => {
    lines.push(`  ${mark.padEnd(13)} ${text}`);
  };
  const agree = (text) => {
    agreements += 1;
    say("AGREES", text);
  };
  const disagree = (text) => {
    disagreements += 1;
    say("DISAGREES", text);
  };
  const cannot = (text) => {
    notRederived += 1;
    say("NOT RE-DERIVED", text);
  };

  for (const entry of records.filter((record) => record.type === "verification-command")) {
    const payload = payloads.get(entry.payloadDigest);
    const status = rederiveRequirementCommand(payload);
    if (status === null)
      cannot(`verification-command ${entry.sequence}: rule or complete output is unavailable`);
    else if (status === payload.status)
      agree(`verification-command ${entry.sequence}: ${status} under ${payload.rule}`);
    else
      disagree(
        `verification-command ${entry.sequence}: recorded ${payload.status}, the rule reads ${status}`,
      );
  }
  if (
    records.some(
      (entry) =>
        entry.type === "controller-graph" ||
        entry.type === "bootstrap-stage" ||
        (entry.type === "controller-launch" &&
          payloads.get(entry.payloadDigest)?.spec?.bootstrap !== undefined),
    )
  ) {
    const board = readControllerHistory(records, payloads);
    if (board.problems.length > 0) disagree(`controller history: ${board.problems.join("; ")}`);
    else
      agree(
        `controller history: graph revision ${board.graph?.ordinal}, ${board.accepted.size} currently accepted tasks`,
      );
  }
  for (const selection of goalSelectionConformance(records, payloads)) {
    if (selection.problems.length > 0)
      disagree(`goal selection ${selection.sequence}: ${selection.problems.join("; ")}`);
    else
      agree(
        `goal selection ${selection.sequence}: complete requirements, measured objective and stable order`,
      );
  }
  const parserByGate = new Map();
  // A gate-baseline record is a gate run over the base tree, in the same shape, read by the
  // same rule.

  for (const entry of records.filter(
    (candidate) => candidate.type === "independent-verification",
  )) {
    const payload = payloads.get(entry.payloadDigest);
    const reading = rederiveCiVerdict(payload ?? {});
    if (!reading.rederived)
      cannot(`independent verification ${entry.sequence}: ${reading.missing.join(", ")}`);
    else if (payload?.verified === reading.verified)
      agree(
        `independent verification ${entry.sequence}: ${reading.verified} under ${payload.certificationPolicy ?? "oracle-v3"}`,
      );
    else
      disagree(
        `independent verification ${entry.sequence}: recorded ${payload?.verified}, policy implies ${reading.verified}`,
      );
  }
  for (const entry of records) {
    if (entry.type !== "gate-run" && entry.type !== "gate-baseline") continue;
    const payload = payloads.get(entry.payloadDigest);
    if (payload === undefined) {
      cannot(`${entry.type} ${entry.sequence}: payload missing`);
      continue;
    }
    const parser = payload.parser ?? "exit-code";
    const ruleNote =
      payload.parser === undefined ? " (rule not named in this record; exit-code assumed)" : "";
    parserByGate.set(payload.gateId, parser);
    if (payload.outputTruncated === true) {
      cannot(
        `${entry.type} ${entry.sequence} ${payload.gateId}: the record truncated the output the rule reads`,
      );
      continue;
    }
    const status = readStatus(parser, payload);
    if (status === null) {
      cannot(`${entry.type} ${entry.sequence} ${payload.gateId}: no rule named ${parser}`);
      continue;
    }
    if (status === payload.status) {
      agree(
        `${entry.type} ${entry.sequence} ${payload.gateId}: ${status} under the ${parser} rule${ruleNote}`,
      );
    } else {
      disagree(
        `${entry.type} ${entry.sequence} ${payload.gateId}: recorded ${payload.status}, the ${parser} rule reads ${status}`,
      );
    }
  }

  for (const entry of records) {
    if (entry.type !== "gate-bond") continue;
    const payload = payloads.get(entry.payloadDigest);
    if (payload === undefined) {
      cannot(`gate-bond ${entry.sequence}: payload missing`);
      continue;
    }
    if (payload.bond === null || payload.observed === null) {
      agree(
        `gate-bond ${entry.sequence} ${payload.gateId}: ${payload.verdict}, nothing observed to re-read`,
      );
      continue;
    }
    const parser = parserByGate.get(payload.gateId) ?? "exit-code";
    const observed = readStatus(parser, payload);
    const verdict = recomputeBondVerdict({ ...payload, observed });
    if (observed === payload.observed && verdict === payload.verdict) {
      agree(
        `gate-bond ${entry.sequence} ${payload.gateId}: ${observed} over the bond, so ${verdict}`,
      );
    } else {
      disagree(
        `gate-bond ${entry.sequence} ${payload.gateId}: recorded ${payload.observed} and ${payload.verdict}, the ${parser} rule reads ${observed} and ${verdict}`,
      );
    }
  }

  for (const entry of records) {
    if (entry.type !== "ratchet-decision") continue;
    const payload = payloads.get(entry.payloadDigest);
    if (payload === undefined) {
      cannot(`ratchet-decision ${entry.sequence}: payload missing`);
      continue;
    }
    const { violations, skipped } = rederiveRatchet(payload);
    const recorded = new Set((payload.violations ?? []).map((violation) => violation.kind));
    const missing = violations.filter((kind) => !recorded.has(kind));
    const extra = [...recorded].filter(
      (kind) => !violations.includes(kind) && !skipped.includes(kind),
    );
    const acceptedAgrees = payload.accepted === (recorded.size === 0);
    if (missing.length === 0 && extra.length === 0 && acceptedAgrees) {
      agree(
        `ratchet-decision ${entry.sequence} (${payload.scope}, attempt ${payload.attempt}): ${payload.accepted ? "accepted" : "rejected"}` +
          (violations.length > 0 ? `, ${violations.join(", ")}` : "") +
          (skipped.length > 0
            ? ` (${skipped.join(", ")} not re-derived: allowance not recorded as a number)`
            : ""),
      );
    } else {
      disagree(
        `ratchet-decision ${entry.sequence}: recorded ${[...recorded].join(", ") || "no violation"}, the measures give ${violations.join(", ") || "no violation"}` +
          (acceptedAgrees ? "" : `; accepted=${payload.accepted} does not follow from that`),
      );
    }
  }

  const cited = indexCitedRecords(records, payloads);
  const recordedVerdicts = new Map(
    (dag?.claims ?? []).map((claim) => [claim.sequence, claim.evaluation?.verdict]),
  );
  for (const entry of records) {
    if (entry.type !== "claim") continue;
    const claim = payloads.get(entry.payloadDigest);
    const evaluation = evaluateClaim(claim, (digest) => cited.get(digest));
    const recorded = recordedVerdicts.get(entry.sequence);
    if (recorded === undefined) {
      cannot(
        `claim ${entry.sequence}: dag.json records no verdict to compare with ${evaluation.verdict}`,
      );
    } else if (recorded === evaluation.verdict) {
      agree(`claim ${entry.sequence}: ${evaluation.verdict}`);
    } else {
      disagree(
        `claim ${entry.sequence}: dag.json says ${recorded}, the predicate over its record says ${evaluation.verdict}`,
      );
    }
  }

  const conformance = sealConformance(records, payloads);
  const gateRan = records.some((entry) => entry.type === "gate-run");
  if (conformance.sealed === null) {
    if ((manifest.bundleFormat ?? 1) >= 2 && gateRan) {
      disagree(
        "sealed criteria: bundle format 2 promises a seal before the gates ran, and none is recorded",
      );
    } else if (gateRan) {
      cannot("sealed criteria: none recorded, this bundle format predates sealing");
    } else {
      cannot("sealed criteria: no gate ran, so there is nothing to hold to a seal");
    }
  } else if (conformance.problems.length === 0) {
    agree(
      `sealed criteria: ${conformance.sealed.gates} gate(s) sealed at record ${conformance.sealed.sequence}, every gate run conforms`,
    );
  } else {
    disagree(`sealed criteria: ${conformance.problems.join("; ")}`);
  }

  log(`re-deriving verdicts in ${directory}`);
  log("");
  for (const line of lines) log(line);
  log("");
  log(
    disagreements === 0
      ? `every re-derived verdict agrees: ${agreements} agree, ${notRederived} could not be re-derived from the bundle alone`
      : `re-derivation FAILED: ${disagreements} verdict(s) disagree, ${agreements} agree, ${notRederived} could not be re-derived`,
  );
  return disagreements === 0 ? 0 : 1;
}

function rederiveRequirementCommand(payload) {
  if (payload?.rule !== "controlled-node-tap-v1") return null;
  if (payload.unavailable != null || payload.outputTruncated === true) return "unavailable";
  if (typeof payload.stdout !== "string" || !/^TAP version \d+/m.test(payload.stdout))
    return "unavailable";
  let plan = null;
  let top = 0;
  let collected = 0;
  let skippedCount = 0;
  const skipped = new Set();
  const passed = new Set();
  const failed = new Set();
  for (const line of payload.stdout.split("\n")) {
    if (/^\s*#/.test(line)) continue;
    const count = /^1\.\.(\d+)\s*$/.exec(line);
    if (count !== null) {
      plan = Number(count[1]);
      continue;
    }
    const point = /^(\s*)(not ok|ok)\s+\d+\s+-\s+(.+?)\s*$/.exec(line);
    if (point === null) continue;
    if (point[1] === "") top += 1;
    collected += 1;
    const [name, directive] = point[3].split(/\s+#\s+/, 2);
    if (/^skip\b/i.test(directive ?? "")) skippedCount += 1;
    if (/^(skip|todo)\b/i.test(directive ?? "")) skipped.add(name);
    else (point[2] === "not ok" ? failed : passed).add(name);
  }
  const failures = [...failed].filter((name) => !skipped.has(name) && !passed.has(name));
  const successes = [...passed].filter((name) => !skipped.has(name) && !failed.has(name));
  if (
    plan === null ||
    plan !== top ||
    collected - skippedCount === 0 ||
    failures.length + successes.length === 0
  )
    return "unavailable";
  if (payload.exitCode === 0) return "passed";
  return failures.length > 0 && /^\s+code: ['"]?ERR_ASSERTION['"]?\s*$/m.test(payload.stdout)
    ? "assertion-failed"
    : "unavailable";
}

const entry =
  process.argv[1] === undefined ? null : pathToFileURL(realpathSync(process.argv[1])).href;
if (entry === import.meta.url) {
  process.exitCode = rederiveBundle(process.argv[2] ?? ".");
}
