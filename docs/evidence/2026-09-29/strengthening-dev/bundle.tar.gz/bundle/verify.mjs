#!/usr/bin/env node

// Embedded bundle verifier for swarm-orchestrator evidence bundles.
//
// Dependency-free on purpose: it imports nothing outside node: builtins, so a reviewer can
// check a bundle on any Node 18+ machine without installing the tool that produced it. It
// recomputes every hash, every signature check, and every claim verdict from the bundle's
// own bytes. Nothing stated in the manifest or dag.json is taken on trust.
//
//   node verify.mjs <bundle directory>
//
// Exit code 0 means every check passed. Exit code 1 means at least one did not.

import { createHash, createPublicKey, verify as verifySignature } from "node:crypto";
import { readdirSync, readFileSync, realpathSync } from "node:fs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";


/** Independent behavior assertion derivation from sealed definitions and raw observations. */
function behaviorStatus(check, observed) {
  if (!check || !observed || observed.unavailable !== null || observed.outputTruncated === true)
    return "unjudged";
  if (check.kind === "browser") {
    const encoded = JSON.stringify(check, (_key, value) =>
      value && typeof value === "object" && !Array.isArray(value)
        ? Object.fromEntries(
            Object.keys(value)
              .sort()
              .map((key) => [key, value[key]]),
          )
        : value,
    );
    const identity = `sha256:${createHash("sha256").update(encoded).digest("hex")}`;
    if (
      !check.instrument ||
      !Array.isArray(check.instrument.titles) ||
      check.instrument.titles.length !== check.expectedTests ||
      new Set(check.instrument.titles).size !== check.expectedTests ||
      observed.browserExecution?.kind !== "sealed-playwright-v1" ||
      observed.browserExecution?.runtime !== "immutable-container" ||
      observed.browserExecution?.instrumentDigest !== identity
    )
      return "unjudged";
  }
  const matches = (text, assertions) =>
    typeof text === "string" &&
    Array.isArray(assertions) &&
    assertions.every((assertion) =>
      assertion.kind === "equals"
        ? text === assertion.value
        : assertion.kind === "contains" && text.includes(assertion.value),
    );
  if (check.kind === "cli")
    return observed.exitCode === check.exitCode &&
      matches(observed.stdout, check.stdout) &&
      matches(observed.stderr, check.stderr)
      ? "accepted"
      : "rejected";
  if (
    check.kind === "browser" &&
    observed.exitCode !== 0 &&
    /Executable doesn't exist|Cannot find (?:module|package)|MODULE_NOT_FOUND|ERR_MODULE_NOT_FOUND|ENOENT.*swarm-browser\/node_modules|trusted Playwright modules|browser instrument refuses candidate modules/i.test(
      observed.stdout + observed.stderr,
    )
  )
    return "unjudged";
  if (check.kind === "browser") {
    try {
      const report = JSON.parse(observed.stdout);
      if (
        report.stats &&
        ["expected", "unexpected", "flaky", "skipped"].every((key) => report.stats[key] === 0)
      )
        return "unjudged";
    } catch {
      /* Retain the process failure or malformed-result outcome below. */
    }
  }
  if (observed.exitCode !== 0) return "rejected";
  try {
    const result = JSON.parse(observed.stdout);
    if (check.kind === "http") {
      if (result.unavailable !== null || result.truncated) return "unjudged";
      let json = true;
      if (check.json.length) {
        const body = JSON.parse(result.body);
        json = check.json.every((assertion) => {
          let value = body;
          for (const key of assertion.path)
            value =
              value !== null && typeof value === "object" && Object.hasOwn(value, key)
                ? value[key]
                : undefined;
          return value === assertion.equals;
        });
      }
      return result.failure === undefined &&
        result.status === check.status &&
        Object.entries(check.headers).every(([key, value]) => result.headers?.[key] === value) &&
        matches(result.body ?? "", check.body) &&
        json
        ? "accepted"
        : "rejected";
    }
    if (
      check.kind !== "browser" ||
      !result.stats ||
      !Array.isArray(result.errors) ||
      !Array.isArray(result.suites)
    )
      return "unjudged";
    const points = [];
    const visit = (groups, depth) => {
      if (!Array.isArray(groups) || depth > 32 || points.length > 100000)
        throw Error("invalid suites");
      for (const group of groups) {
        if (!Array.isArray(group.specs)) throw Error("missing specs");
        for (const spec of group.specs) {
          if (
            typeof spec.id !== "string" ||
            !spec.id ||
            !Array.isArray(spec.tests) ||
            !spec.tests.length
          )
            throw Error("invalid spec");
          for (const test of spec.tests) {
            if (
              typeof test.projectName !== "string" ||
              !Array.isArray(test.results) ||
              !test.results.length ||
              test.expectedStatus !== "passed"
            )
              throw Error("invalid test");
            points.push({
              id: `${spec.id}:${test.projectName}`,
              title: spec.title,
              file: spec.file,
              test,
            });
          }
        }
        visit(group.suites ?? [], depth + 1);
      }
    };
    visit(result.suites, 0);
    if (new Set(points.map((point) => point.id)).size !== points.length) return "unjudged";
    const count = (status) => points.filter((point) => point.test.status === status).length;
    for (const [field, status] of [
      ["expected", "expected"],
      ["unexpected", "unexpected"],
      ["flaky", "flaky"],
      ["skipped", "skipped"],
    ])
      if (result.stats[field] !== count(status)) return "unjudged";
    return points.length === check.expectedTests &&
      new Set(points.map((point) => point.title)).size === check.expectedTests &&
      points.every(
        (point) =>
          point.file === "instrument.spec.mjs" &&
          point.test.projectName === "chromium" &&
          check.instrument.titles.includes(point.title),
      ) &&
      result.errors.length === 0 &&
      points.every(
        ({ test }) =>
          test.status === "expected" &&
          test.results.length === 1 &&
          test.results[0].status === "passed" &&
          Array.isArray(test.results[0].errors) &&
          test.results[0].errors.length === 0,
      )
      ? "accepted"
      : "rejected";
  } catch {
    return "unjudged";
  }
}

const challengeVerdictsAgree = (() => {// The offline reading of a challenge verdict, independent of the module that produced it.
//
// A challenge verdict record says, per requirement, what challenging its checks established. This
// re-derives every one of those readings from the plan record written before anything ran, the
// completed run records between them, the base-control goal verification the verdict names, and
// the final goal verification of the candidate. It shares no code with `src/gates/goal-challenges.ts`;
// the two are held to the same cases by a parity test. Anything it cannot re-derive is named as
// such rather than agreed with.

/**
 * A requirement's status from its checks' statuses, by the goal verifier's rule.
 * @param {{checks: string[]}} requirement
 * @param {Array<{id: string, status: string}>} checks
 */
function requirementStatusOf(requirement, checks) {
  const statuses = requirement.checks.map(
    (id) => checks.find((check) => check.id === id)?.status ?? "unjudged",
  );
  if (statuses.length === 0 || statuses.includes("unjudged")) return "unjudged";
  return statuses.every((status) => status === "accepted") ? "accepted" : "rejected";
}

function baseControlOf(requirementId, base, presetKind) {
  if (base === null || base === undefined) return "not-run";
  const obligation = (base.obligations ?? []).find((entry) => entry.id === requirementId);
  if (obligation === undefined || obligation.status === "unjudged") return "unavailable";
  if (obligation.status === "rejected") return "discriminates";
  return presetKind === "refactor" ? "preserved" : "vacuous";
}

const invalidParses = new Set(["not-applied", "syntax-error", "dialect-unreadable"]);

/**
 * The requirement outcome from the observations, the same rule the producer applies.
 * @returns {{outcome: string, caught: string[], gaps: string[], unwitnessed: string[], invalid: string[]}}
 */
function readChallengeOutcome(input) {
  const { requirement } = input;
  const caught = [];
  const gaps = [];
  const unwitnessed = [];
  const invalid = [];
  for (const one of input.alternatives) {
    const relevant = one.kind === "mutant" || one.fixture?.requirement === requirement.id;
    if (!relevant) continue;
    if (invalidParses.has(one.parse)) {
      if (one.kind === "fixture") invalid.push(one.id);
      continue;
    }
    const status =
      (one.requirements ?? []).find((entry) => entry.id === requirement.id)?.status ?? "unjudged";
    if (status === "rejected") caught.push(one.id);
    else if (status === "unjudged") invalid.push(one.id);
    else if (one.witness === "repository-suite" || one.witness === "declared-fixture")
      gaps.push(one.id);
    else unwitnessed.push(one.id);
  }
  const outcome =
    requirement.checks.length === 0
      ? "gap"
      : input.candidate === "unjudged"
        ? "invalid-evidence"
        : input.baseControl === "vacuous"
          ? "gap"
          : gaps.length > 0
            ? "gap"
            : invalid.length > 0
              ? "invalid-evidence"
              : caught.length > 0 &&
                  (input.baseControl === "discriminates" || input.baseControl === "preserved")
                ? "detected"
                : "unjudged";
  return { outcome, caught, gaps, unwitnessed, invalid };
}

/**
 * Every challenge verdict in the record, each re-derived or named as not re-derivable.
 * @param {Array<{sequence: number, type: string, payloadDigest: string}>} records
 * @param {Map<string, any>} payloads
 * @returns {Array<{sequence: number, agrees: boolean, problems: string[]}>}
 */
function challengeVerdictsAgree(records, payloads) {
  const findings = [];
  const commands = records.filter((entry) => entry.type === "verification-command");
  for (const entry of commands) {
    const verdict = payloads.get(entry.payloadDigest);
    if (verdict?.rule !== "challenge-verdict-v1") continue;
    const problems = [];
    // The nearest plan before the verdict: the same contract challenged twice over the same tree
    // writes two plans with one digest, and the earlier one's runs are not this verdict's.
    const plan = commands
      .filter(
        (candidate) =>
          candidate.sequence < entry.sequence && candidate.payloadDigest === verdict.plan,
      )
      .at(-1);
    const planned = payloads.get(plan?.payloadDigest);
    if (planned?.rule !== "challenge-plan-v1" || planned.contractDigest !== verdict.contractDigest)
      problems.push("the verdict names no plan written before it for this contract");
    if (planned?.policy !== verdict.policy)
      problems.push("the plan and the verdict disagree on the policy");
    const declaration = records.find(
      (candidate) =>
        candidate.type === "goal-contract" &&
        candidate.sequence < entry.sequence &&
        payloads.get(candidate.payloadDigest)?.digest === verdict.contractDigest,
    );
    const contract = payloads.get(declaration?.payloadDigest)?.contract;
    if (contract === undefined)
      problems.push("the contract the verdict names is not on the chain before it");
    const runs = commands
      .filter(
        (candidate) =>
          candidate.sequence > (plan?.sequence ?? Number.MAX_SAFE_INTEGER) &&
          candidate.sequence < entry.sequence,
      )
      .map((candidate) => payloads.get(candidate.payloadDigest))
      .filter((payload) => payload?.rule === "challenge-run-v1" && payload.plan === verdict.plan);
    const completed = runs.filter((run) => run.phase === "completed");
    const intents = runs.filter((run) => run.phase === "intent");
    if (completed.length !== (verdict.alternatives ?? []).length)
      problems.push(
        `${completed.length} completed run(s) on the chain, ${(verdict.alternatives ?? []).length} in the verdict`,
      );
    for (const one of completed) {
      if (!intents.some((intent) => intent.id === one.id))
        problems.push(`run ${one.id} completed with no intent before it`);
      const declared = (verdict.alternatives ?? []).find(
        (alternative) => alternative.id === one.id,
      );
      if (declared === undefined) problems.push(`run ${one.id} is not in the verdict`);
      else if (JSON.stringify(declared.requirements) !== JSON.stringify(one.requirements))
        problems.push(
          `run ${one.id} recorded different requirement statuses than the verdict carries`,
        );
      if (one.kind === "mutant" && !(planned?.mutants ?? []).includes(one.id))
        problems.push(`mutant ${one.id} was not in the plan`);
      if (
        one.kind === "fixture" &&
        !(planned?.fixtures ?? []).some((fixture) => fixture.id === one.id)
      )
        problems.push(`fixture ${one.id} was not in the plan`);
    }
    // The base control the verdict names, as the goal verifier recorded it.
    const base =
      verdict.baseTree === null
        ? null
        : (records
            .filter(
              (candidate) =>
                candidate.type === "goal-verification" && candidate.sequence < entry.sequence,
            )
            .map((candidate) => payloads.get(candidate.payloadDigest))
            .find(
              (payload) =>
                payload?.tree === verdict.baseTree &&
                payload?.contractDigest === verdict.contractDigest,
            ) ?? undefined);
    if (base === undefined) problems.push("the base control the verdict names is not on the chain");
    const candidate = records
      .filter(
        (candidate) =>
          candidate.type === "goal-verification" && candidate.sequence < entry.sequence,
      )
      .map((candidate) => payloads.get(candidate.payloadDigest))
      .filter(
        (payload) =>
          payload?.contractDigest === verdict.contractDigest && payload?.tree !== verdict.baseTree,
      )
      .at(-1);
    if (candidate === undefined)
      problems.push("no candidate goal verification precedes the verdict");
    if (contract !== undefined && problems.length === 0) {
      const presetKind = contract.preset?.kind;
      for (const requirement of contract.requirements) {
        const recorded = (verdict.requirements ?? []).find((entry) => entry.id === requirement.id);
        const reading = readChallengeOutcome({
          requirement,
          candidate:
            candidate.obligations.find((entry) => entry.id === requirement.id)?.status ??
            "unjudged",
          baseControl: baseControlOf(requirement.id, base, presetKind),
          alternatives: completed,
        });
        if (recorded === undefined)
          problems.push(`requirement ${requirement.id} is missing from the verdict`);
        else if (
          recorded.outcome !== reading.outcome ||
          JSON.stringify(recorded.caught) !== JSON.stringify(reading.caught) ||
          JSON.stringify(recorded.gaps) !== JSON.stringify(reading.gaps)
        )
          problems.push(
            `requirement ${requirement.id}: recorded ${recorded.outcome}, the observations read ${reading.outcome}`,
          );
      }
      const satisfied = (verdict.requirements ?? []).every((entry) => entry.outcome === "detected");
      if (verdict.satisfied !== satisfied)
        problems.push("satisfied disagrees with the requirement outcomes");
    }
    findings.push({ sequence: entry.sequence, agrees: problems.length === 0, problems });
  }
  return findings;
}

return challengeVerdictsAgree;})();
const readControllerHistory = (() => {

function canonical(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  return `{${Object.keys(value)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`)
    .join(",")}}`;
}
const equal = (left, right) => canonical(left) === canonical(right);
const hash = (value) => `sha256:${createHash("sha256").update(canonical(value)).digest("hex")}`;
const containsAll = (haystack, needles) => needles.every((item) => haystack.includes(item));
const unique = (items) => new Set(items).size === items.length;
const protectedPath = (immutable, path) => {
  const root = immutable.replace(/\/\*\*$/, "");
  return path === root || path.startsWith(`${root}/`);
};
const canonicalPath = (path) =>
  typeof path === "string" &&
  path.length > 0 &&
  !/^[a-zA-Z]:|^[/~]|[\\*?{}[\]]/.test(path) &&
  ![...path].some((character) => character.charCodeAt(0) < 32 || character.charCodeAt(0) === 127) &&
  !path.split("/").some((part) => part === "" || part === "." || part === "..");

/** Independent interpretation of controller graph v1/v2 and effect events, with no producer imports. */
function readControllerHistory(records, payloads) {
  let graph = null;
  let head = null;
  let resource = null;
  const graphs = [];
  const states = new Map();
  const accepted = new Map();
  const dispatches = new Map();
  const candidates = new Map();
  const integrations = new Map();
  const integrationOrder = new Map();
  const completed = new Set();
  const stale = new Set();
  const cleanup = new Set();
  const cleaned = new Set();
  const reconciled = new Set();
  const problems = bootstrapProblems(records, payloads);
  const require = (condition, description) => {
    if (!condition) throw new Error(description);
  };
  const current = (candidate) => {
    const origin = graphs.find((revision) => revision.revision === candidate.graphRevision);
    return (
      origin !== undefined &&
      graph.nodes.some((node) => node.id === candidate.taskId) &&
      graphs.every(
        (revision) =>
          revision.ordinal <= origin.ordinal || !revision.affected.includes(candidate.taskId),
      )
    );
  };
  try {
    for (const entry of records) {
      if (
        !["controller-graph", "controller-transition", "controller-candidate"].includes(entry.type)
      )
        continue;
      require(entry.actor === "harness", "model text cannot authorize controller effects");
      const observed = payloads.get(entry.payloadDigest);
      require(observed !== null && typeof observed === "object", "controller payload is missing");
      if (entry.type === "controller-graph") {
        const { revision, ...content } = observed;
        require([1, 2].includes(observed.version) &&
          hash(content) === revision, "controller revision digest or version is invalid");
        require(Number.isInteger(observed.ordinal) &&
          Number.isInteger(observed.limit) &&
          observed.limit >= 0 &&
          observed.limit <= 16 &&
          observed.ordinal <= observed.limit, "graph revision budget is invalid");
        require(observed.nodes.length > 0 &&
          observed.nodes.length <= 128 &&
          unique(observed.nodes.map((node) => node.id)) &&
          unique(observed.nodes.map((node) => node.contract.taskId)) &&
          unique(observed.retired), "controller task identities are invalid");
        require((observed.version === 2) ===
          (observed.scope !== undefined), "controller scope authority requires graph version two");
        if (observed.scope !== undefined) {
          const scope = observed.scope;
          require(["files", "workspace"].includes(scope.kind) &&
            Array.isArray(scope.allowedPaths) &&
            scope.allowedPaths.every(canonicalPath) &&
            (scope.kind === "workspace"
              ? scope.allowedPaths.length === 0
              : scope.allowedPaths.length > 0), "controller scope authority is malformed");
          require(Array.isArray(scope.immutablePaths) &&
            scope.immutablePaths.every((path) =>
              canonicalPath(path.replace(/\/\*\*$/, "")),
            ), "controller immutable scope is malformed");
          for (const node of observed.nodes)
            require(containsAll(node.contract.immutablePaths, scope.immutablePaths) &&
              (scope.kind === "workspace" ||
                (node.contract.scopeKind !== "workspace" &&
                  containsAll(
                    scope.allowedPaths,
                    node.contract.allowedPaths,
                  ))), "task exceeds the pinned controller scope");
        }
        const ids = observed.nodes.map((node) => node.id);
        require(!observed.retired.some((id) =>
          ids.includes(id),
        ), "a retired task identity was reused");
        const obligations = [...new Set(observed.nodes.flatMap((node) => node.obligations))].sort();
        require(unique(observed.obligations) &&
          equal(
            [...observed.obligations].sort(),
            obligations,
          ), "a declared obligation disappeared or was invented");
        const visiting = new Set();
        const visited = new Set();
        const visit = (id) => {
          require(!visiting.has(id), `controller dependency cycle at ${id}`);
          if (visited.has(id)) return;
          const node = observed.nodes.find((node) => node.id === id);
          require(node !== undefined, `controller dependency ${id} is missing`);
          require(/^[a-z0-9][a-z0-9-]{0,99}$/.test(node.id), "task identity is not slug-shaped");
          visiting.add(id);
          for (const dependency of node.dependsOn) visit(dependency);
          visiting.delete(id);
          visited.add(id);
        };
        ids.forEach(visit);
        if (graph === null) {
          require(observed.parent === null &&
            observed.ordinal === 0 &&
            observed.operation === null &&
            observed.retired.length === 0 &&
            observed.affected.length === 0, "initial controller declaration is invalid");
          require(equal(observed.obligations, ids) &&
            observed.nodes.every((node) =>
              equal(node.obligations, [node.id]),
            ), "initial task obligations do not match the declaration");
          const configuration = records
            .filter(
              (record) =>
                record.sequence < entry.sequence &&
                record.type === "controller-configuration" &&
                record.actor === "harness",
            )
            .at(-1);
          if (configuration !== undefined)
            require(equal(
              observed.scope ?? null,
              payloads.get(configuration.payloadDigest)?.spec?.controllerScope ?? null,
            ), "initial graph changed the pinned controller scope");
          const goal = records
            .filter((record) => record.sequence < entry.sequence && record.type === "goal-contract")
            .at(-1);
          if (goal !== undefined)
            require(equal(
              observed.requirements,
              payloads
                .get(goal.payloadDigest)
                ?.contract?.requirements.map((requirement) => requirement.id),
            ), "controller graph does not cover the pinned goal requirements");
        } else {
          require(observed.version === graph.version &&
            equal(observed.scope ?? null, graph.scope ?? null) &&
            observed.parent === graph.revision &&
            observed.ordinal === graph.ordinal + 1 &&
            observed.limit === graph.limit &&
            equal(observed.obligations, graph.obligations) &&
            equal(
              observed.requirements,
              graph.requirements,
            ), "revision erased obligations, changed the ceiling or has the wrong parent");
          const operation = observed.operation;
          require(operation &&
            [
              "add-prerequisite",
              "amend-scope",
              "insert-prerequisite",
              "split",
              "combine",
              "reroute",
            ].includes(operation.kind), "unknown controller revision operation");
          const removed = operation.kind === "combine" ? operation.tasks : [operation.taskId];
          require(unique(removed) &&
            removed.every((id) =>
              graph.nodes.some((node) => node.id === id),
            ), "revision references an undeclared task");
          const originals = graph.nodes.filter((node) => removed.includes(node.id));
          const within = (contract, originals) => {
            require(!originals.some((prior) => prior.contract.scopeAuthority === "human") ||
              contract.scopeAuthority === "human", "revision delegated human scope authority");
            const allowed = originals.flatMap((prior) => prior.contract.allowedPaths);
            const immutable = originals.flatMap((prior) => prior.contract.immutablePaths);
            const checks = originals.flatMap((prior) => prior.contract.requiredChecks);
            require(originals.some((prior) => prior.contract.scopeKind === "workspace") ||
              containsAll(allowed, contract.allowedPaths), "revision broadened authorized paths");
            require(!contract.allowedPaths.some((path) =>
              immutable.some((protectedFile) => protectedPath(protectedFile, path)),
            ) &&
              containsAll(contract.immutablePaths, immutable) &&
              containsAll(
                contract.requiredChecks,
                checks,
              ), "revision weakened immutable paths or required checks");
            require(originals.every(
              (prior) =>
                containsAll(prior.contract.allowedTools, contract.allowedTools) &&
                prior.contract.network === contract.network &&
                prior.contract.execution === contract.execution &&
                prior.contract.riskTier === contract.riskTier,
            ), "revision broadened execution or tool authority");
            for (const key of ["maxSteps", "maxWallMs", "maxTokens"])
              require((contract.budget[key] ?? 200000) <=
                Math.max(
                  ...originals.map((prior) => prior.contract.budget[key] ?? 200000),
                ), "revision broadened task budget");
          };
          let expected;
          let retired = graph.retired;
          if (operation.kind === "add-prerequisite") {
            require(!originals[0].dependsOn.includes(
              operation.prerequisite,
            ), "unchanged dependency revision");
            expected = graph.nodes.map((node) =>
              node.id === operation.taskId
                ? { ...node, dependsOn: [...new Set([...node.dependsOn, operation.prerequisite])] }
                : node,
            );
          } else if (operation.kind === "amend-scope") {
            const owner = originals[0];
            const scope = graph.scope;
            require(scope &&
              owner.contract.scopeAuthority === "controller" &&
              owner.contract.scopeKind !==
                "workspace", "task scope has no controller amendment authority");
            require(Array.isArray(operation.paths) &&
              operation.paths.length > 0 &&
              operation.paths.length <= 128 &&
              unique(operation.paths) &&
              operation.paths.every(canonicalPath) &&
              operation.paths.some(
                (path) => !owner.contract.allowedPaths.includes(path),
              ), "scope amendment is malformed or unchanged");
            require(operation.paths.every(
              (path) =>
                (scope.kind === "workspace" || scope.allowedPaths.includes(path)) &&
                ![...scope.immutablePaths, ...owner.contract.immutablePaths].some((immutable) =>
                  protectedPath(immutable, path),
                ),
            ), "scope amendment exceeds pinned authority");
            expected = graph.nodes.map((node) =>
              node.id === operation.taskId
                ? {
                    ...node,
                    contract: {
                      ...node.contract,
                      allowedPaths: [
                        ...new Set([...node.contract.allowedPaths, ...operation.paths]),
                      ].sort(),
                    },
                  }
                : node,
            );
          } else if (operation.kind === "insert-prerequisite") {
            const owner = originals[0];
            const node = operation.node;
            require(node &&
              !graph.nodes.some((prior) => prior.id === node.id) &&
              !graph.retired.includes(node.id), "prerequisite identity was reused");
            require(equal(
              [...node.obligations].sort(),
              [...owner.obligations].sort(),
            ), "new prerequisite erased the requesting task's obligations");
            within(node.contract, originals);
            expected = [
              ...graph.nodes.map((prior) =>
                prior.id === operation.taskId
                  ? { ...prior, dependsOn: [...prior.dependsOn, node.id] }
                  : prior,
              ),
              { ...node, dependsOn: [...new Set([...owner.dependsOn, ...node.dependsOn])] },
            ];
          } else {
            require(originals.every(
              (node) => !["running", "candidate"].includes(states.get(node.id)),
            ), "revision replaced active ownership");
            require(operation.kind !== "split" ||
              states.get(operation.taskId) === "pending", "only pending work may be split");
            const replacements =
              operation.kind === "split"
                ? operation.parts
                : operation.kind === "combine"
                  ? [operation.combined]
                  : [operation.replacement];
            require(replacements.length >= (operation.kind === "split" ? 2 : 1) &&
              replacements.length <= 8, "replacement count is invalid");
            require(equal(
              [...new Set(replacements.flatMap((node) => node.obligations))].sort(),
              [...new Set(originals.flatMap((node) => node.obligations))].sort(),
            ), "replacement erased task obligations");
            for (const node of replacements) {
              require(!graph.retired.includes(node.id) &&
                !graph.nodes.some(
                  (prior) => prior.id === node.id,
                ), "replacement reused an identity");
              within(node.contract, originals);
            }
            const inherited = [
              ...new Set(
                originals.flatMap((node) => node.dependsOn).filter((id) => !removed.includes(id)),
              ),
            ];
            expected = [
              ...graph.nodes
                .filter((node) => !removed.includes(node.id))
                .map((node) => ({
                  ...node,
                  dependsOn: [
                    ...new Set(
                      node.dependsOn.flatMap((id) =>
                        removed.includes(id)
                          ? replacements.map((replacement) => replacement.id)
                          : [id],
                      ),
                    ),
                  ],
                })),
              ...replacements.map((node) => ({
                ...node,
                dependsOn: [...new Set([...node.dependsOn, ...inherited])],
              })),
            ];
            retired = [...retired, ...removed];
          }
          expected = expected.map((node) => ({
            ...node,
            contract: {
              ...node.contract,
              dependsOn: node.dependsOn.map(
                (id) => expected.find((dependency) => dependency.id === id)?.contract.taskId ?? id,
              ),
            },
          }));
          const affected = new Set([
            ...removed,
            ...expected
              .filter((node) => !graph.nodes.some((prior) => prior.id === node.id))
              .map((node) => node.id),
          ]);
          let width;
          do {
            width = affected.size;
            for (const node of expected)
              if (node.dependsOn.some((id) => affected.has(id))) affected.add(node.id);
          } while (width !== affected.size);
          require(equal(observed.nodes, expected) &&
            equal(observed.retired, retired) &&
            equal(
              observed.affected,
              [...affected].sort(),
            ), "revision content does not follow from its declared operation");
        }
        for (const id of observed.affected) {
          accepted.delete(id);
          if (!["running", "candidate"].includes(states.get(id))) states.set(id, "pending");
        }
        for (const node of observed.nodes) if (!states.has(node.id)) states.set(node.id, "pending");
        for (const id of observed.retired) states.set(id, "blocked");
        graph = observed;
        graphs.push(observed);
        continue;
      }
      require(graph !== null, "controller effect precedes graph declaration");
      if (entry.type === "controller-candidate") {
        const intent = dispatches.get(observed.workerId);
        require(intent &&
          !candidates.has(observed.workerId) &&
          ["taskId", "baseCommit", "graphRevision", "branch", "sessionId"].every(
            (key) => intent[key] === observed[key],
          ), "candidate is not bound to one dispatch");
        candidates.set(observed.workerId, observed);
        if (current(observed))
          states.set(
            observed.taskId,
            observed.green && observed.commit !== null ? "candidate" : "failed",
          );
        continue;
      }
      switch (observed.kind) {
        case "integration-resource":
          require(resource === null ||
            (resource.path === observed.path &&
              resource.branch === observed.branch), "integration resource identity changed");
          require(observed.phase !== "created" ||
            resource?.phase === "create-intent", "integration resource lacks creation intent");
          require(observed.phase !== "removed" ||
            resource?.phase === "cleanup-intent", "integration resource lacks cleanup intent");
          resource = observed;
          break;
        case "integration-abandoned": {
          const intent = integrations.get(observed.effectId);
          require(intent &&
            !completed.has(observed.effectId), "abandoned integration lacks its unresolved intent");
          completed.add(observed.effectId);
          states.set(intent.taskId, "candidate");
          head = intent.baseCommit;
          break;
        }
        case "dispatch-intent": {
          const node = graph.nodes.find((node) => node.id === observed.taskId);
          require(node &&
            !dispatches.has(observed.workerId) &&
            graph.revision === observed.graphRevision &&
            states.get(node.id) !== "accepted" &&
            node.dependsOn.every(
              (id) => states.get(id) === "accepted",
            ), "dispatch is duplicate, stale or lacks accepted prerequisites");
          dispatches.set(observed.workerId, observed);
          states.set(node.id, "running");
          break;
        }
        case "integration-intent": {
          const candidate = candidates.get(observed.workerId);
          require(candidate?.green &&
            current(candidate) &&
            candidate.taskId === observed.taskId &&
            candidate.commit === observed.candidateCommit &&
            candidate.branch === observed.branch &&
            !stale.has(observed.workerId) &&
            !accepted.has(observed.taskId) &&
            observed.graphRevision === graph.revision &&
            !integrations.has(observed.effectId) &&
            [...integrations.keys()].every((id) =>
              completed.has(id),
            ), "integration lacks a current eligible candidate");
          require(head === null ||
            head === observed.baseCommit, "integration skipped the actual accepted head");
          integrations.set(observed.effectId, observed);
          integrationOrder.set(observed.effectId, entry.sequence);
          head = observed.baseCommit;
          break;
        }
        case "integration-completed": {
          const intent = integrations.get(observed.effectId);
          const capture = records.find(
            (record) =>
              record.sequence < entry.sequence &&
              record.sequence > (integrationOrder.get(observed.effectId) ?? Infinity) &&
              record.actor === "harness" &&
              record.type === "merge-attempt" &&
              record.payloadDigest === observed.observation,
          );
          const merge = payloads.get(capture?.payloadDigest);
          require(intent &&
            !completed.has(observed.effectId) &&
            merge?.workerId === intent.workerId &&
            merge?.landed === observed.landed &&
            merge?.commit ===
              observed.commit, "integration completion lacks a unique captured merge");
          completed.add(observed.effectId);
          if (observed.landed) {
            require(observed.commit !== null &&
              intent.graphRevision ===
                graph.revision, "accepted integration is stale or has no commit");
            accepted.set(intent.taskId, {
              workerId: intent.workerId,
              commit: observed.commit,
              graphRevision: intent.graphRevision,
            });
            states.set(intent.taskId, "accepted");
            head = observed.commit;
          } else states.set(intent.taskId, "failed");
          break;
        }
        case "candidate-refused": {
          const candidate = candidates.get(observed.workerId);
          const capture = records.find(
            (record) =>
              record.sequence < entry.sequence &&
              record.actor === "harness" &&
              record.type === "goal-candidate-verification" &&
              record.payloadDigest === observed.observation,
          );
          const reading = payloads.get(capture?.payloadDigest);
          require(candidate &&
            reading?.workerId === candidate.workerId &&
            (reading.verification?.verified === false ||
              reading.verification?.checks?.some((check) => check.status === "failed")) &&
            !accepted.has(candidate.taskId), "candidate refusal lacks independent failure");
          states.set(candidate.taskId, "failed");
          break;
        }
        case "candidate-stale": {
          const candidate = candidates.get(observed.workerId);
          require(candidate &&
            graph.revision ===
              observed.currentRevision, "stale candidate observation lacks its candidate");
          stale.add(observed.workerId);
          if (!accepted.has(candidate.taskId)) states.set(candidate.taskId, "pending");
          break;
        }
        case "task-reopened":
          require(states.has(observed.taskId) &&
            !accepted.has(observed.taskId), "reopening duplicates accepted work");
          states.set(observed.taskId, "pending");
          break;
        case "task-blocked":
          require(states.has(observed.taskId) &&
            !accepted.has(observed.taskId), "blocking cannot erase acceptance");
          states.set(observed.taskId, "blocked");
          break;
        case "cleanup-intent":
        case "cleanup-completed":
        case "worktree-created": {
          const intent = dispatches.get(observed.workerId);
          require(intent &&
            intent.path === observed.path &&
            intent.branch ===
              observed.branch, "cleanup or worktree observation names an unowned resource");
          if (observed.kind === "worktree-created")
            require(intent.baseCommit === observed.baseCommit, "worktree base changed");
          if (observed.kind === "cleanup-intent") cleanup.add(observed.workerId);
          if (observed.kind === "cleanup-completed") {
            require(cleanup.has(observed.workerId) &&
              !cleaned.has(observed.workerId), "cleanup completion lacks one prior intent");
            cleaned.add(observed.workerId);
          }
          break;
        }
        case "coordination-consumed":
          break;
        case "recovery-commit-intent":
          require(dispatches.get(observed.workerId)?.branch ===
            observed.branch, "recovery commit is not owned");
          break;
        case "recovery-reset-intent":
          require(integrations.get(observed.effectId)?.baseCommit === observed.targetCommit &&
            !completed.has(
              observed.effectId,
            ), "recovery reset lacks its unresolved integration and original base");
          break;
        case "recovery-ref-intent":
          require(integrations.has(observed.effectId) &&
            !completed.has(
              observed.effectId,
            ), "recovery reference lacks an unresolved integration");
          break;
        case "dispatch-reconciled":
          require(dispatches.has(observed.workerId) &&
            !reconciled.has(
              observed.workerId,
            ), "reconciliation lacks one unreconciled dispatch intent");
          reconciled.add(observed.workerId);
          if (
            observed.disposition === "not-started" &&
            !accepted.has(dispatches.get(observed.workerId).taskId)
          )
            states.set(dispatches.get(observed.workerId).taskId, "pending");
          break;
        default:
          throw new Error(`unknown controller transition ${observed.kind}`);
      }
    }
  } catch (cause) {
    problems.push(cause instanceof Error ? cause.message : String(cause));
  }
  return { graph, states, accepted, head, problems };
}

/** Bootstrap observations are interpreted here independently of the producer's schema and rule. */
function bootstrapProblems(records, payloads) {
  const problems = [];
  try {
    const insist = (holds, reason) => {
      if (!holds) throw new Error(`bootstrap: ${reason}`);
    };
    const launches = records.filter((record) => record.type === "controller-launch");
    const launch = payloads.get(launches[0]?.payloadDigest)?.spec;
    const stages = records.filter((record) => record.type === "bootstrap-stage");
    if (launch?.bootstrap === undefined && stages.length === 0) return [];
    insist(
      launches.length === 1 &&
        launches[0].actor === "harness" &&
        launch.version === 3 &&
        launch.bootstrap === "node" &&
        launch.controllerScope?.kind === "workspace" &&
        launch.goal !== null,
      "requires one authorized version-three goal launch",
    );
    const expectedFiles = {
      ".gitignore": "node_modules/\ncoverage/\n",
      "package.json": `${JSON.stringify({ private: true, type: "module", engines: { node: ">=24" }, scripts: { test: "node --test" } }, null, 2)}\n`,
    };
    let intent = null;
    let ready = null;
    let cleaning = false;
    const calls = new Map();
    const observations = new Map();
    const settled = new Set();
    for (const record of records) {
      const payload = payloads.get(record.payloadDigest);
      if (record.type === "bootstrap-stage") {
        insist(
          record.actor === "harness" && payload !== undefined,
          "requires harness observations",
        );
        if (payload.phase === "intent") {
          insist(
            intent === null &&
              record.sequence > launches[0].sequence &&
              payload.version === 1 &&
              payload.language === "node" &&
              payload.baseCommit === launch.baseCommit &&
              payload.timestamp === 0 &&
              payload.ref === `refs/swarm-bootstrap/${launch.runId}` &&
              payload.workspace === `${launch.scratchRoot}/bootstrap` &&
              equal(payload.files, expectedFiles),
            "intent changed the authorized setup",
          );
          const algorithm = launch.baseCommit.length === 40 ? "sha1" : "sha256";
          const object = (kind, bytes) =>
            createHash(algorithm).update(`${kind} ${bytes.length}\0`).update(bytes).digest("hex");
          const treeBytes = Buffer.concat(
            Object.entries(expectedFiles).map(([path, bytes]) =>
              Buffer.concat([
                Buffer.from(`100644 ${path}\0`),
                Buffer.from(object("blob", Buffer.from(bytes)), "hex"),
              ]),
            ),
          );
          const tree = object("tree", treeBytes);
          const who = "Swarm Orchestrator <swarm@localhost> 0 +0000";
          const commit = object(
            "commit",
            Buffer.from(
              `tree ${tree}\nparent ${launch.baseCommit}\nauthor ${who}\ncommitter ${who}\n\nEstablish Node 24 bootstrap harness\n`,
            ),
          );
          insist(
            payload.tree === tree && payload.commit === commit,
            "setup commit does not describe its recorded objects",
          );
          intent = payload;
        } else {
          insist(intent !== null, "effect preceded its intent");
          if (payload.phase === "check-intent") {
            const attempt =
              [...calls.values()].filter((call) => call.check === payload.check).length + 1;
            insist(
              ready === null &&
                ["toolchain", "positive", "negative"].includes(payload.check) &&
                attempt <= 3 &&
                payload.id === `${payload.check}-${attempt}` &&
                !calls.has(payload.id),
              "invalid check identity, retry or order",
            );
            const backend =
              launch.isolation === null
                ? "host"
                : `${launch.isolation.runtime}:${launch.isolation.image}`;
            const fixtures =
              payload.check === "toolchain"
                ? expectedFiles
                : {
                    ...expectedFiles,
                    "control.test.js": `import {test} from 'node:test'; import assert from 'node:assert/strict'; test('bootstrap-${payload.check}',()=>assert.equal(1,${payload.check === "positive" ? 1 : 2}));\n`,
                  };
            insist(
              payload.backend === backend && equal(payload.files, fixtures),
              "check changed its backend or controls",
            );
            insist(
              payload.check === "toolchain"
                ? typeof payload.argv?.[0] === "string" &&
                    equal(payload.argv.slice(1), [
                      "-e",
                      "process.stdout.write(process.versions.node); if(Number(process.versions.node.split('.')[0])<24) process.exitCode=1",
                    ])
                : equal(payload.argv, ["npm", "test", "--", "--test-reporter=tap"]),
              "check command differs from its declared instrument",
            );
            calls.set(payload.id, payload);
          } else if (payload.phase === "check-observed") {
            const call = calls.get(payload.id);
            insist(
              call !== undefined && !settled.has(payload.id) && ready === null,
              "observation lacks its unique preceding call",
            );
            settled.add(payload.id);
            const seen = payload.observation;
            const complete =
              seen?.cancelled === false &&
              seen.timedOut === false &&
              seen.truncated === false &&
              seen.startFailure === null &&
              typeof seen.stdout === "string";
            let held = false;
            if (complete && call.check === "toolchain")
              held =
                seen.exitCode === 0 &&
                /^\d+\.\d+\.\d+$/.test(seen.stdout) &&
                Number(seen.stdout.split(".")[0]) >= 24;
            if (complete && call.check !== "toolchain") {
              const failure = call.check === "negative";
              held =
                seen.exitCode === (failure ? 1 : 0) &&
                seen.stdout
                  .split("\n")
                  .includes(`${failure ? "not ok" : "ok"} 1 - bootstrap-${call.check}`) &&
                seen.stdout.split("\n").includes("# tests 1") &&
                seen.stdout.split("\n").includes(`# fail ${failure ? 1 : 0}`);
            }
            observations.set(record.payloadDigest, { check: call.check, held });
          } else if (payload.phase === "ready") {
            insist(
              ready === null &&
                payload.commit === intent.commit &&
                payload.tree === intent.tree &&
                Array.isArray(payload.checks) &&
                payload.checks.length === 3 &&
                payload.checks.every((digest, index) => {
                  const seen = observations.get(digest);
                  return (
                    seen?.held === true &&
                    seen.check === ["toolchain", "positive", "negative"][index]
                  );
                }),
              "readiness lacks the exact toolchain and both controls",
            );
            ready = payload;
          } else if (payload.phase === "cleanup-intent") cleaning = true;
          else if (payload.phase === "cleanup-completed") {
            insist(cleaning, "cleanup has no intent");
            cleaning = false;
          } else insist(false, "unknown stage phase");
        }
      }
      if (record.type === "controller-configuration")
        insist(
          ready !== null && payload?.spec?.baseCommit === ready.commit,
          "dispatch base was not established by the setup",
        );
      if (record.type === "controller-event" && payload?.kind === "usage-reserved")
        insist(ready !== null, "model activity preceded setup acceptance");
      if (record.type === "goal-contract")
        insist(ready !== null, "goal checks were pinned before setup acceptance");
    }
  } catch (cause) {
    problems.push(cause instanceof Error ? cause.message : String(cause));
  }
  return problems;
}

return readControllerHistory;})();
const capturedRegression = (() => {

function sortedJson(value) {
  return JSON.stringify(value, (_key, inner) =>
    inner !== null && typeof inner === "object" && !Array.isArray(inner)
      ? Object.fromEntries(Object.entries(inner).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)))
      : inner,
  );
}

/**
 * What makes a recorded instrument untrusted (instrument-identity-v1). Mirrors
 * `instrumentChanges` in src/gates/instrument-identity.ts, written again here so the decision a
 * record carries is re-derived from the digests it recorded rather than taken from the run. The
 * closure itself was followed by the harness; this checks what follows from what it recorded.
 */
function instrumentChanges(instrument) {
  if (
    instrument === null ||
    typeof instrument !== "object" ||
    instrument.rule !== "instrument-identity-v1"
  )
    return ["instrument record under an unknown rule"];
  const changed = [];
  for (const file of instrument.files ?? [])
    if (file.reference !== file.current) changed.push(file.path);
  for (const dependency of instrument.dependencies ?? [])
    if (
      dependency.reference !== dependency.current &&
      dependency.currentSource !== "registry" &&
      dependency.currentSource !== "absent"
    )
      changed.push(`dependency ${dependency.name}`);
  for (const runner of instrument.installed ?? []) {
    if (runner.found === null) continue;
    if (runner.expected !== null && runner.found !== runner.expected)
      changed.push(`installed ${runner.name} ${runner.found} (lockfile ${runner.expected})`);
    if (!runner.linked) changed.push(`installed ${runner.name} executable link`);
  }
  if (instrument.complete !== true) changed.push("instrument closure not followed to its end");
  if (instrument.before !== undefined) {
    const { before: _before, ...rest } = instrument;
    const now = `sha256:${createHash("sha256").update(sortedJson(rest)).digest("hex")}`;
    if (now !== instrument.before) changed.push("the instrument changed while the check ran");
  }
  return changed;
}

function notApplicable(observation) {
  if (observation.unavailable !== null && observation.unavailable !== undefined)
    return "not-applicable";
  if (observation.exitCode === 127) return "not-applicable";
  return null;
}

function counter(text, name) {
  // nosemgrep: javascript.lang.security.audit.detect-non-literal-regexp.detect-non-literal-regexp - name is one of the counter names this file calls with, never input. Mirrors src/gates/parsers.ts.
  const found = new RegExp(`^[#ℹ]\\s+${name}\\s+(\\d+)\\s*$`, "m").exec(text)?.[1];
  return found === undefined ? null : Number(found);
}

/**
 * The status the named parser rule reads out of an observation. Mirrors src/gates/parsers.ts
 * and src/gates/default-gates.ts, rule for rule; the parity test in that tree holds the two
 * to each other.
 */
function readStatus(parser, observation) {
  const status = readParsedStatus(parser, observation);
  // A pass reported under an instrument the change altered is the project's report, not evidence.
  if (
    status === "passed" &&
    observation.instrument !== undefined &&
    instrumentChanges(observation.instrument).length > 0
  )
    return "not-applicable";
  return status;
}

function readParsedStatus(parser, observation) {
  const unavailable = notApplicable(observation);
  if (unavailable !== null) return unavailable;
  const stdout = observation.stdout ?? "";
  const stderr = observation.stderr ?? "";
  switch (parser) {
    case "exit-code":
      return observation.exitCode === 0 ? "passed" : "failed";
    case "no-output":
      if (observation.exitCode !== 0) return "failed";
      return stdout.trim().length === 0 ? "passed" : "failed";
    case "inspection":
      try {
        JSON.parse(stdout);
      } catch {
        return "failed";
      }
      return observation.exitCode === 0 ? "passed" : "failed";
    case "structured-test-output":
      return structuredTestStatus(observation);
    case "test-output": {
      if (stdout.trimStart().startsWith("{")) return structuredTestStatus(observation);
      const text = `${stdout}\n${stderr}`;
      if (/^TAP version \d+/m.test(text) || counter(text, "tests") !== null) {
        const plan = /^\s*1\.\.(\d+)\s*$/m.exec(text)?.[1];
        const tests = counter(text, "tests") ?? (plan === undefined ? null : Number(plan));
        const fail = counter(text, "fail");
        const failed = observation.exitCode !== 0 || (fail ?? 0) > 0;
        const pass = counter(text, "pass");
        const executed =
          pass ??
          (tests === null
            ? null
            : tests - (counter(text, "skipped") ?? 0) - (counter(text, "todo") ?? 0));
        if (!failed && (tests === 0 || executed === 0)) return "not-applicable";
        return failed ? "failed" : "passed";
      }
      const summary = /^\s*Tests\s+(.+?)\s*$/m.exec(text)?.[1] ?? "";
      if (/\(\d+\)/.test(summary)) {
        const failedCount = /(\d+)\s+failed/.exec(summary)?.[1];
        const failed = observation.exitCode !== 0 || Number(failedCount ?? 0) > 0;
        return failed ? "failed" : "passed";
      }
      return observation.exitCode === 0 ? "passed" : "failed";
    }
    default:
      return null;
  }
}

/**
 * The per-test outcomes of a structured report, or null where it is not a complete one. A title
 * repeated in one file is named by its occurrence, as src/gates/runner-results.ts names it.
 */
function structuredPoints(observation) {
  if (observation.outputTruncated || (observation.stdout ?? "").length > 4000000) return null;
  try {
    const report = JSON.parse(observation.stdout);
    let tests;
    if (report.schema === "swarm.pytest.v1") {
      if (!Array.isArray(report.tests) || report.tests.length > 100000) return null;
      tests = report.tests.map((test) => ({
        id: test.id,
        status: test.status,
        identity: test.id,
        cause: typeof test.message === "string" ? test.message : "",
      }));
    } else {
      for (const field of ["numTotalTests", "numPassedTests", "numFailedTests", "numPendingTests"])
        if (!Number.isInteger(report[field]) || report[field] < 0) return null;
      tests = report.testResults.flatMap((file) => {
        if (typeof file.name !== "string") throw new Error("file absent");
        const seen = new Map();
        return file.assertionResults.map((test) => {
          if (
            typeof test.fullName !== "string" ||
            !["passed", "failed", "pending", "skipped", "todo"].includes(test.status)
          )
            throw new Error("invalid point");
          const count = (seen.get(test.fullName) ?? 0) + 1;
          seen.set(test.fullName, count);
          return {
            id: `${file.name}:${test.fullName}${count === 1 ? "" : `#${count}`}`,
            identity: `${file.name}:${test.fullName}`,
            cause: Array.isArray(test.failureMessages) ? test.failureMessages.join("\n") : "",
            status: ["passed", "failed"].includes(test.status) ? test.status : "skipped",
          };
        });
      });
      if (
        report.numTotalTests !== tests.length ||
        report.numPassedTests !== tests.filter((test) => test.status === "passed").length ||
        report.numFailedTests !== tests.filter((test) => test.status === "failed").length ||
        report.numPendingTests !== tests.filter((test) => test.status === "skipped").length
      )
        return null;
    }
    if (
      tests.some(
        (test) =>
          typeof test.id !== "string" ||
          !test.id ||
          !["passed", "failed", "skipped", "error"].includes(test.status),
      ) ||
      new Set(tests.map((test) => test.id)).size !== tests.length
    )
      return null;
    return tests;
  } catch {
    return null;
  }
}

/** Structured results carry outcomes, never extra ratchet authority. */
function structuredTestStatus(observation) {
  const tests = structuredPoints(observation);
  if (tests === null)
    return observation.outputTruncated || (observation.stdout ?? "").length > 4000000
      ? "not-applicable"
      : observation.exitCode === 0
        ? "not-applicable"
        : "failed";
  const executed = tests.filter((test) => test.status !== "skipped");
  if (!executed.length) return "not-applicable";
  return observation.exitCode !== 0 || executed.some((test) => test.status !== "passed")
    ? "failed"
    : "passed";
}

/**
 * The tests a run names as failed and passed, under the title-only identity records were
 * attributed with through 1.0.7 (failure-identity v1). Kept so those records re-derive under the
 * rule that wrote them; it is not a rule new records are judged by, and an inheritance it proves
 * is not re-established by it (SV-24).
 */
function namedTestsV1(observation) {
  const stdout = observation.stdout ?? "";
  if (stdout.trimStart().startsWith("{")) {
    const points = structuredPoints(observation);
    if (points === null) return null;
    return {
      failed: points.filter((p) => p.status === "failed" || p.status === "error").map((p) => p.id),
      passed: points.filter((p) => p.status === "passed").map((p) => p.id),
    };
  }
  const text = `${stdout}\n${observation.stderr ?? ""}`;
  if (!/^TAP version \d+/m.test(text)) {
    const plain = stripColour(text);
    const summary = /^\s*Test Files\s+(.+)$/m.exec(plain)?.[1];
    if (summary === undefined) return null;
    const failed = [];
    for (const line of plain.split("\n")) {
      const named = /^\s*FAIL\s+(\S.*?)\s*$/.exec(line)?.[1];
      if (named && !failed.includes(named)) failed.push(named);
    }
    if (failed.length === 0 && /\d+\s+failed/.test(summary)) return null;
    return { failed, passed: [] };
  }
  const failed = [];
  const passed = [];
  for (const line of text.split("\n")) {
    const point = /^(\s*)(not ok|ok)\s+\d+\s+-\s+(.+?)\s*$/.exec(line);
    if (point === null) continue;
    if (/#\s*(TODO|SKIP)\b/i.test(point[3])) continue;
    const id = `${point[1].length}:${point[3].replace(/\s+#.*$/, "")}`;
    (point[2] === "ok" ? passed : failed).push(id);
  }
  return { failed, passed };
}

const escapeCharacter = String.fromCharCode(27);

function stripColour(text) {
  return text
    .split(escapeCharacter)
    .map((part, index) => (index === 0 ? part : part.replace(/^\[[0-9;]*[A-Za-z]/, "")))
    .join("");
}

function cause(text) {
  return stripColour(text)
    .replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?/g, "<timestamp>")
    .replace(/\b\d+(?:\.\d+)?\s?(?:ms|s|sec|secs|seconds)\b/g, "<duration>")
    .trim()
    .slice(0, 2000);
}

/** The directory every TAP failure location in the texts shares. */
function locationRoot(texts) {
  const files = [];
  for (const text of texts)
    for (const line of text.split("\n")) {
      const found = /^\s*location:\s*'([^']+)'\s*$/.exec(line)?.[1];
      if (found !== undefined) files.push(found.replace(/^file:\/\//, "").replace(/:\d+:\d+$/, ""));
    }
  if (files.length === 0) return "";
  let shared = files[0].split("/").slice(0, -1);
  for (const file of files.slice(1)) {
    const parts = file.split("/").slice(0, -1);
    let length = 0;
    while (length < shared.length && shared[length] === parts[length]) length++;
    shared = shared.slice(0, length);
  }
  return shared.length === 0 ? "" : `${shared.join("/")}/`;
}

const causeFields = ["failureType", "error", "code", "name", "expected", "actual", "operator"];

/** Node's TAP read under failure-identity v2: a failure named by its location, depth and title. */
function tapTests(text, truncated, root) {
  const lines = text.split("\n");
  const failed = [];
  const passed = [];
  const causes = {};
  let leafFailures = 0;
  for (let index = 0; index < lines.length; index++) {
    const point = /^(\s*)(not ok|ok)\s+\d+\s+-\s+(.+?)\s*$/.exec(lines[index]);
    if (point === null) continue;
    if (/#\s*(TODO|SKIP)\b/i.test(point[3])) continue;
    const depth = point[1].length;
    const title = point[3].replace(/\s+#.*$/, "");
    const yaml = [];
    if (/^\s*---\s*$/.test(lines[index + 1] ?? ""))
      for (
        let inner = index + 2;
        inner < lines.length && !/^\s*\.\.\.\s*$/.test(lines[inner]);
        inner++
      )
        yaml.push(lines[inner]);
    if (point[2] === "ok") {
      passed.push(`${depth}:${title}`);
      continue;
    }
    let location = null;
    let type = null;
    const kept = [];
    let block = null;
    // Keys sit two spaces inside the point; deeper lines belong to the key above them.
    const inner = " ".repeat(depth + 2);
    for (const line of yaml) {
      const key =
        line.startsWith(inner) && line[inner.length] !== " "
          ? /^(\w+):\s*(.*)$/.exec(line.slice(inner.length))
          : null;
      if (key !== null) block = key[1];
      const value = key === null ? null : key[2].replace(/^'(.*)'$/, "$1");
      if (key !== null && key[1] === "location" && location === null)
        location = value.replace(/^file:\/\//, "");
      if (key !== null && key[1] === "type" && type === null) type = value;
      if (block !== null && causeFields.includes(block)) kept.push(line.trim());
    }
    if (type !== "suite") leafFailures++;
    const relative =
      location !== null && root.length > 0 && location.startsWith(root)
        ? location.slice(root.length)
        : location;
    const id = relative === null ? `${depth}:${title}` : `${relative} › ${depth}:${title}`;
    failed.push(id);
    causes[id] = cause(kept.join("\n"));
  }
  const counter = (name) => {
    for (const line of lines) {
      const match = /^[#ℹ]\s+(\w+)\s+(\d+)\s*$/.exec(line);
      if (match !== null && match[1] === name) return Number(match[2]);
    }
    return null;
  };
  const fail = counter("fail");
  const complete =
    !truncated &&
    lines.some((line) => /^1\.\.\d+\s*$/.test(line)) &&
    (counter("cancelled") ?? 0) === 0 &&
    (fail === null || fail === leafFailures);
  return { failed, passed, causes, complete };
}

/** Node's spec reporter under failure-identity v2. Mirrors `specPoints` in failure-attribution.ts. */
function specTests(raw, truncated) {
  const lines = stripColour(raw).split("\n");
  const passed = [];
  const failed = [];
  const causes = {};
  const summary = lines.findIndex((line) => /^\u2716 failing tests:\s*$/.test(line));
  for (let index = 0; index < lines.length; index++) {
    if (summary !== -1 && index >= summary) break;
    const pass = /^(\s*)\u2714 (.+?) \(\d+(?:\.\d+)?ms\)\s*$/.exec(lines[index]);
    if (pass !== null) passed.push(`${pass[1].length}:${pass[2]}`);
  }
  if (summary !== -1)
    for (let index = summary + 1; index < lines.length; index++) {
      const location = /^test at (.+:\d+:\d+)\s*$/.exec(lines[index])?.[1];
      const title = /^\s*\u2716 (.+?) \(\d+(?:\.\d+)?ms\)\s*$/.exec(lines[index + 1] ?? "")?.[1];
      if (location === undefined || title === undefined) continue;
      const kept = [];
      for (let inner = index + 2; inner < lines.length; inner++) {
        if (/^test at /.test(lines[inner])) break;
        if (/^\s+at /.test(lines[inner]) || lines[inner].trim().length === 0) continue;
        kept.push(lines[inner].trim());
      }
      const id = `${location} \u203a 0:${title}`;
      failed.push(id);
      causes[id] = cause(kept.join("\n"));
    }
  const count = (name) => {
    for (const line of lines) {
      const match = /^\u2139\s+(\w+)\s+(\d+)\s*$/.exec(line);
      if (match !== null && match[1] === name) return Number(match[2]);
    }
    return null;
  };
  const fail = count("fail");
  return {
    failed,
    passed,
    causes,
    complete:
      !truncated && fail !== null && fail === failed.length && (count("cancelled") ?? 0) === 0,
  };
}

/** A run's tests under failure-identity v2, or null where it names none. */
function namedTestsV2(observation, sharedRoot) {
  const stdout = observation.stdout ?? "";
  const root = sharedRoot ?? locationRoot([`${stdout}\n${observation.stderr ?? ""}`]);
  if (stdout.trimStart().startsWith("{")) {
    const points = structuredPoints(observation);
    if (points === null) return null;
    const failing = points.filter((p) => p.status === "failed" || p.status === "error");
    const causes = {};
    for (const p of failing) causes[p.identity] = cause(p.cause ?? "");
    return {
      failed: failing.map((p) => p.identity),
      passed: points.filter((p) => p.status === "passed").map((p) => p.identity),
      causes,
      complete: true,
    };
  }
  const text = `${stdout}\n${observation.stderr ?? ""}`;
  if (/^TAP version \d+/m.test(text))
    return tapTests(text, observation.outputTruncated === true, root);
  if (/^\u2716 failing tests:\s*$/m.test(text) || /^\u2139\s+tests\s+\d+\s*$/m.test(text))
    return specTests(text, observation.outputTruncated === true);
  const plain = stripColour(text);
  const summary = /^\s*Test Files\s+(.+)$/m.exec(plain)?.[1];
  if (summary === undefined) return null;
  const lines = plain.split("\n");
  const failed = [];
  const causes = {};
  for (let index = 0; index < lines.length; index++) {
    const named = /^\s*FAIL\s+(\S.*?)\s*$/.exec(lines[index])?.[1];
    if (!named) continue;
    failed.push(named);
    const next = lines.slice(index + 1).find((line) => line.trim().length > 0) ?? "";
    causes[named] = /^\s*FAIL\s/.test(next) ? "" : cause(next);
  }
  if (failed.length === 0 && /\d+\s+failed/.test(summary)) return null;
  const counted = /(\d+)\s+failed/.exec(/^\s*Tests\s+(.+)$/m.exec(plain)?.[1] ?? "")?.[1];
  return {
    failed,
    passed: [],
    causes,
    complete: counted === undefined || Number(counted) <= failed.length,
  };
}

function comparableOutput(observation) {
  return stripColour(
    `${observation.exitCode}\n${observation.stdout ?? ""}\n${observation.stderr ?? ""}`,
  )
    .replace(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?/g, "<timestamp>")
    .replace(/\b\d{1,2}:\d{2}:\d{2}(?:\.\d+)?\b/g, "<clock>")
    .replace(/\b\d+(?:\.\d+)?\s?(?:ms|s|sec|secs|seconds|m|min)\b/g, "<duration>")
    .split("\n")
    .map((line) => line.replace(/\s+$/, ""))
    .join("\n");
}

/** Why a failed reading failed under v1: title identities, as sets. */
function attributionV1(failing, parser, baseObservation) {
  if (baseObservation === undefined || readStatus(parser, baseObservation) !== "failed")
    return { attribution: "new", newFailures: [] };
  const patched = namedTestsV1(failing);
  const base = namedTestsV1(baseObservation);
  if (patched !== null && base !== null && patched.failed.length > 0) {
    const newFailures = patched.failed.filter((id) => !base.failed.includes(id));
    return newFailures.length === 0
      ? { attribution: "inherited", newFailures: [] }
      : { attribution: "new", newFailures };
  }
  return comparableOutput(failing) === comparableOutput(baseObservation)
    ? { attribution: "inherited", newFailures: [] }
    : { attribution: "unattributed", newFailures: [] };
}

function tally(ids) {
  const found = new Map();
  for (const id of ids) found.set(id, (found.get(id) ?? 0) + 1);
  return found;
}

/**
 * Why a failed reading failed under failure-identity v2: identities that tell same-titled tests
 * apart, counted, with their causes, from two complete runs. Mirrors `attributeFailure` in
 * src/gates/failure-attribution.ts.
 */
function attributionV2(failing, parser, baseObservation) {
  if (baseObservation === undefined || readStatus(parser, baseObservation) !== "failed")
    return { attribution: "new", newFailures: [] };
  if (failing.outputTruncated === true || baseObservation.outputTruncated === true)
    return { attribution: "unattributed", newFailures: [] };
  const texts = [failing, baseObservation].map((one) => `${one.stdout ?? ""}\n${one.stderr ?? ""}`);
  const root = texts.every((text) => /^TAP version \d+/m.test(text)) ? locationRoot(texts) : "";
  const patched = namedTestsV2(failing, root);
  const base = namedTestsV2(baseObservation, root);
  if (patched !== null && base !== null && patched.failed.length > 0) {
    const before = tally(base.failed);
    const after = tally(patched.failed);
    const newFailures = [...after]
      .filter(([id, count]) => count > (before.get(id) ?? 0))
      .map(([id]) => id)
      .sort();
    if (newFailures.length > 0) return { attribution: "new", newFailures };
    const repeated = [...after, ...before].some(([, count]) => count > 1);
    const changed = [...after.keys()].some((id) => patched.causes[id] !== base.causes[id]);
    return patched.complete && base.complete && !repeated && !changed
      ? { attribution: "inherited", newFailures: [] }
      : { attribution: "unattributed", newFailures: [] };
  }
  if (patched !== null || base !== null) return { attribution: "unattributed", newFailures: [] };
  return comparableOutput(failing) === comparableOutput(baseObservation)
    ? { attribution: "inherited", newFailures: [] }
    : { attribution: "unattributed", newFailures: [] };
}

/** Why a failed reading failed, under the rule the record names. */
function attribution(check, failing) {
  return check.attributionRule === "failure-identity-v2"
    ? attributionV2(failing, check.parser, check.baseObservation)
    : attributionV1(failing, check.parser, check.baseObservation);
}

/**
 * The status a check must carry given its own, base-configuration, base-tests and base readings.
 * A pass whose base-written tests fail against the patch's source, in a way the base does not
 * fail, is withheld with those tests named. Mirrors `weakenedUnderBaseTests` in
 * src/gates/independent-verification.ts.
 */
function expectedStatus(check) {
  const decided = expectedStatusBeforeTests(check);
  if (decided === null) return null;
  if (check.baseTestsObservation === undefined) return { ...decided, weakened: [] };
  const within = (observation, instrument) =>
    instrument === undefined ? observation : { ...observation, instrument };
  const underTests = readStatus(
    check.parser,
    within(check.baseTestsObservation, check.baseTestsInstrument),
  );
  if (underTests !== check.baseTestsStatus) return null;
  if (decided.status !== "passed" || underTests !== "failed") return { ...decided, weakened: [] };
  const derived = attributionV2(check.baseTestsObservation, check.parser, check.baseObservation);
  if (derived.attribution === "inherited") return { ...decided, weakened: [] };
  const baseFailed =
    check.baseObservation !== undefined &&
    readStatus(check.parser, check.baseObservation) === "failed";
  const weakened = baseFailed
    ? derived.newFailures
    : [...new Set(namedTestsV2(check.baseTestsObservation)?.failed ?? [])].sort();
  return { status: "not-applicable", regressed: decided.regressed, weakened };
}

function expectedStatusBeforeTests(check) {
  const within = (observation, instrument) =>
    instrument === undefined ? observation : { ...observation, instrument };
  const reported = readStatus(check.parser, check.observation);
  const own = readStatus(check.parser, within(check.observation, check.instrument));
  // What the runner said is kept where the instrument rule withheld it, and must be what it said.
  if (own !== reported ? check.reportedStatus !== reported : check.reportedStatus !== undefined)
    return null;
  if (check.configurationObservation === undefined) return { status: own, regressed: [] };
  const underBase = readStatus(
    check.parser,
    within(check.configurationObservation, check.configurationInstrument),
  );
  if (underBase !== check.configurationStatus) return null;
  if (reported !== "passed") return { status: own, regressed: [] };
  // Measured again under the base's instrument and passed there: that reading stands.
  if (underBase === "passed") return { status: "passed", regressed: [] };
  const v2 = check.attributionRule === "failure-identity-v2";
  const points = v2
    ? namedTestsV2(check.configurationObservation)
    : namedTestsV1(check.configurationObservation);
  const base =
    check.baseObservation === undefined
      ? null
      : v2
        ? namedTestsV2(check.baseObservation)
        : namedTestsV1(check.baseObservation);
  const title = (id) => (id.includes(" › ") ? id.slice(id.indexOf(" › ") + 3) : id);
  const regressed =
    points === null || base === null
      ? []
      : v2
        ? points.failed.filter(
            (id) =>
              base.passed.filter((one) => one === id || one === title(id)).length === 1 &&
              !base.failed.some((one) => one === id || title(one) === title(id)),
          )
        : points.failed.filter((id) => base.passed.includes(id) && !base.failed.includes(id));
  return {
    status: underBase === "failed" && regressed.length > 0 ? "failed" : "not-applicable",
    regressed,
  };
}

const sameList = (a, b) => JSON.stringify([...(a ?? [])]) === JSON.stringify([...(b ?? [])]);

/**
 * Derive new captured-check results; undefined preserves older aggregate-only records.
 *
 * A record that carries `attribution` or a base-configuration reading is judged by the rule that
 * wrote them: every failed check's attribution is recomputed from its readings and must match,
 * a check the patch's runner configuration alone passed must carry the status the base's
 * configuration decides, and only a proven inherited failure is left out of the dimension. A
 * record without them is judged by the rule it was written under, which read any failure the base
 * shared as inherited and left the dimension unmeasured. Records from 1.0.3 to 1.0.5 that read
 * such a failure as a regression pass do not re-derive, and should not: that pass was not shown.
 */
function capturedRegression(checks) {
  if (!Array.isArray(checks) || !checks.some((check) => check.observation !== undefined))
    return undefined;
  try {
    const attributed = checks.some(
      (check) => check.attribution !== undefined || check.configurationObservation !== undefined,
    );
    for (const check of checks) {
      if (
        check.observation === undefined ||
        typeof check.id !== "string" ||
        !["passed", "failed", "not-applicable"].includes(check.status) ||
        (check.optionalAbsence !== undefined && typeof check.optionalAbsence !== "boolean") ||
        (check.optionalAbsence === true &&
          (check.status !== "not-applicable" ||
            typeof check.observation.unavailable !== "string" ||
            check.observation.exitCode !== 0 ||
            check.observation.stdout !== "" ||
            check.observation.stderr !== "")) ||
        !["blocking", "advisory"].includes(check.severity)
      )
        return null;
      const expected = expectedStatus(check);
      if (expected === null || expected.status !== check.status) return null;
      if (!sameList(expected.weakened, check.weakenedTests ?? [])) return null;
      if (
        check.configurationObservation !== undefined &&
        !sameList(expected.regressed, check.regressedUnderBaseConfiguration ?? [])
      )
        return null;
      if (!attributed) {
        if (
          check.inheritedFromBase === true &&
          (!check.baseObservation || readStatus(check.parser, check.baseObservation) !== "failed")
        )
          return null;
        continue;
      }
      if (check.status !== "failed") {
        if (check.attribution !== undefined || check.inheritedFromBase === true) return null;
        continue;
      }
      const failing =
        (check.regressedUnderBaseConfiguration ?? []).length > 0
          ? check.configurationObservation
          : check.observation;
      const derived = attribution(check, failing);
      if (
        derived.attribution !== check.attribution ||
        (check.inheritedFromBase === true) !== (derived.attribution === "inherited") ||
        !sameList(derived.newFailures, check.newFailures ?? [])
      )
        return null;
    }
    const inherited = (check) =>
      check.status === "failed" &&
      (attributed ? check.attribution === "inherited" : check.inheritedFromBase === true);
    if (
      checks.some(
        (check) =>
          check.status === "failed" &&
          !inherited(check) &&
          !(attributed && check.attribution === "unattributed"),
      )
    )
      return "fail";
    if (
      checks.some(
        (check) =>
          check.severity === "blocking" &&
          check.status !== "passed" &&
          check.optionalAbsence !== true &&
          !(attributed && inherited(check)),
      )
    )
      return "unmeasured";
    return checks.some((check) => check.status === "passed") ? "pass" : "unmeasured";
  } catch {
    return null;
  }
}

return capturedRegression;})();
const strengtheningAgrees = (() => {

// Check strengthening, re-derived from the chain. An additive check is admitted to a requirement
// only on the harness's own observations: under its one-check probe contract it rejects the
// counterexample that exposed the gap and accepts every sealed reference for the requirement.
// A revision appends admitted checks to its parent and changes nothing else. Mirrors
// `admissionDecision` in src/gates/check-admission.ts and `revisionProblem` in
// src/evidence/goal-contract.ts, written again so the decision a record carries is checked by a
// second implementation rather than by the code that made it. Dependency-free.

function canonicalText(value) {
  if (value === null || value === undefined) return "null";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "boolean" || typeof value === "number") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalText).join(",")}]`;
  const entries = Object.entries(value)
    .filter(([, item]) => item !== undefined)
    .sort(([a], [b]) => (a === b ? 0 : a < b ? -1 : 1));
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalText(v)}`).join(",")}}`;
}

function digestOf(value) {
  return `sha256:${createHash("sha256").update(canonicalText(value), "utf8").digest("hex")}`;
}

/** The admission rule over recorded runs. Mirrors `admissionDecision`. */
function readAdmission(runs, references) {
  const reasons = [];
  const counterexample = runs.filter((run) => run.purpose === "counterexample");
  if (counterexample.length !== 1) reasons.push("the counterexample was not run exactly once");
  else if (counterexample[0].status !== "rejected")
    reasons.push(
      `the check did not reject the counterexample (${counterexample[0].status}), so it does not detect the fault that exposed the gap`,
    );
  if (references.length === 0)
    reasons.push(
      "no sealed reference implementation for this requirement, so nothing justifies what the check expects of correct code",
    );
  for (const reference of references) {
    const run = runs.filter((one) => one.purpose === "reference" && one.reference === reference);
    if (run.length !== 1) reasons.push(`reference ${reference} was not run exactly once`);
    else if (run[0].status !== "accepted")
      reasons.push(
        `reference ${reference} is ${run[0].status}, so the check rejects work the contract's author vouches is correct`,
      );
  }
  if (runs.filter((run) => run.purpose === "candidate").length !== 1)
    reasons.push("the candidate was not run exactly once");
  return { admitted: reasons.length === 0, reasons };
}

/** Why a revision is not its parent with only the admitted checks appended; null where it is. */
function readRevision(parent, revised, admitted) {
  const { requirements: parentRequirements, checks: parentChecks, ...parentRest } = parent;
  const { requirements: revisedRequirements, checks: revisedChecks, ...revisedRest } = revised;
  if (canonicalText(parentRest) !== canonicalText(revisedRest))
    return "the revision changes the contract beyond its requirement checks";
  if (revisedRequirements.length !== parentRequirements.length)
    return "the revision adds or removes a requirement";
  for (let index = 0; index < parentRequirements.length; index++) {
    const original = parentRequirements[index];
    const next = revisedRequirements[index];
    const added = admitted
      .filter((one) => one.requirement === original.id)
      .map((one) => one.check.id);
    if (
      next === undefined ||
      next.id !== original.id ||
      next.description !== original.description ||
      canonicalText(next.checks) !== canonicalText([...original.checks, ...added])
    )
      return `requirement ${original.id} is not its original with only the admitted checks appended`;
  }
  const expected = [...parentChecks, ...admitted.map((one) => one.check)];
  if (canonicalText(revisedChecks) !== canonicalText(expected))
    return "the revision's checks are not the original checks followed by the admitted ones";
  return null;
}

/**
 * Every admission and every revision on the chain, re-derived or named as not re-derivable.
 * @param {Array<{sequence: number, type: string, payloadDigest: string}>} records
 * @param {Map<string, any>} payloads
 * @returns {Array<{sequence: number, agrees: boolean, problems: string[]}>}
 */
function strengtheningAgrees(records, payloads) {
  const findings = [];
  const contracts = new Map();
  for (const entry of records) {
    if (entry.type !== "goal-contract") continue;
    const payload = payloads.get(entry.payloadDigest);
    if (payload?.digest !== undefined && !contracts.has(payload.digest))
      contracts.set(payload.digest, { sequence: entry.sequence, payload });
  }
  const admissions = new Map();
  const requirementAdmissions = new Map();
  for (const entry of records) {
    if (entry.type !== "verification-command") continue;
    const payload = payloads.get(entry.payloadDigest);
    if (payload?.rule !== "check-admission-v1" || payload.phase !== "completed") continue;
    const problems = [];
    const probe = contracts.get(payload.probe);
    if (probe === undefined || probe.sequence > entry.sequence)
      problems.push("the probe contract is not on the chain before the admission");
    else {
      const lineage = probe.payload.lineage;
      if (
        lineage?.role !== "admission-probe" ||
        lineage.proposal !== payload.proposal ||
        lineage.requirement !== payload.requirement
      )
        problems.push("the probe does not name this proposal and requirement");
      const parent = contracts.get(lineage?.parent);
      const source = parent?.payload.contract.requirements.find(
        (one) => one.id === payload.requirement,
      );
      const contract = probe.payload.contract;
      if (
        digestOf(contract) !== payload.probe ||
        source === undefined ||
        contract.requirements.length !== 1 ||
        contract.requirements[0].id !== source.id ||
        contract.requirements[0].description !== source.description ||
        canonicalText(contract.checks) !== canonicalText([payload.check])
      )
        problems.push("the probe contract is not the requirement with the proposed check alone");
      const expectedReferences = (parent?.payload.contract.challenges?.references ?? [])
        .filter((reference) => reference.requirement === payload.requirement)
        .map((reference) => reference.id);
      if (canonicalText(expectedReferences) !== canonicalText(payload.references ?? []))
        problems.push("the admission ran other references than the contract seals");
    }
    for (const run of payload.runs ?? []) {
      const written = records.find(
        (candidate) =>
          candidate.type === "goal-verification" &&
          candidate.sequence < entry.sequence &&
          candidate.payloadDigest === run.verification,
      );
      const verification = payloads.get(written?.payloadDigest);
      const status =
        written === undefined ? "unjudged" : (verification?.obligations?.[0]?.status ?? "unjudged");
      if (written !== undefined && verification?.contractDigest !== payload.probe)
        problems.push(`the ${run.purpose} run cites a verification of another contract`);
      if (status !== run.status)
        problems.push(
          `the ${run.purpose} run records ${run.status}; its verification reads ${status}`,
        );
    }
    const derived = readAdmission(payload.runs ?? [], payload.references ?? []);
    if (derived.admitted !== payload.admitted)
      problems.push(
        `recorded ${payload.admitted ? "admitted" : "refused"}, the rule reads ${derived.admitted ? "admitted" : "refused"}`,
      );
    if (payload.admitted) {
      admissions.set(entry.payloadDigest, payload);
      requirementAdmissions.set(
        payload.requirement,
        (requirementAdmissions.get(payload.requirement) ?? 0) + 1,
      );
    }
    findings.push({ sequence: entry.sequence, agrees: problems.length === 0, problems });
  }
  for (const [digest, { sequence, payload }] of contracts) {
    if (payload.lineage?.role !== "revision") continue;
    const problems = [];
    const parent = contracts.get(payload.lineage.parent);
    if (parent === undefined || parent.sequence > sequence)
      problems.push("the revision's parent is not on the chain before it");
    const admitted = [];
    for (const record of payload.lineage.admissions ?? []) {
      const admission = admissions.get(record);
      if (admission === undefined)
        problems.push(`admission ${record} is not an admitted check on the chain`);
      else admitted.push({ requirement: admission.requirement, check: admission.check });
    }
    if (digestOf(payload.contract) !== digest)
      problems.push("the revision's digest does not match its contract");
    if (parent !== undefined && problems.length === 0) {
      const problem = readRevision(parent.payload.contract, payload.contract, admitted);
      if (problem !== null) problems.push(problem);
    }
    findings.push({ sequence, agrees: problems.length === 0, problems });
  }
  const plan = records
    .filter((entry) => entry.type === "verification-command")
    .map((entry) => payloads.get(entry.payloadDigest))
    .find((payload) => payload?.rule === "strengthening-plan-v1");
  if (plan !== undefined)
    for (const [requirement, count] of requirementAdmissions)
      if (count > plan.perRequirement)
        findings.push({
          sequence: -1,
          agrees: false,
          problems: [
            `requirement ${requirement} has ${count} admitted checks; the plan allows ${plan.perRequirement}`,
          ],
        });
  return findings;
}

return strengtheningAgrees;})();
const upgradeControlPasses = (() => {

const digest = (text) => `sha256:${createHash("sha256").update(text).digest("hex")}`;
const canonical = (value) =>
  JSON.stringify(value, (_key, item) =>
    item && typeof item === "object" && !Array.isArray(item)
      ? Object.fromEntries(
          Object.keys(item)
            .sort()
            .map((key) => [key, item[key]]),
        )
      : item,
  );
const regexLiteral = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function maskPython(text, dependency, candidate) {
  const pattern = candidate
    ? `${regexLiteral(dependency.name)}==${regexLiteral(dependency.version)}`
    : `${regexLiteral(dependency.name)}[^'"\\r\\n]*`;
  // nosemgrep: javascript.lang.security.audit.detect-non-literal-regexp.detect-non-literal-regexp - every regex metacharacter in the name and version is escaped by regexLiteral, so the only quantifier is the fixed character class written here.
  const matches = [...text.matchAll(new RegExp(`(['"])${pattern}\\1`, "g"))];
  if (matches.length !== 1) throw Error("ambiguous dependency literal");
  const match = matches[0];
  return (
    text.slice(0, match.index) +
    JSON.stringify(`<authorized ${dependency.name}>`) +
    text.slice(match.index + match[0].length)
  );
}

/** Independently compare authorized manifest changes and captured installed versions. */
function upgradeControlPasses(preset, authorization, resolution) {
  try {
    if (
      preset?.kind !== "upgrade" ||
      authorization?.rule !== "upgrade-authorization-v1" ||
      resolution?.rule !== "upgrade-resolution-v1" ||
      resolution.matched !== true ||
      authorization.presetDigest !== digest(canonical(preset)) ||
      authorization.manifest !== preset.manifest ||
      authorization.lockfile !== preset.lockfile ||
      !Array.isArray(preset.dependencies) ||
      !preset.dependencies.length ||
      !Array.isArray(authorization.touched) ||
      !Array.isArray(preset.sourcePaths) ||
      authorization.manifestDigest !== digest(authorization.candidate) ||
      authorization.manifestDigest !== resolution.manifestDigest ||
      authorization.lockDigest !== resolution.lockDigest ||
      resolution.manager !== preset.manager
    )
      return false;
    const allowed = [preset.manifest, preset.lockfile, ...preset.sourcePaths];
    if (authorization.touched.some((path) => !allowed.includes(path))) return false;
    if (preset.dependencies.some(({ name, version }) => resolution.versions?.[name] !== version))
      return false;
    if (preset.manager === "uv") {
      let before = authorization.base,
        after = authorization.candidate;
      for (const dependency of preset.dependencies) {
        before = maskPython(before, dependency, false);
        after = maskPython(after, dependency, true);
      }
      return before === after;
    }
    if (!["npm", "pnpm"].includes(preset.manager)) return false;
    const before = JSON.parse(authorization.base),
      after = JSON.parse(authorization.candidate);
    for (const { name, section, version } of preset.dependencies) {
      if (
        !["dependencies", "devDependencies"].includes(section) ||
        typeof before[section]?.[name] !== "string" ||
        after[section]?.[name] !== version
      )
        return false;
      delete before[section][name];
      delete after[section][name];
    }
    return canonical(before) === canonical(after);
  } catch {
    return false;
  }
}

return upgradeControlPasses;})();

export { readControllerHistory };

const GENESIS = "genesis";
const COMPARISONS = ["==", "!=", ">=", "<=", ">", "<"];

// One record type covers many subjects: every gate writes a gate-run, every tool writes a
// tool-call. A claim names the subject it asserts against, and this is how that name is
// recomputed here rather than read out of the bundle.
const SUBJECT_FIELD_BY_TYPE = {
  "gate-run": "gateId",
  "tool-call": "toolName",
  "attempt-selection": "taskId",
  "goal-attempt-selection": "taskId",
  "goal-candidate-verification": "workerId",
};

export function recordKindOf(type, payload) {
  const field = SUBJECT_FIELD_BY_TYPE[type];
  if (field === undefined) return type;
  if (payload === null || typeof payload !== "object") return type;
  const subject = payload[field];
  return typeof subject === "string" && subject.length > 0 ? `${type}:${subject}` : type;
}

/**
 * What a cited payload digest resolves to. Identical content is one blob by design, so two
 * writers can share a digest; what must not follow is that the citation means whichever of
 * them wrote last. The payload cannot differ between them, the kind can, so every record
 * carrying the digest is kept with the sequence that names it, and the claim says which one
 * it was bound to when it was submitted.
 */
export function indexCitedRecords(records, payloads) {
  const index = new Map();
  for (const entry of records) {
    if (!payloads.has(entry.payloadDigest)) continue;
    const payload = payloads.get(entry.payloadDigest);
    const carrier = { sequence: entry.sequence, kind: recordKindOf(entry.type, payload) };
    const found = index.get(entry.payloadDigest);
    if (found === undefined) {
      index.set(entry.payloadDigest, { carriers: [carrier], payload });
    } else {
      found.carriers.push(carrier);
    }
  }
  return index;
}

export function canonicalJson(value) {
  if (value === null) return "null";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new Error("non-finite number in canonical JSON");
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  const entries = Object.entries(value)
    .filter(([, item]) => item !== undefined)
    .sort(([a], [b]) => (a === b ? 0 : a < b ? -1 : 1));
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalJson(v)}`).join(",")}}`;
}

export function sha256(bytes) {
  return `sha256:${createHash("sha256").update(bytes, "utf8").digest("hex")}`;
}

function tokenize(source) {
  const tokens = [];
  let index = 0;
  while (index < source.length) {
    const character = source[index];
    if (/\s/.test(character)) {
      index += 1;
      continue;
    }
    if (character === "(" || character === ")") {
      tokens.push({ kind: "paren", text: character });
      index += 1;
      continue;
    }
    const pair = source.slice(index, index + 2);
    if (["&&", "||", "==", "!=", ">=", "<="].includes(pair)) {
      tokens.push({ kind: "operator", text: pair });
      index += 2;
      continue;
    }
    if (character === ">" || character === "<") {
      tokens.push({ kind: "operator", text: character });
      index += 1;
      continue;
    }
    if (character === '"' || character === "'") {
      const end = source.indexOf(character, index + 1);
      if (end === -1) throw new Error(`an opening ${character} is never closed`);
      tokens.push({ kind: "string", text: source.slice(index + 1, end) });
      index = end + 1;
      continue;
    }
    const remainder = source.slice(index);
    const number = /^-?\d+(?:\.\d+)?/.exec(remainder);
    if (number !== null) {
      tokens.push({ kind: "number", text: number[0] });
      index += number[0].length;
      continue;
    }
    const path = /^[A-Za-z_][A-Za-z0-9_-]*(?:\.[A-Za-z0-9_-]+)*/.exec(remainder);
    if (path !== null) {
      const text = path[0];
      tokens.push({ kind: ["true", "false", "null"].includes(text) ? "keyword" : "path", text });
      index += text.length;
      continue;
    }
    throw new Error(`"${character}" is not valid in a predicate`);
  }
  return tokens;
}

export function parsePredicate(source) {
  const tokens = tokenize(source);
  if (tokens.length === 0) throw new Error("the predicate is empty");
  let position = 0;

  const parseOperand = () => {
    const token = tokens[position];
    if (token === undefined) throw new Error("the predicate ends where a value was expected");
    position += 1;
    if (token.kind === "path")
      return { kind: "path", path: token.text.split("."), source: token.text };
    if (token.kind === "number") return { kind: "literal", value: Number(token.text) };
    if (token.kind === "string") return { kind: "literal", value: token.text };
    if (token.kind === "keyword") {
      return { kind: "literal", value: token.text === "null" ? null : token.text === "true" };
    }
    throw new Error(`"${token.text}" is not a value`);
  };

  const parseUnit = () => {
    const token = tokens[position];
    if (token !== undefined && token.text === "(") {
      position += 1;
      const inner = parseOr();
      if (tokens[position]?.text !== ")") throw new Error("an opening parenthesis is never closed");
      position += 1;
      return inner;
    }
    const left = parseOperand();
    const operator = tokens[position];
    if (
      operator === undefined ||
      operator.kind !== "operator" ||
      !COMPARISONS.includes(operator.text)
    ) {
      throw new Error("expected a comparison operator");
    }
    position += 1;
    return { kind: "compare", operator: operator.text, left, right: parseOperand() };
  };

  const parseAnd = () => {
    let node = parseUnit();
    while (tokens[position]?.text === "&&") {
      position += 1;
      node = { kind: "and", left: node, right: parseUnit() };
    }
    return node;
  };

  function parseOr() {
    let node = parseAnd();
    while (tokens[position]?.text === "||") {
      position += 1;
      node = { kind: "or", left: node, right: parseAnd() };
    }
    return node;
  }

  const node = parseOr();
  if (tokens[position] !== undefined) throw new Error("unexpected trailing input");
  return node;
}

function resolveOperand(operand, subject) {
  if (operand.kind === "literal") return { ok: true, value: operand.value };
  let current = subject;
  for (const segment of operand.path) {
    if (current === null || typeof current !== "object") {
      return {
        ok: false,
        failure: "path-not-found",
        detail: `${operand.source} does not exist in the cited record`,
      };
    }
    const next = Array.isArray(current) ? current[Number(segment)] : current[segment];
    if (next === undefined) {
      return {
        ok: false,
        failure: "path-not-found",
        detail: `${operand.source} does not exist in the cited record`,
      };
    }
    current = next;
  }
  return { ok: true, value: current };
}

function isPrimitive(value) {
  return value === null || typeof value !== "object";
}

function describeType(value) {
  if (value === null) return "null";
  return Array.isArray(value) ? "array" : typeof value;
}

function compare(operator, left, right) {
  if (operator === "==" || operator === "!=") {
    if (!isPrimitive(left) || !isPrimitive(right)) {
      return {
        ok: false,
        failure: "type-mismatch",
        detail: `${operator} compares primitives, and one side is an object or array`,
      };
    }
    const equal = left === right;
    return { ok: true, value: operator === "==" ? equal : !equal };
  }
  if (typeof left !== "number" || typeof right !== "number") {
    return {
      ok: false,
      failure: "type-mismatch",
      detail: `${operator} compares numbers, got ${describeType(left)} and ${describeType(right)}`,
    };
  }
  if (operator === ">=") return { ok: true, value: left >= right };
  if (operator === "<=") return { ok: true, value: left <= right };
  if (operator === ">") return { ok: true, value: left > right };
  return { ok: true, value: left < right };
}

// && and || evaluate both sides: a broken path never hides behind a false conjunction.
export function evaluatePredicate(node, subject) {
  if (node.kind === "and" || node.kind === "or") {
    const left = evaluatePredicate(node.left, subject);
    const right = evaluatePredicate(node.right, subject);
    if (!left.ok) return left;
    if (!right.ok) return right;
    return {
      ok: true,
      value: node.kind === "and" ? left.value && right.value : left.value || right.value,
    };
  }
  const left = resolveOperand(node.left, subject);
  if (!left.ok) return left;
  const right = resolveOperand(node.right, subject);
  if (!right.ok) return right;
  return compare(node.operator, left.value, right.value);
}

export function evaluateClaim(claim, lookup) {
  if (claim === null || typeof claim !== "object") {
    return {
      verdict: "unverified",
      reason: "record-not-found",
      detail: "the claim payload is missing",
    };
  }
  if (claim.record === null || claim.record === undefined) {
    return {
      verdict: "unverified",
      reason: "no-evidence-edge",
      detail: "the claim cites no record",
    };
  }
  const cited = lookup(claim.record);
  if (cited === undefined) {
    return {
      verdict: "unverified",
      reason: "record-not-found",
      detail: `no ledger record carries the payload digest ${claim.record}`,
    };
  }
  // Checked before the predicate: a predicate that is true of another kind of record is not
  // an honest near miss, it is a claim bound to the wrong evidence. The claim names the
  // record it was bound to at submission, so a later record reusing the digest under another
  // kind cannot reach back and withdraw a verdict that was honestly earned.
  const carriers = cited.carriers ?? [];
  const kinds = [...new Set(carriers.map((carrier) => carrier.kind))];
  if (claim.recordSequence === null) {
    return {
      verdict: "unverified",
      reason: "predicate-kind-mismatch",
      detail:
        kinds.length > 1
          ? `the digest ${claim.record} is carried by records of ${kinds.length} kinds (${kinds.join(", ")})`
          : "the harness bound this claim to no record when it was submitted",
    };
  }
  const bound =
    claim.recordSequence === undefined
      ? carriers[0]
      : carriers.find((carrier) => carrier.sequence === claim.recordSequence);
  if (bound === undefined) {
    return {
      verdict: "unverified",
      reason: "record-not-found",
      detail: `no record at sequence ${claim.recordSequence} carries the payload digest ${claim.record}`,
    };
  }
  if (bound.kind !== claim.recordKind) {
    return {
      verdict: "unverified",
      reason: "predicate-kind-mismatch",
      detail: `the claim asserts against ${claim.recordKind}, but the cited record is ${bound.kind}`,
    };
  }
  let node;
  try {
    node = parsePredicate(String(claim.predicate ?? ""));
  } catch (cause) {
    return { verdict: "unverified", reason: "predicate-unparseable", detail: cause.message };
  }
  const result = evaluatePredicate(node, cited.payload);
  if (!result.ok) return { verdict: "unverified", reason: result.failure, detail: result.detail };
  if (!result.value) {
    return {
      verdict: "unverified",
      reason: "predicate-false",
      detail: "the cited record does not support the predicate",
    };
  }
  return {
    verdict: "verified",
    reason: null,
    detail: "the predicate held against the cited record",
  };
}

/**
 * What a bond showed, from its recorded observation alone. Held: the check refused the bond.
 * Vacuous: the check passed over a bond it demonstrably saw. Unshown: the check passed and
 * nothing shows whether it saw the bond. Not measured: the check could not run. The same
 * rule as src/gates/bonds.ts, reimplemented here so a bundle's own verdicts can be recomputed
 * without this package.
 */
export function bondVerdict({ observed, provable, collectedBefore, collectedAfter }) {
  if (observed === "not-applicable") return "not-measured";
  if (observed === "failed") return "held";
  if (provable) return "vacuous";
  if (collectedBefore !== null && collectedAfter !== null && collectedAfter > collectedBefore) {
    return "vacuous";
  }
  return "unshown";
}

export function recomputeBondVerdict(payload) {
  if (payload === null || typeof payload !== "object") return "not-bonded";
  if (payload.bond === null || payload.bond === undefined || payload.observed === null) {
    return "not-bonded";
  }
  return bondVerdict({
    observed: payload.observed,
    provable: payload.bond.provable === true,
    collectedBefore: payload.collectedBefore ?? null,
    collectedAfter: payload.measures?.testsCollected ?? null,
  });
}

/**
 * Holds every gate-run to the criteria sealed before the loop. The seal has to come before
 * the first model call, tool call and gate run; every gate that ran has to be one the seal
 * names, at the severity and under the parser it declared; and every sealed gate has to have
 * run in the final attempt. A run that met all of that was measured by what it promised.
 */
export function sealConformance(records, payloads) {
  const seals = records.filter((entry) => entry.type === "gate-set-sealed");
  if (seals.length === 0) return { sealed: null, problems: [] };
  const problems = [];
  if (seals.length > 1) {
    problems.push(
      `criteria sealed ${seals.length} times; a second seal is a second set of criteria`,
    );
  }
  const seal = seals[0];
  const sealed = payloads.get(seal.payloadDigest);
  if (sealed === undefined || !Array.isArray(sealed.gates)) {
    return { sealed: null, problems: [`record ${seal.sequence} carries no readable gate set`] };
  }
  const first = records.find((entry) =>
    ["model-call", "tool-call", "gate-run", "gate-baseline"].includes(entry.type),
  );
  if (first !== undefined && first.sequence < seal.sequence) {
    problems.push(
      `criteria sealed at record ${seal.sequence}, after the first ${first.type} at record ${first.sequence}`,
    );
  }
  const byId = new Map(sealed.gates.map((gate) => [gate.id, gate]));
  // Every run of a gate, over the tree the loop left or over the base, has to be a sealed gate
  // run as sealed; only the runs over the tree the loop left make up a cycle.
  const everyRun = records
    .filter((entry) => entry.type === "gate-run" || entry.type === "gate-baseline")
    .map((entry) => ({
      sequence: entry.sequence,
      type: entry.type,
      payload: payloads.get(entry.payloadDigest),
    }))
    .filter((entry) => entry.payload !== undefined);
  const runs = everyRun.filter((entry) => entry.type === "gate-run");
  for (const { sequence, payload } of everyRun) {
    const declared = byId.get(payload.gateId);
    if (declared === undefined) {
      problems.push(`record ${sequence} ran gate ${payload.gateId}, which the seal does not name`);
      continue;
    }
    if (declared.severity !== payload.severity) {
      problems.push(
        `record ${sequence} ran ${payload.gateId} as ${payload.severity}; the seal declared ${declared.severity}`,
      );
    }
    if (payload.parser !== undefined && declared.parser !== payload.parser) {
      problems.push(
        `record ${sequence} read ${payload.gateId} with the ${payload.parser} rule; the seal declared ${declared.parser}`,
      );
    }
    // The command is what was run, and a seal that names one is a promise about it: a gate
    // assembled from a manifest the run rewrote would carry the same id and a different command.
    if (
      declared.command !== undefined &&
      payload.command !== undefined &&
      declared.command !== payload.command
    ) {
      problems.push(
        `record ${sequence} ran ${payload.gateId} as \`${payload.command}\`; the seal declared \`${declared.command}\``,
      );
    }
  }
  // The final cycle is the run of gate-run records at the end of the chain sharing one attempt
  // number, which is the last cycle whatever came before it: a session's last turn, or a
  // single run's fixed point. Reading the highest attempt number instead would let an earlier
  // turn's retry stand in for a later turn that dropped a gate.
  const finalCycle = [];
  for (let index = runs.length - 1; index >= 0; index -= 1) {
    const entry = runs[index];
    if (
      finalCycle.length > 0 &&
      (entry.payload.attempt ?? 0) !== (finalCycle[0].payload.attempt ?? 0)
    ) {
      break;
    }
    finalCycle.unshift(entry);
  }
  for (const gate of sealed.gates) {
    if (!finalCycle.some((entry) => entry.payload.gateId === gate.id)) {
      problems.push(`sealed gate ${gate.id} did not run in the final attempt`);
    }
  }
  return { sealed: { sequence: seal.sequence, gates: sealed.gates.length }, problems };
}

/**
 * Every check for one bundle directory, without printing any of them. Split out so a combined
 * bundle can fold in its workers' checks: a worker chain is verified by exactly the same code
 * as the coordinator's, rather than by a second, looser reading of the same format.
 */
function collectChecks(directory) {
  const checks = [];
  const record = (name, ok, detail) => {
    checks.push({ name, ok, detail });
  };

  let manifest;
  try {
    manifest = JSON.parse(readFileSync(join(directory, "manifest.json"), "utf8"));
    record(
      "manifest reads",
      true,
      `bundle format ${manifest.bundleFormat}, session ${manifest.sessionId}`,
    );
  } catch (cause) {
    record("manifest reads", false, cause.message);
    return { checks, verdicts: [], payloads: new Map(), manifest: null, vacuous: [] };
  }

  let lines = [];
  try {
    lines = readFileSync(join(directory, "ledger.jsonl"), "utf8")
      .split("\n")
      .filter((line) => line.trim().length > 0);
  } catch (cause) {
    record("ledger reads", false, cause.message);
    return { checks, verdicts: [], payloads: new Map(), manifest, vacuous: [] };
  }

  const records = [];
  let parseFailures = 0;
  for (const [index, line] of lines.entries()) {
    try {
      records.push(JSON.parse(line));
    } catch (cause) {
      parseFailures += 1;
      record(`ledger line ${index + 1} parses`, false, cause.message);
    }
  }
  record("ledger parses", parseFailures === 0, `${records.length} of ${lines.length} lines`);
  record(
    "record count matches the manifest",
    records.length === manifest.recordCount,
    `${records.length} records, manifest says ${manifest.recordCount}`,
  );

  let previous = GENESIS;
  const chainProblems = [];
  for (const [index, entry] of records.entries()) {
    if (entry.sequence !== index) {
      chainProblems.push(`record ${index} declares sequence ${entry.sequence}`);
    }
    if (entry.previousHash !== previous) {
      chainProblems.push(
        `record ${index} carries previousHash ${entry.previousHash}, but the record before it hashes to ${previous}`,
      );
    }
    previous = sha256(canonicalJson(entry));
  }
  record(
    "hash chain intact",
    chainProblems.length === 0,
    chainProblems.join("; ") || `${records.length} links`,
  );
  record(
    "chain head matches the manifest",
    previous === manifest.chainHead,
    `computed ${previous}`,
  );

  let signatureOk = false;
  try {
    signatureOk = verifySignature(
      null,
      Buffer.from(manifest.chainHead, "utf8"),
      createPublicKey({
        key: Buffer.from(manifest.signature.publicKey, "base64"),
        format: "der",
        type: "spki",
      }),
      Buffer.from(manifest.signature.value, "base64"),
    );
  } catch (cause) {
    record("signature checks", false, cause.message);
  }
  record(
    "signature over the chain head verifies",
    signatureOk,
    `${manifest.signature.algorithm}, ${manifest.signature.keySource} key`,
  );

  const payloads = new Map();
  const blobProblems = [];
  let blobFiles = [];
  try {
    blobFiles = readdirSync(join(directory, "blobs"));
  } catch {
    blobFiles = [];
  }
  for (const file of blobFiles) {
    const bytes = readFileSync(join(directory, "blobs", file), "utf8");
    const digest = sha256(bytes);
    if (`${digest.replace("sha256:", "")}.json` !== file) {
      blobProblems.push(`${file} hashes to ${digest}`);
      continue;
    }
    try {
      payloads.set(digest, JSON.parse(bytes));
    } catch (cause) {
      blobProblems.push(`${file} is not JSON: ${cause.message}`);
    }
  }
  record(
    "blobs match their content addresses",
    blobProblems.length === 0,
    blobProblems.join("; ") || `${blobFiles.length} blobs`,
  );

  const missing = records
    .map((entry) => entry.payloadDigest)
    .filter((digest) => !payloads.has(digest));
  record(
    "every record's payload is present",
    missing.length === 0,
    missing.length === 0
      ? "all payloads resolve"
      : `${missing.length} missing: ${missing.join(", ")}`,
  );

  const referenced = [...new Set(records.map((entry) => entry.payloadDigest))].sort();
  record(
    "manifest blob inventory matches the ledger",
    Array.isArray(manifest.blobs) &&
      JSON.stringify([...manifest.blobs].sort()) === JSON.stringify(referenced) &&
      Array.isArray(manifest.missingBlobs) &&
      manifest.missingBlobs.length === 0,
    "every referenced payload must be listed and present",
  );

  let attestationBytes;
  try {
    attestationBytes = readFileSync(join(directory, "attestation.dsse.json"), "utf8");
  } catch (cause) {
    if (cause.code !== "ENOENT") record("attestation reads", false, cause.message);
  }
  if (manifest.attestationDigest !== undefined) {
    record(
      "attestation content address",
      attestationBytes !== undefined && sha256(attestationBytes) === manifest.attestationDigest,
      "declared attestation must be present and unchanged",
    );
  }
  if (attestationBytes !== undefined) {
    try {
      const envelope = JSON.parse(attestationBytes);
      const payload = Buffer.from(envelope.payload, "base64");
      const statement = JSON.parse(payload.toString("utf8"));
      const legacy = statement.predicateType === "https://swarm-orchestrator.dev/attestation/v3";
      const pae = Buffer.concat([
        Buffer.from(
          `DSSEv1 ${Buffer.byteLength(envelope.payloadType)} ${envelope.payloadType} ${payload.length} `,
        ),
        payload,
      ]);
      const signature = envelope.signatures[0];
      const signatureHolds = verifySignature(
        null,
        legacy ? Buffer.from(pae.toString("base64")) : pae,
        createPublicKey({
          key: Buffer.from(signature.publicKey, "base64"),
          format: "der",
          type: "spki",
        }),
        Buffer.from(signature.sig, "base64"),
      );
      record(
        "attestation signature and type",
        signatureHolds &&
          envelope.payloadType === "application/vnd.in-toto+json" &&
          statement._type === "https://in-toto.io/Statement/v1" &&
          (legacy || statement.predicateType === "https://swarm-orchestrator.dev/attestation/v4") &&
          signature.publicKey === manifest.signature.publicKey,
        legacy ? "legacy v3 base64 signing compatibility" : "standard DSSE raw PAE",
      );
      const latest = (type) =>
        payloads.get(records.filter((entry) => entry.type === type).at(-1)?.payloadDigest);
      const patch = latest("workspace-diff");
      const assessment = latest("run-assessment");
      const spec = records.find((entry) => entry.type === "run-spec-sealed");
      record(
        "attestation bound to this bundle",
        statement.predicate.chainHead === manifest.chainHead &&
          statement.predicate.runId === manifest.sessionId &&
          (legacy ||
            (typeof patch?.patch === "string" &&
              patch.truncated === false &&
              statement.subject?.length === 1 &&
              statement.subject[0]?.digest?.sha256 === sha256(patch.patch).slice(7) &&
              statement.predicate.specDigest === spec?.payloadDigest &&
              statement.predicate.sourceCommit ===
                payloads.get(spec?.payloadDigest)?.spec?.repository?.baseCommit &&
              canonicalJson(statement.predicate.verdict) === canonicalJson(assessment?.verdict) &&
              statement.predicate.executionMode === assessment?.verdict?.executionTrust)),
        "patch bytes, spec, source, assessment and chain must agree",
      );
    } catch (cause) {
      record("attestation verifies", false, cause.message);
    }
  }

  const cited = indexCitedRecords(records, payloads);
  const lookup = (digest) => cited.get(digest);
  const verdicts = records
    .filter((entry) => entry.type === "claim")
    .map((entry) => {
      const claim = payloads.get(entry.payloadDigest);
      return { sequence: entry.sequence, claim, evaluation: evaluateClaim(claim, lookup) };
    });

  const verified = verdicts.filter((entry) => entry.evaluation.verdict === "verified").length;
  record(
    "claim verdicts recomputed",
    manifest.claims.verified === verified &&
      manifest.claims.unverified === verdicts.length - verified,
    `${verified} verified, ${verdicts.length - verified} unverified; manifest says ${manifest.claims.verified} verified`,
  );

  // Format 2 promises criteria sealed before the loop and a bond per passing gate. A bundle
  // of that format with no seal in it dodged the check, and is refused as such; an earlier
  // format predates sealing and has nothing to be held to.
  const conformance = sealConformance(records, payloads);
  const gateRan = records.some((entry) => entry.type === "gate-run");
  if (conformance.sealed === null) {
    const dodged = (manifest.bundleFormat ?? 1) >= 2 && gateRan;
    record(
      "gate runs conform to the sealed criteria",
      !dodged,
      dodged
        ? "bundle format 2 promises criteria sealed before the gates ran, and none is recorded"
        : gateRan
          ? "no criteria sealed: this bundle format predates sealing"
          : "no gate ran in this bundle, so there is nothing to hold to a seal",
    );
  } else {
    record(
      "gate runs conform to the sealed criteria",
      conformance.problems.length === 0,
      conformance.problems.join("; ") ||
        `${conformance.sealed.gates} gate(s) sealed at record ${conformance.sealed.sequence}, before the first model call`,
    );
  }

  const bonds = records
    .filter((entry) => entry.type === "gate-bond")
    .map((entry) => ({ sequence: entry.sequence, payload: payloads.get(entry.payloadDigest) }))
    .filter((entry) => entry.payload !== undefined);
  const bondDisagreements = [];
  const tally = {};
  for (const { sequence, payload } of bonds) {
    const recomputed = recomputeBondVerdict(payload);
    if (recomputed !== payload.verdict) {
      bondDisagreements.push(
        `record ${sequence} says ${payload.verdict}, its observation says ${recomputed}`,
      );
    }
    tally[payload.verdict] = (tally[payload.verdict] ?? 0) + 1;
  }
  if (bonds.length > 0 || (manifest.bundleFormat ?? 1) >= 2) {
    record(
      "bond verdicts recomputed",
      bondDisagreements.length === 0,
      bondDisagreements.join("; ") ||
        (bonds.length === 0
          ? "no gate passed, so nothing was bonded"
          : `${bonds.length} bond(s): ${Object.entries(tally)
              .map(([verdict, count]) => `${count} ${verdict}`)
              .join(", ")}`),
    );
  }

  for (const entry of records.filter((candidate) => candidate.type === "model-call")) {
    const payload = payloads.get(entry.payloadDigest);
    if (payload?.prompt?.transcriptVersion !== 2) continue;
    try {
      const reference = payload.prompt;
      const read = (digest, kind) => {
        if (
          !records.some(
            (candidate) =>
              candidate.sequence < entry.sequence &&
              candidate.type === "transcript-component" &&
              candidate.payloadDigest === digest,
          )
        )
          throw new Error("component is not recorded before this prompt");
        const component = payloads.get(digest);
        if (component?.kind !== kind) throw new Error("component kind mismatch");
        return component;
      };
      const messages = [];
      const visited = new Set();
      let tail = reference.tail;
      while (tail !== null) {
        if (
          visited.has(tail) ||
          messages.length >= reference.length ||
          messages.length > records.length
        )
          throw new Error("invalid transcript links");
        visited.add(tail);
        const component = read(tail, "message");
        messages.push(component.value);
        tail = component.previous;
      }
      const reconstructed = {
        system: read(reference.system, "system").value,
        tools: read(reference.tools, "tools").value,
        messages: messages.reverse(),
        maxOutputTokens: reference.maxOutputTokens,
        sampling: reference.sampling,
      };
      record(
        `transcript ${entry.sequence} reconstructs`,
        messages.length === reference.length &&
          sha256(canonicalJson(reconstructed)) === entry.promptDigest,
        "component chain and exact prompt digest",
      );
    } catch (cause) {
      record(`transcript ${entry.sequence} reconstructs`, false, String(cause));
    }
  }

  for (const entry of records.filter((candidate) => candidate.type === "contract-verification")) {
    const verification = payloads.get(entry.payloadDigest);
    const declaration = records.find(
      (candidate) =>
        candidate.type === "acceptance-contract" &&
        candidate.sequence < entry.sequence &&
        payloads.get(candidate.payloadDigest)?.digest === verification?.contractDigest,
    );
    const contract = payloads.get(declaration?.payloadDigest)?.contract;
    let consistent =
      declaration !== undefined &&
      sha256(canonicalJson(contract)) === verification?.contractDigest &&
      verification?.policy === "required-obligations-v1";
    const requirements = contract?.requirements ?? [];
    const obligations = verification?.obligations ?? [];
    consistent &&=
      requirements.length === obligations.length &&
      new Set(requirements.map((requirement) => requirement.id)).size === requirements.length;
    let accepted = true;
    for (const [index, requirement] of requirements.entries()) {
      const obligation = obligations[index];
      const observations = obligation?.observations ?? [];
      consistent &&=
        obligation?.id === requirement.id &&
        obligation?.severity === requirement.severity &&
        observations.length === (requirement.applicable ? 3 : 0);
      for (const [position, observation] of observations.entries()) {
        const named = records.find(
          (candidate) =>
            candidate.type === "verification-command" &&
            candidate.sequence > declaration.sequence &&
            candidate.sequence < entry.sequence &&
            candidate.payloadDigest === observation.evidenceDigest,
        );
        const captured = payloads.get(named?.payloadDigest);
        consistent &&=
          captured?.status === observation.status &&
          captured?.requirementId === requirement.id &&
          captured?.target === ["reference", "violating-control", "candidate"][position] &&
          captured?.artifactDigest === requirement.artifactDigest &&
          (position === 2 ||
            captured?.patchDigest ===
              (position === 0 ? requirement.referenceDigest : requirement.violatingControlDigest));
      }
      const instrument =
        observations[0]?.status === "passed" && observations[1]?.status === "assertion-failed";
      const status = !requirement.applicable
        ? "not-applicable"
        : !instrument || observations[2]?.status === "unavailable"
          ? "unjudged"
          : observations[2]?.status === "passed"
            ? "accepted"
            : "rejected";
      consistent &&= obligation?.status === status;
      accepted &&=
        requirement.severity !== "required" || status === "accepted" || status === "not-applicable";
    }
    record(
      `required obligations ${entry.sequence} re-derived`,
      consistent && verification?.accepted === accepted,
      `obligation conjunction implies ${accepted}`,
    );
  }
  const setupIntents = new Map();
  const setupSeen = new Set();
  for (const entry of records.filter((candidate) => candidate.type === "dependency-install")) {
    const setup = payloads.get(entry.payloadDigest);
    let consistent = entry.actor === "harness" && setup?.version === 1;
    if (setup?.phase === "intent") {
      consistent &&= typeof setup.id === "string" && !setupSeen.has(setup.id);
      setupSeen.add(setup.id);
      setupIntents.set(setup.id, setup);
    } else if (setup?.phase === "completed") {
      const intent = setupIntents.get(setup.id);
      consistent &&=
        intent !== undefined &&
        ["workspace", "argv", "lockDigest", "sourceDigest"].every(
          (key) => canonicalJson(intent[key]) === canonicalJson(setup[key]),
        ) &&
        typeof setup.sourceAfter === "string" &&
        (Number.isInteger(setup.exitCode) || setup.exitCode === null) &&
        (typeof setup.unavailable === "string" || setup.unavailable === null) &&
        setup.succeeded ===
          (setup.exitCode === 0 &&
            setup.unavailable === null &&
            setup.sourceAfter === intent.sourceDigest);
      setupIntents.delete(setup.id);
    } else consistent = false;
    record(
      `dependency setup ${entry.sequence} re-derived`,
      consistent,
      "intent identity, process observation and source preservation determine setup status",
    );
  }
  for (const entry of records.filter(
    (candidate) => candidate.type === "independent-verification",
  )) {
    const verification = payloads.get(entry.payloadDigest);
    if (verification?.certificationPolicy !== "required-obligations-v1") continue;
    const named = records
      .filter(
        (candidate) =>
          candidate.type === "contract-verification" && candidate.sequence < entry.sequence,
      )
      .at(-1);
    const acceptance = payloads.get(named?.payloadDigest);
    record(
      `independent obligations ${entry.sequence} bound`,
      named !== undefined &&
        canonicalJson(acceptance) === canonicalJson(verification.acceptance) &&
        verification.verified ===
          (verification.regression === "pass" && acceptance?.accepted === true),
      "the final verification cites the recorded requirement checks",
    );
  }
  for (const entry of records.filter((candidate) => candidate.type === "goal-verification")) {
    const reading = payloads.get(entry.payloadDigest);
    const declaration = records.find(
      (candidate) =>
        candidate.type === "goal-contract" &&
        candidate.sequence < entry.sequence &&
        payloads.get(candidate.payloadDigest)?.digest === reading?.contractDigest,
    );
    const contract = payloads.get(declaration?.payloadDigest)?.contract;
    let consistent =
      contract?.version === 1 &&
      sha256(canonicalJson(contract)) === reading?.contractDigest &&
      reading?.policy === "goal-obligations-v1";
    const requirements = contract?.requirements ?? [];
    const checks = contract?.checks ?? [];
    const obligations = reading?.obligations ?? [];
    consistent &&=
      requirements.length > 0 &&
      requirements.length === obligations.length &&
      new Set(requirements.map((requirement) => requirement.id)).size === requirements.length &&
      new Set(checks.map((check) => check.id)).size === checks.length;
    let presetAccepted = true;
    if (contract?.preset?.kind === "upgrade") {
      const source = records.find(
        (candidate) =>
          candidate.type === "verification-command" &&
          candidate.sequence > declaration.sequence &&
          candidate.sequence < entry.sequence &&
          candidate.payloadDigest === reading.upgradeControl?.manifestRecord,
      );
      const installed = records.find(
        (candidate) =>
          candidate.type === "verification-command" &&
          candidate.sequence > (source?.sequence ?? entry.sequence) &&
          candidate.sequence < entry.sequence &&
          candidate.payloadDigest === reading.upgradeControl?.resolution,
      );
      presetAccepted =
        source !== undefined &&
        installed !== undefined &&
        upgradeControlPasses(
          contract.preset,
          payloads.get(source.payloadDigest),
          payloads.get(installed.payloadDigest),
        );
      consistent &&= presetAccepted;
    }
    const control = reading?.presetControl;
    if (["bugfix", "refactor"].includes(contract?.preset?.kind)) {
      consistent &&=
        reading.purpose === "base-control"
          ? control === undefined
          : reading.purpose === "candidate" && control !== undefined;
    }
    if (control !== undefined) {
      if (
        contract.preset?.kind !== control.kind ||
        !/^[a-f0-9]{40,64}$/.test(control.baseTree ?? "")
      )
        consistent = false;
      const prior = records.filter(
        (candidate) =>
          candidate.sequence < entry.sequence && candidate.sequence > declaration.sequence,
      );
      if (control.kind === "refactor")
        presetAccepted = prior.some((candidate) => {
          const base = payloads.get(candidate.payloadDigest);
          return (
            candidate.type === "goal-verification" &&
            base?.contractDigest === reading.contractDigest &&
            base?.purpose === "base-control" &&
            base?.tree === control.baseTree &&
            base?.accepted === true
          );
        });
      else if (control.kind === "bugfix") {
        const reproducer = checks.find((check) => check.id === contract.preset.reproducer);
        presetAccepted =
          reproducer?.behavior?.kind === "cli" &&
          reproducer.behavior.stdout.length + reproducer.behavior.stderr.length > 0 &&
          prior.some((candidate) => {
            const base = payloads.get(candidate.payloadDigest);
            return (
              candidate.type === "goal-check" &&
              base?.checkId === reproducer.id &&
              base?.tree === control.baseTree &&
              base?.contractDigest === reading.contractDigest &&
              base?.observation?.unavailable === null &&
              !base?.observation?.outputTruncated &&
              base?.observation?.exitCode === reproducer.behavior.exitCode &&
              behaviorStatus(reproducer.behavior, base.observation) === "rejected"
            );
          });
      } else presetAccepted = false;
      consistent &&= control.accepted === presetAccepted;
    }
    for (const [index, requirement] of requirements.entries()) {
      const obligation = obligations[index];
      consistent &&=
        requirement.id === obligation?.id &&
        requirement.checks.length === obligation?.checks?.length;
      const statuses = [];
      for (const [position, checkId] of requirement.checks.entries()) {
        const definition = checks.find((check) => check.id === checkId);
        const capturedRecord = records.find(
          (candidate) =>
            candidate.type === "goal-check" &&
            candidate.sequence > declaration.sequence &&
            candidate.sequence < entry.sequence &&
            candidate.payloadDigest === obligation?.checks?.[position],
        );
        const captured = payloads.get(capturedRecord?.payloadDigest);
        const status =
          captured?.observation?.unavailable !== null ||
          captured?.observation?.outputTruncated === true
            ? "unjudged"
            : definition?.behavior !== undefined
              ? captured?.unchanged === true
                ? behaviorStatus(definition.behavior, captured.observation)
                : "rejected"
              : captured?.observation?.exitCode === 0 && captured?.unchanged === true
                ? "accepted"
                : "rejected";
        consistent &&=
          definition !== undefined &&
          capturedRecord !== undefined &&
          captured?.checkId === checkId &&
          captured?.contractDigest === reading.contractDigest &&
          captured?.tree === reading.tree &&
          captured?.command === definition.command &&
          captured?.author === definition.author &&
          captured?.exposure === definition.exposure &&
          captured?.status === status;
        statuses.push(status);
      }
      const status =
        !presetAccepted || statuses.length === 0 || statuses.includes("unjudged")
          ? "unjudged"
          : statuses.every((status) => status === "accepted")
            ? "accepted"
            : "rejected";
      consistent &&= obligation?.status === status;
    }
    record(
      `goal obligations ${entry.sequence} re-derived`,
      consistent &&
        reading?.accepted === obligations.every((obligation) => obligation.status === "accepted"),
      "every pinned requirement is bound to its captured check observations",
    );
  }
  for (const entry of records.filter(
    (candidate) => candidate.type === "independent-verification",
  )) {
    const reading = payloads.get(entry.payloadDigest);
    const regression = capturedRegression(reading?.checks);
    if (regression !== undefined)
      record(
        `independent regression ${entry.sequence} re-derived`,
        regression !== null && regression === reading.regression,
        "configured checks derive from captured process observations",
      );
    if (reading?.certificationPolicy !== "goal-obligations-v1") continue;
    const observed = records
      .filter(
        (candidate) =>
          candidate.type === "goal-verification" && candidate.sequence < entry.sequence,
      )
      .at(-1);
    const goal = payloads.get(observed?.payloadDigest);
    record(
      `independent goal ${entry.sequence} bound`,
      goal === undefined
        ? reading.verified === false
        : canonicalJson(goal) === canonicalJson(reading.goalAcceptance) &&
            // Mirrors reasonsToRefuse under goal-obligations-v1: a required challenge that was not
            // satisfied refuses, whatever the checks said about this candidate.
            reading.verified ===
              (reading.regression === "pass" &&
                goal.accepted === true &&
                !(reading.challenges?.policy === "required" && reading.challenges?.satisfied !== true)),
      "final goal policy binds independent regression and goal observations",
    );
  }
  for (const finding of challengeVerdictsAgree(records, payloads))
    record(
      `challenge verdict ${finding.sequence} re-derived`,
      finding.agrees,
      finding.problems.join("; ") ||
        "every requirement's challenge outcome follows from its plan, its runs and the goal verifications",
    );
  for (const finding of strengtheningAgrees(records, payloads))
    record(
      `check strengthening ${finding.sequence} re-derived`,
      finding.agrees,
      finding.problems.join("; ") ||
        "the admission follows from its probe runs, and the revision only appends admitted checks",
    );
  for (const assessment of goalSelectionConformance(records, payloads))
    record(
      `goal alternatives ${assessment.sequence} re-derived`,
      assessment.problems.length === 0,
      assessment.problems.join("; ") || "complete obligations precede the declared objective",
    );
  if (
    records.some(
      (entry) =>
        entry.type === "controller-graph" ||
        entry.type === "bootstrap-stage" ||
        (entry.type === "controller-launch" &&
          payloads.get(entry.payloadDigest)?.spec?.bootstrap !== undefined),
    )
  ) {
    const board = readControllerHistory(records, payloads);
    record(
      "controller history re-derived",
      board.problems.length === 0,
      board.problems.join("; ") || "bounded graph revisions and effect ordering agree",
    );
  }
  for (const entry of records.filter((candidate) => candidate.type === "controller-assessment")) {
    const reading = payloads.get(entry.payloadDigest);
    const prior = records.filter((candidate) => candidate.sequence < entry.sequence);
    const declaration = prior.find(
      (candidate) =>
        candidate.type === "controller-event" &&
        payloads.get(candidate.payloadDigest)?.kind === "work-declared",
    );
    const declared = payloads.get(declaration?.payloadDigest)?.tasks ?? [];
    const tasks = reading?.tasks ?? [];
    const goal = prior.find((candidate) => candidate.type === "goal-contract");
    const requirements = payloads.get(goal?.payloadDigest)?.contract?.requirements ?? [];
    const verificationRecord = prior
      .filter((candidate) => candidate.type === "independent-verification")
      .at(-1);
    const verification = payloads.get(verificationRecord?.payloadDigest);
    let consistent =
      ["controller-outcome-v1", "controller-outcome-v2"].includes(reading?.policy) &&
      declared.length > 0 &&
      tasks.length === declared.length &&
      reading?.requirements?.length === requirements.length;
    if (reading?.policy === "controller-outcome-v2") {
      const board = readControllerHistory(prior, payloads);
      consistent &&=
        board.problems.length === 0 &&
        board.graph?.revision === reading.graphRevision &&
        equalIds(
          board.graph?.obligations ?? [],
          declared.map((task) => task.id),
        );
      for (const [index, task] of declared.entries()) {
        const current = tasks[index];
        const members =
          board.graph?.nodes
            .filter((node) => node.obligations.includes(task.id))
            .map((node) => node.id) ?? [];
        const allAccepted = members.length > 0 && members.every((id) => board.accepted.has(id));
        consistent &&=
          current?.id === task.id &&
          equalIds(current?.members ?? [], members) &&
          (current?.state === "accepted") === allAccepted &&
          (!allAccepted ||
            members.some((id) => board.accepted.get(id)?.workerId === current.workerId));
      }
    } else {
      for (const [index, task] of declared.entries()) {
        const current = tasks[index];
        const workers = prior
          .filter(
            (candidate) =>
              candidate.type === "worker-finished" &&
              payloads.get(candidate.payloadDigest)?.taskId === task.id,
          )
          .map((candidate) => payloads.get(candidate.payloadDigest));
        const landed = workers.find((worker) =>
          prior.some(
            (candidate) =>
              candidate.type === "merge-attempt" &&
              payloads.get(candidate.payloadDigest)?.workerId === worker.workerId &&
              payloads.get(candidate.payloadDigest)?.landed === true,
          ),
        );
        consistent &&=
          current?.id === task.id &&
          (current?.state === "accepted") === (landed !== undefined) &&
          (landed === undefined || current.workerId === landed.workerId);
      }
    }
    for (const [index, requirement] of requirements.entries()) {
      consistent &&=
        reading.requirements[index]?.id === requirement.id &&
        reading.requirements[index]?.status ===
          (verification?.goalAcceptance?.obligations.find(
            (obligation) => obligation.id === requirement.id,
          )?.status ?? "unjudged");
    }
    const integrated = tasks.length > 0 && tasks.every((task) => task.state === "accepted");
    const accepted =
      integrated &&
      reading.status !== "cancelled" &&
      verification?.verified === true &&
      requirements.length > 0 &&
      reading.requirements.every((requirement) => requirement.status === "accepted");
    const status =
      reading.status === "cancelled"
        ? "cancelled"
        : accepted
          ? "accepted"
          : integrated && goal === undefined
            ? "integrated"
            : "blocked";
    record(
      `controller outcome ${entry.sequence} re-derived`,
      consistent &&
        reading.goalAccepted === accepted &&
        reading.status === status &&
        reading.exitCode ===
          (status === "cancelled" ? 130 : ["accepted", "integrated"].includes(status) ? 0 : 1),
      "all declared tasks and requirements govern the terminal outcome",
    );
  }
  for (const entry of records.filter((candidate) => candidate.type === "run-assessment")) {
    const assessment = payloads.get(entry.payloadDigest);
    const inputs = assessment?.inputs;
    const verdict = assessment?.verdict;
    if (inputs?.policy === "run-acceptance-v3") {
      const prior = records.filter((candidate) => candidate.sequence < entry.sequence);
      const previous = prior.filter((candidate) => candidate.type === "run-assessment").at(-1);
      const verification = prior.find(
        (candidate) =>
          candidate.type === "independent-verification" &&
          candidate.payloadDigest === inputs.independentRecord &&
          candidate.sequence > (previous?.sequence ?? -1),
      );
      const source = prior.find(
        (candidate) =>
          candidate.type === "workspace-diff" &&
          candidate.payloadDigest === inputs.sourceRecord &&
          candidate.sequence < (previous?.sequence ?? -1),
      );
      const base = payloads.get(previous?.payloadDigest);
      const observed = payloads.get(verification?.payloadDigest);
      const diff = payloads.get(source?.payloadDigest);
      const sealed = payloads.get(
        prior.find((candidate) => candidate.type === "run-spec-sealed")?.payloadDigest,
      );
      const task = observed?.task === "vacuous" ? "unjudged" : observed?.task;
      const expected = {
        ...base?.verdict,
        task,
        acceptable: base?.verdict?.acceptable === true && observed?.verified === true,
        reasons: {
          ...base?.verdict?.reasons,
          task: observed?.advice || `pinned goal checks: ${observed?.task}`,
        },
      };
      record(
        `run assessment ${entry.sequence} re-derived`,
        previous?.payloadDigest === inputs.previousAssessment &&
          ["run-acceptance-v1", "run-acceptance-v2"].includes(base?.inputs?.policy) &&
          verification !== undefined &&
          source !== undefined &&
          observed?.certificationPolicy === "goal-obligations-v1" &&
          diff?.rawPatchDigest === observed?.sourcePatchDigest &&
          sealed?.spec?.repository?.baseCommit === observed?.sourceBase &&
          canonicalJson(verdict) === canonicalJson(expected),
        "final pinned goal verdict is conjoined with the worker assessment at the same source",
      );
      continue;
    }
    let consistent =
      ["run-acceptance-v1", "run-acceptance-v2"].includes(inputs?.policy) &&
      typeof verdict?.acceptable === "boolean";
    const prior = records.filter((candidate) => candidate.sequence < entry.sequence);
    const lookupKind = (digest, kind) =>
      prior.some((candidate) => candidate.payloadDigest === digest && candidate.type === kind);
    const gateRecords = Array.isArray(inputs?.gateRecords) ? inputs.gateRecords : [];
    const gates = gateRecords.map((digest) => payloads.get(digest));
    consistent &&= gateRecords.every((digest) => lookupKind(digest, "gate-run"));
    const previousAssessment =
      prior.filter((candidate) => candidate.type === "run-assessment").at(-1)?.sequence ?? -1;
    const thisRun = prior.filter((candidate) => candidate.sequence > previousAssessment);
    const latestGates = new Map(
      thisRun
        .filter((candidate) => candidate.type === "gate-run")
        .map((candidate) => [
          payloads.get(candidate.payloadDigest)?.gateId,
          candidate.payloadDigest,
        ]),
    );
    consistent &&=
      gateRecords.length === latestGates.size &&
      new Set(gateRecords).size === gateRecords.length &&
      [...latestGates.values()].every((digest) => gateRecords.includes(digest));
    const measured = Object.assign({}, ...gates.map((gate) => gate?.measures ?? {}));
    consistent &&= inputs?.changedFiles === (measured.changedFiles ?? 0);
    const stop = thisRun.filter((candidate) => candidate.type === "session-stopped").at(-1);
    consistent &&=
      inputs?.lifecycleRecord === (stop?.payloadDigest ?? null) &&
      (stop === undefined
        ? inputs?.lifecycle === "completed"
        : payloads.get(stop.payloadDigest)?.stopReason === inputs?.lifecycle);
    consistent &&=
      inputs?.settled ===
      (thisRun.some((candidate) => candidate.type === "escalation") ? "escalated" : "green");

    const base = payloads.get(inputs?.baseRatchetRecord);
    consistent &&=
      lookupKind(inputs?.baseRatchetRecord, "ratchet-decision") &&
      base?.scope === "base" &&
      base?.accepted === inputs?.baseRatchetAccepted;
    const blockingVacuous = bonds
      .filter(
        (bond) =>
          bond.sequence < entry.sequence &&
          bond.sequence > previousAssessment &&
          bond.payload.severity === "blocking" &&
          bond.payload.verdict === "vacuous",
      )
      .map((bond) => bond.payload.gateId);
    consistent &&= JSON.stringify(blockingVacuous) === JSON.stringify(inputs?.vacuousBlockingBonds);
    const requiredChecks = inputs?.policy === "run-acceptance-v2" ? inputs.requiredChecks : [];
    if (inputs?.policy === "run-acceptance-v2") {
      const contract = payloads.get(inputs.contractRecord);
      consistent &&=
        lookupKind(inputs.contractRecord, "task-contract") &&
        contract?.phase === "effective" &&
        Array.isArray(requiredChecks) &&
        canonicalJson(contract.requiredChecks) === canonicalJson(requiredChecks);
    }
    const requiredPassed =
      Array.isArray(requiredChecks) &&
      requiredChecks.every((id) =>
        gates.some((gate) => gate?.gateId === id && gate.status === "passed"),
      );
    const failed = gates.some((gate) => gate?.severity === "blocking" && gate.status === "failed");
    const policyFailed = gates.some(
      (gate) => gate?.capability === "policy" && gate.status === "failed",
    );
    const dynamic = gates.filter((gate) => gate?.capability === "dynamic");
    const executed =
      inputs?.changedFiles === 0 ||
      (dynamic.some((gate) => gate.status === "passed") &&
        !dynamic.some((gate) => gate.status === "failed"));
    const acceptable =
      requiredPassed &&
      inputs?.settled === "green" &&
      base?.accepted === true &&
      inputs?.cancelled === false &&
      !["interrupted", "max-wall-time", "max-tokens"].includes(inputs?.lifecycle) &&
      (inputs?.changedFiles > 0 || inputs?.lifecycle === "completed") &&
      blockingVacuous.length === 0 &&
      !failed &&
      !policyFailed &&
      executed &&
      verdict?.task !== "rejected" &&
      !["required", "rejected"].includes(verdict?.humanApproval);
    record(
      `run assessment ${entry.sequence} re-derived`,
      consistent && verdict?.acceptable === acceptable,
      `recorded ${verdict?.acceptable}, evidence implies ${acceptable}`,
    );
  }
  const vacuous = bonds.filter((entry) => entry.payload.verdict === "vacuous");

  return { checks, verdicts, payloads, manifest, vacuous };
}

/** Does any payload in this bundle name that chain head? That is the coordinator's linkage. */
function namesChainHead(payloads, chainHead) {
  for (const payload of payloads.values()) {
    if (payload !== null && typeof payload === "object" && payload.chainHead === chainHead) {
      return true;
    }
  }
  return false;
}

function equalIds(left, right) {
  return canonicalJson(left) === canonicalJson(right);
}

export function verifyBundle(directory, write = console.log) {
  const top = collectChecks(directory);
  const checks = [...top.checks];
  const sections = [{ title: null, verdicts: top.verdicts }];

  for (const worker of top.manifest?.workers ?? []) {
    const label = `worker ${worker.workerId}`;
    const nested = collectChecks(join(directory, worker.directory));
    for (const check of nested.checks) {
      checks.push({ ...check, name: `${label}: ${check.name}` });
    }
    checks.push({
      name: `${label}: chain head matches the one this manifest lists`,
      ok: nested.manifest?.chainHead === worker.chainHead,
      detail: `listed ${worker.chainHead}, its own manifest says ${nested.manifest?.chainHead ?? "nothing"}`,
    });
    checks.push({
      name: `${label}: named by a coordinator record`,
      ok: namesChainHead(top.payloads, worker.chainHead),
      detail: namesChainHead(top.payloads, worker.chainHead)
        ? "a coordinator record carries this chain head"
        : "no coordinator record carries this chain head, so the signature says nothing about it",
    });
    sections.push({ title: label, verdicts: nested.verdicts });
  }

  for (const entry of top.vacuous ?? []) {
    write("");
    write(
      `  VACUOUS    record ${entry.sequence}: the ${entry.payload.gateId} gate passed over its bond` +
        ` (${entry.payload.bond?.description ?? "no description"}), so that pass cannot fail`,
    );
  }

  for (const section of sections) {
    if (section.verdicts.length === 0) {
      continue;
    }
    write("");
    if (section.title !== null) {
      write(`  ${section.title}`);
    }
    for (const entry of section.verdicts) {
      const mark = entry.evaluation.verdict === "verified" ? "VERIFIED  " : "UNVERIFIED";
      const reason = entry.evaluation.reason === null ? "" : ` [${entry.evaluation.reason}]`;
      write(
        `  ${mark} record ${entry.sequence}: ${entry.claim?.predicate ?? "(no predicate)"}${reason}`,
      );
    }
  }

  return report(checks, write);
}

function report(checks, write) {
  write("");
  for (const check of checks) {
    write(
      `  ${check.ok ? "PASS" : "FAIL"}  ${check.name}${check.detail ? `: ${check.detail}` : ""}`,
    );
  }
  const failed = checks.filter((check) => !check.ok).length;
  write("");
  write(
    failed === 0
      ? "bundle verified: every check passed"
      : `bundle FAILED: ${failed} check(s) did not pass`,
  );
  return failed === 0 ? 0 : 1;
}

// Exported above so the project's own tests can check that this reimplementation agrees
// with the one in src/evidence. Importing the file must not run a verification.
// realpath first: on macOS the temp directory is a symlink, and the ESM loader reports the
// resolved path while argv does not.
const entry =
  process.argv[1] === undefined ? null : pathToFileURL(realpathSync(process.argv[1])).href;
if (entry === import.meta.url) {
  const target = process.argv[2] ?? ".";
  console.log(`verifying bundle at ${target}`);
  process.exitCode = verifyBundle(target);
}

/** Independently re-read eligibility, usage and ordering; a selection cannot testify about itself. */
export function goalSelectionConformance(records, payloads) {
  return records
    .filter((entry) => entry.type === "goal-attempt-selection")
    .map((entry) => {
      const problems = [];
      const require = (condition, reason) => {
        if (!condition) throw new Error(reason);
      };
      try {
        const selection = payloads.get(entry.payloadDigest);
        require(entry.actor === "harness" &&
          selection?.policy ===
            "complete-goal-selection-v1", "goal selection lacks harness authority or its declared policy");
        const prior = records.filter((record) => record.sequence < entry.sequence);
        const declaration = prior.find(
          (record) => record.type === "goal-contract" && record.actor === "harness",
        );
        const contract = payloads.get(declaration?.payloadDigest)?.contract;
        require(contract &&
          Array.isArray(contract.requirements) &&
          contract.requirements.length > 0, "goal selection has no pinned requirement set");
        require(selection.objective ===
          (contract.selection === "cost"
            ? "reported-model-tokens"
            : contract.selection), "goal selection changed the declared objective");
        const candidates = selection.candidates;
        require(Array.isArray(candidates) &&
          candidates.length > 0 &&
          new Set(candidates.map((candidate) => candidate.workerId)).size ===
            candidates.length, "goal candidate identities are missing or duplicated");
        for (const candidate of candidates) {
          require(candidate.baseCommit ===
            selection.baseCommit, "goal candidates do not share a base");
          const captured = prior.find(
            (record) =>
              record.type === "controller-candidate" &&
              record.actor === "harness" &&
              payloads.get(record.payloadDigest)?.workerId === candidate.workerId,
          );
          const producer = payloads.get(captured?.payloadDigest);
          require(producer &&
            producer.taskId === selection.taskId &&
            producer.baseCommit === selection.baseCommit &&
            producer.attemptIndex ===
              candidate.attemptIndex, "goal candidate lacks its captured task, base and attempt");
          let obligations = [];
          let regression = false;
          if (candidate.verification !== null) {
            const record = prior.find(
              (record) =>
                record.type === "goal-candidate-verification" &&
                record.actor === "harness" &&
                record.payloadDigest === candidate.verification,
            );
            const observation = payloads.get(record?.payloadDigest);
            require(observation?.workerId === candidate.workerId &&
              observation?.baseCommit ===
                candidate.baseCommit, "goal candidate cites another attempt's verification");
            const verified = observation.verification;
            const goalRecord = prior
              .filter(
                (one) =>
                  one.sequence < record.sequence &&
                  one.type === "goal-verification" &&
                  one.actor === "harness",
              )
              .at(-1);
            const goal = payloads.get(goalRecord?.payloadDigest);
            require(goal &&
              canonicalJson(goal) === canonicalJson(verified.goalAcceptance) &&
              goal.tree ===
                observation.tree, "candidate verification is not bound to its goal observations and tree");
            require(verified.verified ===
              (verified.regression === "pass" &&
                goal.accepted === true), "candidate verification disagrees with its goal policy");
            obligations = goal.obligations.map((obligation) => ({
              id: obligation.id,
              accepted: obligation.status === "accepted",
            }));
            regression =
              producer.green &&
              verified.regression === "pass" &&
              !verified.checks.some((check) => check.status === "failed");
            require(candidate.changedFiles === observation.changedFiles &&
              candidate.changedLines ===
                observation.changedLines, "candidate change size differs from the captured Git observation");
          }
          require(canonicalJson(candidate.obligations) === canonicalJson(obligations) &&
            candidate.regressionPassed ===
              regression, "selection altered its candidate acceptance");
          const events = prior
            .filter((record) => record.type === "controller-event" && record.actor === "harness")
            .map((record) => payloads.get(record.payloadDigest));
          const calls = events.filter(
            (event) => event?.kind === "usage-reserved" && event.activity === candidate.workerId,
          );
          let count = calls.length > 0 ? 0 : null;
          for (const call of calls) {
            const settled = events.find(
              (event) => event?.kind === "usage-settled" && event.id === call.id,
            );
            if (
              settled?.status !== "reported" ||
              !Number.isInteger(settled.inputTokens) ||
              !Number.isInteger(settled.outputTokens)
            ) {
              count = null;
              break;
            }
            count += settled.inputTokens + settled.outputTokens;
          }
          require(candidate.tokenCount ===
            count, "selection altered reported or unknown provider usage");
          const missing = contract.requirements.filter(
            (requirement) =>
              requirement.checks.length === 0 ||
              !obligations.some((observed) => observed.id === requirement.id && observed.accepted),
          );
          const reason =
            candidate.verification === null
              ? "no independent verification"
              : !regression
                ? "required integrated checks did not pass"
                : missing.length > 0
                  ? `unaccepted requirements: ${missing.map((requirement) => requirement.id).join(", ")}`
                  : null;
          require(candidate.eligible === (reason === null) &&
            candidate.reason ===
              reason, "goal eligibility does not cover every pinned requirement");
        }
        const eligible = candidates.filter((candidate) => candidate.eligible);
        const measured = eligible.some((candidate) => candidate.tokenCount !== null);
        const ordered = [...eligible]
          .sort((left, right) => {
            if (selection.objective === "reported-model-tokens" && measured) {
              if (left.tokenCount === null)
                return right.tokenCount === null ? left.attemptIndex - right.attemptIndex : 1;
              if (right.tokenCount === null) return -1;
              if (left.tokenCount !== right.tokenCount) return left.tokenCount - right.tokenCount;
            }
            if (selection.objective !== "stable") {
              const size =
                left.changedLines - right.changedLines || left.changedFiles - right.changedFiles;
              if (size !== 0) return size;
            }
            return left.attemptIndex - right.attemptIndex;
          })
          .map((candidate) => candidate.workerId);
        require(canonicalJson(ordered) === canonicalJson(selection.order) &&
          selection.winner ===
            (ordered[0] ??
              null), "goal ranking disagrees with its declared objective and stable tie-break");
        const abstentions =
          selection.objective === "reported-model-tokens" && !measured
            ? ["provider token usage was not measured; monetary cost is also unavailable"]
            : [];
        require(canonicalJson(abstentions) ===
          canonicalJson(selection.abstentions), "goal selection hides an unmeasured dimension");
      } catch (cause) {
        problems.push(cause instanceof Error ? cause.message : String(cause));
      }
      return { sequence: entry.sequence, problems };
    });
}
