// The development study's three exposed tasks, re-exported unchanged from their published modules.
import { tasks as block1 } from "/Users/brad/.cache/swarm-heldout-2026-10-22/sealed/heldout-tasks.mjs";
import { tasks as block2 } from "/Users/brad/.cache/swarm-heldout-2026-10-23/sealed/heldout-tasks.mjs";

const ids = [
  "svgo-bugfix-remove-scripts-anchor-bypass",
  "markdown-it-feature-reference-definition-token",
  "p-limit-bugfix-limit-function-clear-queue",
];
export const tasks = [...block1, ...block2].filter((task) => ids.includes(task.id));
