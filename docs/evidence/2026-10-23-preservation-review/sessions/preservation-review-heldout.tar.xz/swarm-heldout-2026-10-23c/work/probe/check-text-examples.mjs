import { createRequire } from "node:module";
const root = process.argv[2] + "/";
const { createJiti } = createRequire(root + "package.json")("jiti");
const u = await createJiti(root).import(root + "src/index.ts");
const ex = [["withoutBase","/admin-dashboard","/admin"],["withoutBase","/administrator","/admin/"],["withBase","/admin-dashboard","/admin"],["withBase","/apix","/api"],["withBase","/a/bc","/a/b/"],["withoutBase","/admin-dashboard","/admin/"],["withoutBase","/v10/items","/v1"],["withBase","/api?x=1","/api"],["withoutBase","/api?test","/api"],["withoutBase","/base","/base/"],["withBase","/a/b","/a/b"],["withoutBase","/admin/admin-dashboard","/admin/"],["withoutBase","https://x.com/base/p","https://x.com/base"]];
for (const [f,i,b] of ex) console.log(f, i, b, "=>", u[f](i,b));
