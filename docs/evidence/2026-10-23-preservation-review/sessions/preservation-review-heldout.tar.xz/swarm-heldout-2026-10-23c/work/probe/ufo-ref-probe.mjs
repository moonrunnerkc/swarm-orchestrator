import { createRequire } from "node:module";
const root = process.argv[2] + "/";
const { createJiti } = createRequire(root + "package.json")("jiti");
const u = await createJiti(root).import(root + "src/index.ts");
const f = u.filterQuery;
const notBar = (k) => k !== "bar";
const cases = [
 ["/foo?bar=1&baz=2", notBar], ["/foo?bar=1", notBar], ["/foo?a=1&a=2&bar=3#frag", notBar],
 ["https://example.com/p?q=%20x&bar=1", (k, v) => v !== "1"], ["https://user:pw@example.com:8080/p/a?bar=1&q=%20x+y#h", notBar],
 ["?bar=1&c=3", notBar], ["//cdn.example.com/x?bar=1&y", notBar], ["/x?a=%2F&bar", notBar], ["/foo#h?bar=1", () => false],
 ["file:///C:/x?bar=1&k=v", notBar], ["file:///C:/x", () => false], ["/foo?", () => true], ["/p?x=1&&bar=2&", notBar],
 ["/p?__proto__=1&bar=2&z=3", notBar], ["/p?a=1&b=2&c=1", (k, v) => v === "1"], ["/p?a=1&a=2&b=3", (k, v) => Array.isArray(v)],
 ["/p?caf%C3%A9=1&bar=2", notBar], ["http://a.com/b?x=a%26b&bar=&y=%3D", notBar], ["/foo?bar=1&baz=2", () => false],
];
for (const [i, p] of cases) console.log(JSON.stringify(i), JSON.stringify(f(i, p)), JSON.stringify(u.withQuery(i, {})), JSON.stringify(f(i, () => true)));
const calls = []; f("/p?b=2&a=1&a=3&caf%C3%A9=x", (...args) => { calls.push(args); return true; }); console.log(JSON.stringify(calls));
