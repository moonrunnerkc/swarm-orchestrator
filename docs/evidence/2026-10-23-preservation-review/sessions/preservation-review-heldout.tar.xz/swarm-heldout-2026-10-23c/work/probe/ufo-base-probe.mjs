import { createRequire } from "node:module";
const root = process.argv[2] + "/";
const { createJiti } = createRequire(root + "package.json")("jiti");
const u = await createJiti(root).import(root + "src/index.ts");
const bases = ["/admin", "/admin/", "/", "", "/a/b", "/a/b/", "/api", "https://x.com/base"];
const inputs = ["/admin", "/admin/", "/admin-dashboard", "/admin/x", "/adminx/y", "/admin?q=1", "/admin#h", "/administrator", "/admin.html", "/admin//x", "/a/b", "/a/bc", "/a/b/c", "/a/b?x", "/apix", "/api", "/api/v1", "https://x.com/base/p", "https://x.com/basement", "", "/", "admin", "/x"];
for (const b of bases) for (const i of inputs) console.log(JSON.stringify([b, i]), "with:", JSON.stringify(u.withBase(i, b)), "without:", JSON.stringify(u.withoutBase(i, b)));
