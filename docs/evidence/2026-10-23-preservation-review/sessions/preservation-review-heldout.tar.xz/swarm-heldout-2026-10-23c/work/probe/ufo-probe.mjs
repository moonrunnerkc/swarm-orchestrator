import { createRequire } from "node:module";
const root = process.argv[2] + "/";
const { createJiti } = createRequire(root + "package.json")("jiti");
const jiti = createJiti(root);
const u = await jiti.import(root + "src/index.ts");
const inputs = ["/foo", "/foo?", "/foo?bar=1", "/foo?bar=1&baz=2", "/foo?a=1&a=2&bar=3#frag", "https://user:pw@example.com:8080/p/a?bar=1&q=%20x+y#h", "?bar=1&c=3", "//cdn.example.com/x?bar=1&y", "/x?a=%2F&bar", "/foo#h?bar=1", "file:///C:/x?bar=1&k=v", "/foo?bar", "/p?x=1&&bar=2&", "/p?__proto__=1&bar=2&z=3"];
for (const i of inputs) {
  const p = u.parseURL(i);
  console.log(JSON.stringify(i), "->", JSON.stringify(u.stringifyParsedURL({ ...p, search: u.stringifyQuery(Object.fromEntries(Object.entries(u.parseQuery(p.search)).filter(([k]) => k !== "bar"))) })), "| withQuery:", JSON.stringify(u.withQuery(i, {})), "| getQuery:", JSON.stringify(u.getQuery(i)));
}
console.log(Object.keys(u).length, Object.keys(u).sort().join(","));
