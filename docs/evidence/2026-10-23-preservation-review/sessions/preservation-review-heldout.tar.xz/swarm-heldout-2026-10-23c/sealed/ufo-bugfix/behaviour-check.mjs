// Hidden behaviour check: withBase and withoutBase treat a base as present only where it ends at a
// path-segment boundary of the input. Written into the scoring checkout at acceptance/hidden/ only
// at scoring time, after the project tests.
import assert from "node:assert/strict";
import { createJiti } from "jiti";

const { withBase, withoutBase } = await createJiti(import.meta.url).import("../../src/index.ts");
const failures = [];
const check = (name, fn) => {
  try {
    fn();
  } catch (error) {
    failures.push(`${name}: ${String(error && error.message).split("\n").slice(0, 6).join(" | ")}`);
  }
};
// [base, input, withBase result, withoutBase result] where input continues past the base text
// inside a path segment, so the base is not present.
const cases = [
  ["/admin", "/admin-dashboard", "/admin/admin-dashboard", "/admin-dashboard"],
  ["/admin/", "/admin-dashboard", "/admin/admin-dashboard", "/admin-dashboard"],
  ["/admin", "/administrator", "/admin/administrator", "/administrator"],
  ["/admin/", "/administrator", "/admin/administrator", "/administrator"],
  ["/admin", "/admin.html", "/admin/admin.html", "/admin.html"],
  ["/admin", "/adminx/y", "/admin/adminx/y", "/adminx/y"],
  ["/admin/", "/adminx/y", "/admin/adminx/y", "/adminx/y"],
  ["/a/b", "/a/bc", "/a/b/a/bc", "/a/bc"],
  ["/a/b/", "/a/bc/d?x=1", "/a/b/a/bc/d?x=1", "/a/bc/d?x=1"],
  ["/api", "/apix", "/api/apix", "/apix"],
  ["/api", "/api_v2/users", "/api/api_v2/users", "/api_v2/users"],
  ["/v1", "/v10/items", "/v1/v10/items", "/v10/items"],
];
for (const [base, input, joined, kept] of cases) {
  check(`withBase(${JSON.stringify(input)}, ${JSON.stringify(base)})`, () => assert.equal(withBase(input, base), joined));
  check(`withoutBase(${JSON.stringify(input)}, ${JSON.stringify(base)})`, () => assert.equal(withoutBase(input, base), kept));
}
check("withoutBase with a full URL base that only prefixes the input text", () =>
  assert.equal(withoutBase("https://x.com/basement", "https://x.com/base"), "https://x.com/basement"),
);
// The same bases still match at a boundary.
const boundaries = [
  ["/admin", "/admin/dashboard", "/admin/dashboard", "/dashboard"],
  ["/admin/", "/admin/admin-dashboard", "/admin/admin-dashboard", "/admin-dashboard"],
  ["/a/b", "/a/b", "/a/b", "/"],
  ["/v1", "/v1/v10", "/v1/v10", "/v10"],
];
for (const [base, input, joined, stripped] of boundaries) {
  check(`boundary withBase(${JSON.stringify(input)}, ${JSON.stringify(base)})`, () => assert.equal(withBase(input, base), joined));
  check(`boundary withoutBase(${JSON.stringify(input)}, ${JSON.stringify(base)})`, () => assert.equal(withoutBase(input, base), stripped));
}
check("withBase and withoutBase round-trip a non-matching path", () => {
  for (const [base, input] of cases.slice(0, 10)) assert.equal(withoutBase(withBase(input, base), base), input);
});

if (failures.length > 0) {
  console.error(`${failures.length} behaviour check(s) failed:`);
  for (const failure of failures.slice(0, 40)) console.error(`- ${failure}`);
  process.exit(1);
}
console.log("behaviour check passed");
