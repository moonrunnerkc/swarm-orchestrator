// Hidden behaviour check: filterQuery(input, predicate) exported from the package entry, keeping
// only the parameters the predicate accepts and rebuilding the URL as withQuery does. Written
// into the scoring checkout at acceptance/hidden/ only at scoring time, after the project tests.
import assert from "node:assert/strict";
import { createJiti } from "jiti";

const u = await createJiti(import.meta.url).import("../../src/index.ts");
const failures = [];
const check = (name, fn) => {
  try {
    fn();
  } catch (error) {
    failures.push(`${name}: ${String(error && error.message).split("\n").slice(0, 6).join(" | ")}`);
  }
};
const notBar = (key) => key !== "bar";

check("filterQuery is a function exported from src/index.ts", () => {
  assert.equal(typeof u.filterQuery, "function");
});

if (typeof u.filterQuery === "function") {
  const filterQuery = u.filterQuery;
  // An input with no "?" comes back exactly as given, whatever the predicate says.
  for (const input of ["/foo", "file:///C:/x", "http://example.com", "", "/a b", "#frag", "//host/p", "/p#a=1"]) {
    check(`no query: ${JSON.stringify(input)}`, () => {
      assert.equal(filterQuery(input, () => false), input);
      assert.equal(filterQuery(input, () => true), input);
    });
  }
  // Accepting every parameter gives what withQuery(input, {}) gives (as recorded on the base).
  const identity = [
    ["/foo?", "/foo"],
    ["/foo?bar=1&baz=2", "/foo?bar=1&baz=2"],
    ["/foo?a=1&a=2&bar=3#frag", "/foo?a=1&a=2&bar=3#frag"],
    ["https://user:pw@example.com:8080/p/a?bar=1&q=%20x+y#h", "https://user:pw@example.com:8080/p/a?bar=1&q=+x+y#h"],
    ["//cdn.example.com/x?bar=1&y", "//cdn.example.com/x?bar=1&y"],
    ["file:///C:/x?bar=1&k=v", "file://C:/x?bar=1&k=v"],
    ["/p?x=1&&bar=2&", "/p?x=1&bar=2"],
    ["/p?__proto__=1&bar=2&z=3", "/p?bar=2&z=3"],
    ["http://a.com/b?x=a%26b&bar=&y=%3D", "http://a.com/b?x=a%26b&bar&y=="],
    ["/foo#h?bar=1", "/foo#h?bar=1"],
  ];
  for (const [input, expected] of identity) {
    check(`accept all: ${JSON.stringify(input)}`, () => assert.equal(filterQuery(input, () => true), expected));
  }
  const filtered = [
    ["/foo?bar=1&baz=2", notBar, "/foo?baz=2"],
    ["/foo?bar=1", notBar, "/foo"],
    ["/foo?bar=1&baz=2", () => false, "/foo"],
    ["/foo?a=1&a=2&bar=3#frag", notBar, "/foo?a=1&a=2#frag"],
    ["https://example.com/p?q=%20x&bar=1", (key, value) => value !== "1", "https://example.com/p?q=+x"],
    ["https://user:pw@example.com:8080/p/a?bar=1&q=%20x+y#h", notBar, "https://user:pw@example.com:8080/p/a?q=+x+y#h"],
    ["?bar=1&c=3", notBar, "?c=3"],
    ["//cdn.example.com/x?bar=1&y", notBar, "//cdn.example.com/x?y"],
    ["/x?a=%2F&bar", notBar, "/x?a=%2F"],
    ["file:///C:/x?bar=1&k=v", notBar, "file://C:/x?k=v"],
    ["/p?x=1&&bar=2&", notBar, "/p?x=1"],
    ["/p?__proto__=1&bar=2&z=3", notBar, "/p?z=3"],
    ["/p?a=1&b=2&c=1", (key, value) => value === "1", "/p?a=1&c=1"],
    ["/p?a=1&a=2&b=3", (key, value) => Array.isArray(value), "/p?a=1&a=2"],
    ["/p?caf%C3%A9=1&bar=2", (key) => key === "café", "/p?caf%C3%A9=1"],
    ["http://a.com/b?x=a%26b&bar=&y=%3D", notBar, "http://a.com/b?x=a%26b&y=="],
    ["/p?b=2&a=1", (key) => key === "a", "/p?a=1"],
  ];
  for (const [input, predicate, expected] of filtered) {
    check(`filter: ${JSON.stringify(input)} with ${predicate.toString()}`, () =>
      assert.equal(filterQuery(input, predicate), expected),
    );
  }
  check("the predicate sees each decoded key once, in order, with getQuery's value", () => {
    const calls = [];
    filterQuery("/p?b=2&a=1&a=3&caf%C3%A9=x&e", (...args) => {
      calls.push([args[0], args[1]]);
      return true;
    });
    assert.deepEqual(calls, [["b", "2"], ["a", ["1", "3"]], ["café", "x"], ["e", ""]]);
  });
  check("the input string is not altered and results do not depend on earlier calls", () => {
    const input = "/foo?bar=1&baz=2";
    assert.equal(filterQuery(input, notBar), "/foo?baz=2");
    assert.equal(filterQuery(input, () => true), "/foo?bar=1&baz=2");
    assert.equal(filterQuery(input, notBar), "/foo?baz=2");
  });
}

if (failures.length > 0) {
  console.error(`${failures.length} behaviour check(s) failed:`);
  for (const failure of failures.slice(0, 40)) console.error(`- ${failure}`);
  process.exit(1);
}
console.log("behaviour check passed");
