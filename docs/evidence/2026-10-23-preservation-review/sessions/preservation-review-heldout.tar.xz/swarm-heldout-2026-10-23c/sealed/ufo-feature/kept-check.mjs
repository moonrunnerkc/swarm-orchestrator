// Hidden kept-behaviour check: the existing query and URL functions behave as on the base, and
// every export of the base is still exported with the same type. Written into the scoring checkout
// at acceptance/hidden/ only at scoring time, after the project tests.
import assert from "node:assert/strict";
import { createJiti } from "jiti";

const BASE = {"exports":{"$URL":"function","cleanDoubleSlashes":"function","createURL":"function","decode":"function","decodePath":"function","decodeQueryKey":"function","decodeQueryValue":"function","encode":"function","encodeHash":"function","encodeHost":"function","encodeParam":"function","encodePath":"function","encodeQueryItem":"function","encodeQueryKey":"function","encodeQueryValue":"function","getQuery":"function","hasLeadingSlash":"function","hasProtocol":"function","hasTrailingSlash":"function","isEmptyURL":"function","isEqual":"function","isNonEmptyURL":"function","isRelative":"function","isSamePath":"function","isScriptProtocol":"function","joinRelativeURL":"function","joinURL":"function","normalizeURL":"function","parseAuth":"function","parseFilename":"function","parseHost":"function","parsePath":"function","parseQuery":"function","parseURL":"function","resolveURL":"function","stringifyParsedURL":"function","stringifyQuery":"function","withBase":"function","withFragment":"function","withHttp":"function","withHttps":"function","withLeadingSlash":"function","withProtocol":"function","withQuery":"function","withTrailingSlash":"function","withoutBase":"function","withoutFragment":"function","withoutHost":"function","withoutLeadingSlash":"function","withoutProtocol":"function","withoutTrailingSlash":"function"},"observed":{"withQuery":[["/foo","/foo?a","/foo","/foo?x=1&x=2","/foo?n=0&b=false&t=true","/foo?o=%7B%22k%22:1%7D","/foo?=e","/foo?bar=new&extra=a+b%26c","/foo","/foo?s=x%2Fy?z%23w"],["/foo","/foo?a","/foo","/foo?x=1&x=2","/foo?n=0&b=false&t=true","/foo?o=%7B%22k%22:1%7D","/foo?=e","/foo?bar=new&extra=a+b%26c","/foo","/foo?s=x%2Fy?z%23w"],["/foo?bar=1","/foo?bar=1&a","/foo","/foo?bar=1&x=1&x=2","/foo?bar=1&n=0&b=false&t=true","/foo?bar=1&o=%7B%22k%22:1%7D","/foo?bar=1&=e","/foo?bar=new&extra=a+b%26c","/foo?bar=1","/foo?bar=1&s=x%2Fy?z%23w"],["/foo?bar=1&baz=2","/foo?bar=1&baz=2&a","/foo?baz=2","/foo?bar=1&baz=2&x=1&x=2","/foo?bar=1&baz=2&n=0&b=false&t=true","/foo?bar=1&baz=2&o=%7B%22k%22:1%7D","/foo?bar=1&baz=2&=e","/foo?bar=new&baz=2&extra=a+b%26c","/foo?bar=1&baz=2","/foo?bar=1&baz=2&s=x%2Fy?z%23w"],["/foo?a=1&a=2&bar=3#frag","/foo?a&bar=3#frag","/foo?a=1&a=2#frag","/foo?a=1&a=2&bar=3&x=1&x=2#frag","/foo?a=1&a=2&bar=3&n=0&b=false&t=true#frag","/foo?a=1&a=2&bar=3&o=%7B%22k%22:1%7D#frag","/foo?a=1&a=2&bar=3&=e#frag","/foo?a=1&a=2&bar=new&extra=a+b%26c#frag","/foo?bar=3#frag","/foo?a=1&a=2&bar=3&s=x%2Fy?z%23w#frag"],["https://user:pw@example.com:8080/p/a?bar=1&q=+x+y#h","https://user:pw@example.com:8080/p/a?bar=1&q=+x+y&a#h","https://user:pw@example.com:8080/p/a?q=+x+y#h","https://user:pw@example.com:8080/p/a?bar=1&q=+x+y&x=1&x=2#h","https://user:pw@example.com:8080/p/a?bar=1&q=+x+y&n=0&b=false&t=true#h","https://user:pw@example.com:8080/p/a?bar=1&q=+x+y&o=%7B%22k%22:1%7D#h","https://user:pw@example.com:8080/p/a?bar=1&q=+x+y&=e#h","https://user:pw@example.com:8080/p/a?bar=new&q=+x+y&extra=a+b%26c#h","https://user:pw@example.com:8080/p/a?bar=1&q=+x+y#h","https://user:pw@example.com:8080/p/a?bar=1&q=+x+y&s=x%2Fy?z%23w#h"],["?bar=1&c=3","?bar=1&c=3&a","?c=3","?bar=1&c=3&x=1&x=2","?bar=1&c=3&n=0&b=false&t=true","?bar=1&c=3&o=%7B%22k%22:1%7D","?bar=1&c=3&=e","?bar=new&c=3&extra=a+b%26c","?bar=1&c=3","?bar=1&c=3&s=x%2Fy?z%23w"],["//cdn.example.com/x?bar=1&y","//cdn.example.com/x?bar=1&y&a","//cdn.example.com/x?y","//cdn.example.com/x?bar=1&y&x=1&x=2","//cdn.example.com/x?bar=1&y&n=0&b=false&t=true","//cdn.example.com/x?bar=1&y&o=%7B%22k%22:1%7D","//cdn.example.com/x?bar=1&y&=e","//cdn.example.com/x?bar=new&y&extra=a+b%26c","//cdn.example.com/x?bar=1&y","//cdn.example.com/x?bar=1&y&s=x%2Fy?z%23w"],["/x?a=%2F&bar","/x?a&bar","/x?a=%2F","/x?a=%2F&bar&x=1&x=2","/x?a=%2F&bar&n=0&b=false&t=true","/x?a=%2F&bar&o=%7B%22k%22:1%7D","/x?a=%2F&bar&=e","/x?a=%2F&bar=new&extra=a+b%26c","/x?bar","/x?a=%2F&bar&s=x%2Fy?z%23w"],["/foo#h?bar=1","/foo?a#h?bar=1","/foo#h?bar=1","/foo?x=1&x=2#h?bar=1","/foo?n=0&b=false&t=true#h?bar=1","/foo?o=%7B%22k%22:1%7D#h?bar=1","/foo?=e#h?bar=1","/foo?bar=new&extra=a+b%26c#h?bar=1","/foo#h?bar=1","/foo?s=x%2Fy?z%23w#h?bar=1"],["file://C:/x?bar=1&k=v","file://C:/x?bar=1&k=v&a","file://C:/x?k=v","file://C:/x?bar=1&k=v&x=1&x=2","file://C:/x?bar=1&k=v&n=0&b=false&t=true","file://C:/x?bar=1&k=v&o=%7B%22k%22:1%7D","file://C:/x?bar=1&k=v&=e","file://C:/x?bar=new&k=v&extra=a+b%26c","file://C:/x?bar=1&k=v","file://C:/x?bar=1&k=v&s=x%2Fy?z%23w"],["file://C:/x","file://C:/x?a","file://C:/x","file://C:/x?x=1&x=2","file://C:/x?n=0&b=false&t=true","file://C:/x?o=%7B%22k%22:1%7D","file://C:/x?=e","file://C:/x?bar=new&extra=a+b%26c","file://C:/x","file://C:/x?s=x%2Fy?z%23w"],["/x?bar","/x?bar&a","/x","/x?bar&x=1&x=2","/x?bar&n=0&b=false&t=true","/x?bar&o=%7B%22k%22:1%7D","/x?bar&=e","/x?bar=new&extra=a+b%26c","/x?bar","/x?bar&s=x%2Fy?z%23w"],["/p?x=1&bar=2","/p?x=1&bar=2&a","/p?x=1","/p?x=1&x=2&bar=2","/p?x=1&bar=2&n=0&b=false&t=true","/p?x=1&bar=2&o=%7B%22k%22:1%7D","/p?x=1&bar=2&=e","/p?x=1&bar=new&extra=a+b%26c","/p?x=1&bar=2","/p?x=1&bar=2&s=x%2Fy?z%23w"],["/p?bar=2&z=3","/p?bar=2&z=3&a","/p?z=3","/p?bar=2&z=3&x=1&x=2","/p?bar=2&z=3&n=0&b=false&t=true","/p?bar=2&z=3&o=%7B%22k%22:1%7D","/p?bar=2&z=3&=e","/p?bar=new&z=3&extra=a+b%26c","/p?bar=2&z=3","/p?bar=2&z=3&s=x%2Fy?z%23w"],["/p?caf%C3%A9=1&bar=2","/p?caf%C3%A9=1&bar=2&a","/p?caf%C3%A9=1","/p?caf%C3%A9=1&bar=2&x=1&x=2","/p?caf%C3%A9=1&bar=2&n=0&b=false&t=true","/p?caf%C3%A9=1&bar=2&o=%7B%22k%22:1%7D","/p?caf%C3%A9=1&bar=2&=e","/p?caf%C3%A9=1&bar=new&extra=a+b%26c","/p?caf%C3%A9=1&bar=2","/p?caf%C3%A9=1&bar=2&s=x%2Fy?z%23w"],["http://a.com/b?x=a%26b&bar&y==","http://a.com/b?x=a%26b&bar&y==&a","http://a.com/b?x=a%26b&y==","http://a.com/b?x=1&x=2&bar&y==","http://a.com/b?x=a%26b&bar&y==&n=0&b=false&t=true","http://a.com/b?x=a%26b&bar&y==&o=%7B%22k%22:1%7D","http://a.com/b?x=a%26b&bar&y==&=e","http://a.com/b?x=a%26b&bar=new&y==&extra=a+b%26c","http://a.com/b?x=a%26b&bar&y==","http://a.com/b?x=a%26b&bar&y==&s=x%2Fy?z%23w"],["http://example.com","http://example.com?a","http://example.com","http://example.com?x=1&x=2","http://example.com?n=0&b=false&t=true","http://example.com?o=%7B%22k%22:1%7D","http://example.com?=e","http://example.com?bar=new&extra=a+b%26c","http://example.com","http://example.com?s=x%2Fy?z%23w"],["","?a","","?x=1&x=2","?n=0&b=false&t=true","?o=%7B%22k%22:1%7D","?=e","?bar=new&extra=a+b%26c","","?s=x%2Fy?z%23w"],["/a b?c+d=e+f","/a b?c+d=e+f&a","/a b?c+d=e+f","/a b?c+d=e+f&x=1&x=2","/a b?c+d=e+f&n=0&b=false&t=true","/a b?c+d=e+f&o=%7B%22k%22:1%7D","/a b?c+d=e+f&=e","/a b?c+d=e+f&bar=new&extra=a+b%26c","/a b?c+d=e+f","/a b?c+d=e+f&s=x%2Fy?z%23w"],["/p?a%5B%5D=1&a%5B%5D=2","/p?a%5B%5D=1&a%5B%5D=2&a","/p?a%5B%5D=1&a%5B%5D=2","/p?a%5B%5D=1&a%5B%5D=2&x=1&x=2","/p?a%5B%5D=1&a%5B%5D=2&n=0&b=false&t=true","/p?a%5B%5D=1&a%5B%5D=2&o=%7B%22k%22:1%7D","/p?a%5B%5D=1&a%5B%5D=2&=e","/p?a%5B%5D=1&a%5B%5D=2&bar=new&extra=a+b%26c","/p?a%5B%5D=1&a%5B%5D=2","/p?a%5B%5D=1&a%5B%5D=2&s=x%2Fy?z%23w"],["/p?x&y","/p?x&y&a","/p?x&y","/p?x=1&x=2&y","/p?x&y&n=0&b=false&t=true","/p?x&y&o=%7B%22k%22:1%7D","/p?x&y&=e","/p?x&y&bar=new&extra=a+b%26c","/p?x&y","/p?x&y&s=x%2Fy?z%23w"]],"getQuery":[{"value":{},"protoFree":true},{"value":{},"protoFree":true},{"value":{"bar":"1"},"protoFree":true},{"value":{"bar":"1","baz":"2"},"protoFree":true},{"value":{"a":["1","2"],"bar":"3"},"protoFree":true},{"value":{"bar":"1","q":" x y"},"protoFree":true},{"value":{"bar":"1","c":"3"},"protoFree":true},{"value":{"bar":"1","y":""},"protoFree":true},{"value":{"a":"/","bar":""},"protoFree":true},{"value":{},"protoFree":true},{"value":{"bar":"1","k":"v"},"protoFree":true},{"value":{},"protoFree":true},{"value":{"bar":""},"protoFree":true},{"value":{"x":"1","bar":"2"},"protoFree":true},{"value":{"bar":"2","z":"3"},"protoFree":true},{"value":{"café":"1","bar":"2"},"protoFree":true},{"value":{"x":"a&b","bar":"","y":"="},"protoFree":true},{"value":{},"protoFree":true},{"value":{},"protoFree":true},{"value":{"c d":"e f"},"protoFree":true},{"value":{"a[]":["1","2"]},"protoFree":true},{"value":{"x":"","y":""},"protoFree":true}],"parseQuery":[{"value":{},"protoFree":true},{"value":{},"protoFree":true},{"value":{"a":"1"},"protoFree":true},{"value":{"a":["1","2","3"]},"protoFree":true},{"value":{"a":"","b":"","c":"1"},"protoFree":true},{"value":{"[k]":"v"},"protoFree":true},{"value":{"a":"1=2"},"protoFree":true},{"value":{" x":" y"},"protoFree":true},{"value":{"ok":"3"},"protoFree":true}],"stringifyQuery":["","a=1","a=1&a=2","b&c","n=1&f=false","a+b=c+d","o=%7B%22x%22:1%7D","arr=null&arr=undefined&arr=z"],"parseURL":[{"pathname":"/foo","search":"","hash":""},{"pathname":"/foo","search":"?","hash":""},{"pathname":"/foo","search":"?bar=1","hash":""},{"pathname":"/foo","search":"?bar=1&baz=2","hash":""},{"pathname":"/foo","search":"?a=1&a=2&bar=3","hash":"#frag"},{"protocol":"https:","auth":"user:pw","host":"example.com:8080","pathname":"/p/a","search":"?bar=1&q=%20x+y","hash":"#h"},{"pathname":"","search":"?bar=1&c=3","hash":""},{"protocol":"","auth":"","host":"cdn.example.com","pathname":"/x","search":"?bar=1&y","hash":""},{"pathname":"/x","search":"?a=%2F&bar","hash":""},{"pathname":"/foo","search":"","hash":"#h?bar=1"},{"protocol":"file:","auth":"","host":"","pathname":"C:/x","search":"?bar=1&k=v","hash":""},{"protocol":"file:","auth":"","host":"","pathname":"C:/x","search":"","hash":""},{"pathname":"/x","search":"?bar","hash":""},{"pathname":"/p","search":"?x=1&&bar=2&","hash":""},{"pathname":"/p","search":"?__proto__=1&bar=2&z=3&constructor=4","hash":""},{"pathname":"/p","search":"?caf%C3%A9=1&bar=2","hash":""},{"protocol":"http:","auth":"","host":"a.com","pathname":"/b","search":"?x=a%26b&bar=&y=%3D","hash":""},{"protocol":"http:","auth":"","host":"example.com","pathname":"","search":"","hash":""},{"pathname":"","search":"","hash":""},{"pathname":"/a b","search":"?c d=e f","hash":""},{"pathname":"/p","search":"?a[]=1&a[]=2","hash":""},{"pathname":"/p","search":"?=x&y=","hash":""}],"roundTrip":["/foo","/foo?","/foo?bar=1","/foo?bar=1&baz=2","/foo?a=1&a=2&bar=3#frag","https://user:pw@example.com:8080/p/a?bar=1&q=%20x+y#h","?bar=1&c=3","//cdn.example.com/x?bar=1&y","/x?a=%2F&bar","/foo#h?bar=1","file://C:/x?bar=1&k=v","file://C:/x","/x?bar","/p?x=1&&bar=2&","/p?__proto__=1&bar=2&z=3&constructor=4","/p?caf%C3%A9=1&bar=2","http://a.com/b?x=a%26b&bar=&y=%3D","http://example.com","","/a b?c d=e f","/p?a[]=1&a[]=2","/p?=x&y="]}};
const inputs = [
  "/foo", "/foo?", "/foo?bar=1", "/foo?bar=1&baz=2", "/foo?a=1&a=2&bar=3#frag",
  "https://user:pw@example.com:8080/p/a?bar=1&q=%20x+y#h", "?bar=1&c=3", "//cdn.example.com/x?bar=1&y",
  "/x?a=%2F&bar", "/foo#h?bar=1", "file:///C:/x?bar=1&k=v", "file:///C:/x", "/x?bar", "/p?x=1&&bar=2&",
  "/p?__proto__=1&bar=2&z=3&constructor=4", "/p?caf%C3%A9=1&bar=2", "http://a.com/b?x=a%26b&bar=&y=%3D",
  "http://example.com", "", "/a b?c d=e f", "/p?a[]=1&a[]=2", "/p?=x&y=",
];
const queries = [
  {}, { a: null }, { bar: undefined }, { x: [1, "2"] }, { n: 0, b: false, t: true }, { o: { k: 1 } },
  { "": "e" }, { bar: "new", extra: "a b&c" }, { a: [] }, { s: "x/y?z#w" },
];
const searches = ["", "?", "a=1", "?a=1&a=2&a=3", "a&b=&c=1", "%5Bk%5D=v", "a=1=2", "+x=+y", "__proto__=1&constructor=2&ok=3"];
const objects = [
  {}, { a: "1" }, { a: ["1", "2"] }, { a: undefined, b: null, c: "" }, { n: 1, f: false }, { "a b": "c d" },
  { o: { x: 1 } }, { arr: [null, undefined, "z"] },
];
function observe(u) {
  const plain = (value) => JSON.parse(JSON.stringify(value));
  const protoFree = (value) => !("toString" in value) && !("hasOwnProperty" in value);
  return {
    withQuery: inputs.map((input) => queries.map((query) => u.withQuery(input, query))),
    getQuery: inputs.map((input) => {
      const value = u.getQuery(input);
      return { value: plain(value), protoFree: protoFree(value) };
    }),
    parseQuery: searches.map((search) => {
      const value = u.parseQuery(search);
      return { value: plain(value), protoFree: protoFree(value) };
    }),
    stringifyQuery: objects.map((object) => u.stringifyQuery(object)),
    parseURL: inputs.map((input) => plain(u.parseURL(input))),
    roundTrip: inputs.map((input) => u.stringifyParsedURL(u.parseURL(input))),
  };
}

const u = await createJiti(import.meta.url).import("../../src/index.ts");
const failures = [];
for (const [name, type] of Object.entries(BASE.exports)) {
  if (typeof u[name] !== type) failures.push(`export ${name} is ${typeof u[name]}, was ${type}`);
}
let observed;
try {
  observed = observe(u);
} catch (error) {
  failures.push(`an existing function threw: ${error && error.message}`);
}
if (observed) {
  for (const key of Object.keys(BASE.observed)) {
    try {
      assert.deepStrictEqual(observed[key], BASE.observed[key]);
    } catch (error) {
      failures.push(`${key} differs from the base: ${String(error.message).split("\n").slice(0, 12).join(" | ")}`);
    }
  }
}
if (failures.length > 0) {
  console.error(`kept behaviour changed (${failures.length}):`);
  for (const failure of failures.slice(0, 20)) console.error(`- ${failure}`);
  process.exit(1);
}
console.log("kept-behaviour check passed");
