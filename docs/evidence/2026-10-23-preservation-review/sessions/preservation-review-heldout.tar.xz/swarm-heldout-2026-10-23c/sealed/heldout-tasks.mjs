/**
 * Fresh block 3 (2026-10-23): three tasks selected by
 * docs/evidence/2026-10-23-preservation-review/fresh-block-selection-rule.md (registered in
 * c494db30b), one per family, in the shape of block 2's module. Task text was written from the
 * base's observed behaviour and the upstream change without naming it. Hidden behaviour checks
 * are read from this sealed directory by absolute path and written into the scoring checkout
 * under acceptance/hidden/ only at scoring.
 *
 * ufo commits only a pnpm lockfile and nanoid (at its base) only a yarn.lock, so its install is `npm install` pinned to the registry as it
 * stood before the block was registered; the frozen lockfile for each launch workspace is under
 * ~/.cache/swarm-study-2026-10-23c/heldout-inputs/<task-id>/. Its npm test runs `pnpm lint`
 * first, and under that resolution prettier already reports src/punycode.ts on the unchanged
 * base, so the project test argv is npm test's vitest step. nanoid's npm test runs jest-ci with a
 * 100% coverage threshold (missed on the unchanged base under Node 24), eslint-ci, size-limit and
 * a networked yarn spelling check, so its project test argv is npx jest.
 */
import { readFileSync } from "node:fs";

const sealed = "/Users/brad/.cache/swarm-heldout-2026-10-23c/sealed";
const hiddenSource = (path) => readFileSync(`${sealed}/${path}`, "utf8");

const pinnedInstall = [
  "npm",
  "install",
  "--ignore-scripts",
  "--no-audit",
  "--no-fund",
  "--before=2026-10-23T00:00:00.000Z",
];

const ufo = {
  repository: "unjs/ufo",
  install: [pinnedInstall],
  build: [],
  projectTest: ["npx", "vitest", "run", "--typecheck"],
  visiblePrefix: "",
};

// nanoid's repository commits a yarn.lock, which npm 11 rewrites during any install; the tracked
// file is restored after the install so a prepared tree carries no change the task did not make.
const nanoid = {
  repository: "ai/nanoid",
  install: [pinnedInstall, ["git", "checkout", "--quiet", "--", "yarn.lock"]],
  build: [],
  projectTest: ["npx", "jest"],
  visiblePrefix: "",
};

const check = (repo, source) => ({
  path: "acceptance/visible/check.mjs",
  command: `${repo.visiblePrefix}node acceptance/visible/check.mjs`,
  source,
});

const hiddenFiles = (directory) => [
  { path: "acceptance/hidden/behaviour-check.mjs", source: hiddenSource(`${directory}/behaviour-check.mjs`) },
  { path: "acceptance/hidden/kept-check.mjs", source: hiddenSource(`${directory}/kept-check.mjs`) },
];
const hiddenArgv = [
  ["node", "acceptance/hidden/behaviour-check.mjs"],
  ["node", "acceptance/hidden/kept-check.mjs"],
];

export const tasks = [
  {
    id: "ufo-feature-filter-query",
    ...ufo,
    workType: "feature",
    baseCommit: "7959de5b49f52e7eb2919a33a9bfe30911e05712",
    upstreamCommit: "3c4b43de1128f2c04c2131db9a7e9fe2c7daf0d5",
    hidden: {
      testFiles: ["test/query.test.ts"],
      argv: ["npx", "vitest", "run", "test/query.test.ts"],
      files: hiddenFiles("ufo-feature"),
      extraArgv: hiddenArgv,
    },
    immutable: [],
    taskText: "ufo (URL utilities, TypeScript under src/, every module re-exported from src/index.ts) can add or overwrite query parameters with withQuery(input, query) and read them with getQuery(input), both in src/utils.ts, but it has no way to drop parameters selectively. Add, beside withQuery, and export from the package entry src/index.ts a function filterQuery(input: string, predicate: (key: string, value: string | string[]) => boolean): string that returns input keeping only the query parameters for which predicate returns true. Its rules: an input that contains no \"?\" is returned exactly as given (filterQuery(\"file:///C:/x\", () => false) is \"file:///C:/x\", not normalized). Otherwise predicate is called once for each key of getQuery(input), in that order, with the decoded key and the value getQuery gives it (a string, or an array of strings for a repeated key, so a repeated key is kept or dropped as a whole), and the URL is rebuilt the way withQuery rebuilds it: filterQuery(input, () => true) equals withQuery(input, {}) for every input that contains \"?\"; protocol, auth, host, path and fragment are kept as withQuery keeps them; the kept parameters are encoded as withQuery encodes them; and the \"?\" is left out when no parameter remains. Examples: filterQuery(\"/foo?bar=1&baz=2\", (key) => key !== \"bar\") is \"/foo?baz=2\"; filterQuery(\"/foo?bar=1\", (key) => key !== \"bar\") is \"/foo\"; filterQuery(\"/foo?a=1&a=2&bar=3#frag\", (key) => key !== \"bar\") is \"/foo?a=1&a=2#frag\"; filterQuery(\"https://example.com/p?q=%20x&bar=1\", (key, value) => value !== \"1\") is \"https://example.com/p?q=+x\". What must not change: every existing export keeps its name and its behaviour for every input, in particular withQuery, getQuery, parseQuery, stringifyQuery, parseURL and stringifyParsedURL return exactly what they return today (for example withQuery(\"/x?bar\", {}) stays \"/x?bar\", withQuery(\"/foo?\", {}) stays \"/foo\" and withQuery(\"/p?x=1&&bar=2&\", {}) stays \"/p?x=1&bar=2\"), and getQuery and parseQuery still return an object that does not inherit from Object.prototype and still ignore __proto__ and constructor keys. The tests are vitest files under test/, with the query utilities in test/query.test.ts. Add regression tests for filterQuery to the project's existing test suite. The project's tests run with npx vitest run --typecheck (npm test runs pnpm lint first; on the unchanged base under this install, prettier already reports src/punycode.ts, so lint is not part of the required test command).",
    visible: check(ufo, "import assert from \"node:assert/strict\";\nimport { createJiti } from \"jiti\";\n\nconst { filterQuery } = await createJiti(import.meta.url).import(\n  \"../../src/index.ts\",\n);\n\nassert.equal(\n  filterQuery(\"/foo?bar=1&baz=2\", (key) => key !== \"bar\"),\n  \"/foo?baz=2\",\n);\nconsole.log(\"visible check passed\");\n"),
  },
  {
    id: "ufo-bugfix-base-prefix-boundary",
    ...ufo,
    workType: "bugfix",
    baseCommit: "5fb179d51384301ffb66b48e213863a27cadd1ff",
    upstreamCommit: "eb29945470c8629309764f026a36e7f477a9a1ff",
    hidden: {
      testFiles: ["test/base.test.ts"],
      argv: ["npx", "vitest", "run", "test/base.test.ts"],
      files: hiddenFiles("ufo-bugfix"),
      extraArgv: hiddenArgv,
    },
    immutable: [],
    taskText: "ufo's withBase(input, base) and withoutBase(input, base) in src/utils.ts (exported from src/index.ts) decide whether input already starts with base by a plain string prefix test, after dropping a trailing slash from base. So a path whose first segment merely begins with the base's text is taken as being under the base: today withoutBase(\"/admin-dashboard\", \"/admin\") returns \"/-dashboard\", withoutBase(\"/administrator\", \"/admin/\") returns \"/istrator\", withBase(\"/admin-dashboard\", \"/admin\") returns \"/admin-dashboard\" unchanged as if the base were already there, and withBase(\"/apix\", \"/api\") returns \"/apix\". Fix both functions so that the base counts as present only when it ends at a boundary of input: input equals the base (without its trailing slash), or the character right after it is \"/\" or \"?\". When it is not present, withBase joins the base in front of input as it does for any other path (withBase(\"/admin-dashboard\", \"/admin\") is \"/admin/admin-dashboard\", withBase(\"/a/bc\", \"/a/b/\") is \"/a/b/a/bc\") and withoutBase returns input unchanged (withoutBase(\"/admin-dashboard\", \"/admin/\") is \"/admin-dashboard\", withoutBase(\"/v10/items\", \"/v1\") is \"/v10/items\"). What must not change: wherever the base does end at such a boundary, or input does not start with the base text at all, both functions return exactly what they return today, including a base followed by a query (withBase(\"/api?x=1\", \"/api\") stays \"/api?x=1\", withoutBase(\"/api?test\", \"/api\") stays \"/?test\"), a base equal to input (withoutBase(\"/base\", \"/base/\") stays \"/\", withBase(\"/a/b\", \"/a/b\") stays \"/a/b\"), nested paths (withoutBase(\"/admin/admin-dashboard\", \"/admin/\") stays \"/admin-dashboard\"), an empty or \"/\" base, an input with a protocol given to withBase, and full URL bases (withoutBase(\"https://x.com/base/p\", \"https://x.com/base\") stays \"/p\"); joinURL, withoutTrailingSlash, hasProtocol, isEmptyURL and every other export are unchanged. The tests are vitest files under test/, with these two functions in test/base.test.ts. Add regression tests for this behaviour to the project's existing test suite. The project's tests run with npx vitest run --typecheck (npm test runs pnpm lint first; on the unchanged base under this install, prettier already reports src/punycode.ts, so lint is not part of the required test command).",
    visible: check(ufo, "import assert from \"node:assert/strict\";\nimport { createJiti } from \"jiti\";\n\nconst { withoutBase } = await createJiti(import.meta.url).import(\n  \"../../src/index.ts\",\n);\n\nassert.equal(withoutBase(\"/admin-dashboard\", \"/admin\"), \"/admin-dashboard\");\nconsole.log(\"visible check passed\");\n"),
  },
  {
    id: "nanoid-refactor-module-subdirectories",
    ...nanoid,
    workType: "refactor",
    baseCommit: "a58703bd9ae5355af23fc871d9b955127334d21f",
    upstreamCommit: "a069b8f22a52a22f78fa03325d9aae2e12219263",
    hidden: {
      // The upstream commit's only test change follows the moved paths, so none is overlaid: the
      // candidate's own suite runs, then the behaviour and kept-behaviour checks.
      testFiles: [],
      argv: ["npx", "jest"],
      files: hiddenFiles("nanoid-refactor"),
      extraArgv: hiddenArgv,
    },
    immutable: [],
    taskText: "nanoid keeps each public module as one file named after it: format.js, random.js, generate.js and url.js at the package root, non-secure/generate.js, and async/format.js, async/generate.js and async/random.js, with browser and React Native builds beside them (format.browser.js, random.browser.js, async/format.browser.js, async/random.browser.js, async/random.rn.js). Move each of these thirteen files into a directory named after its module, as index.js, index.browser.js or index.rn.js, with behaviour unchanged: format.js to format/index.js, format.browser.js to format/index.browser.js, random.js to random/index.js, random.browser.js to random/index.browser.js, generate.js to generate/index.js, url.js to url/index.js, non-secure/generate.js to non-secure/generate/index.js, async/format.js to async/format/index.js, async/format.browser.js to async/format/index.browser.js, async/generate.js to async/generate/index.js, async/random.js to async/random/index.js, async/random.browser.js to async/random/index.browser.js, and async/random.rn.js to async/random/index.rn.js. index.js, index.browser.js, async/index.js, async/index.browser.js and non-secure/index.js stay where they are. Leave nothing at the old paths (no re-exporting stubs), and do not change the moved code apart from the module paths in its require calls. Update every reference to an old path: the relative requires between the modules, the requires in the tests under test/, and in package.json the browser field (which maps each Node file to its browser build), the react-native field (the same for React Native) and the size-limit entries, so that each names the moved files with the same mappings and the same limits. Change nothing else in package.json (scripts, jest, eslintConfig, eslintIgnore and every other field stay exactly as they are) and add no other configuration file. What must not change: require(\"nanoid\") and every subpath (format, random, generate, url, non-secure, non-secure/generate, async, async/format, async/generate, async/random) still resolve, now to the moved modules, and export exactly what they export today; a bundler that applies the browser or react-native field gets the same browser and React Native builds as today; ESLint (npx eslint ., which passes on the base) lints each moved file with the rules its old path got and ignores none of them; and every existing test still runs and passes. The tests are Jest files under test/. The project's tests run with npx jest (npm test also runs jest-ci with a 100% coverage threshold, eslint-ci, size-limit and a yarn spelling check; on the unchanged base under this install the coverage threshold is already missed, so those steps are not part of the required test command).",
    visible: check(nanoid, "import assert from 'node:assert/strict'\nimport { existsSync } from 'node:fs'\nimport { createRequire } from 'node:module'\n\nconst require = createRequire(import.meta.url)\nassert.equal(existsSync(new URL('../../format/index.js', import.meta.url)), true)\nassert.equal(existsSync(new URL('../../format.js', import.meta.url)), false)\nassert.equal(require('../../generate')('abc', 8).length, 8)\nconsole.log('visible check passed')\n"),
  },
];
