// Builds the two sealed checks from the templates, the shared facts and the base's record.
import { readFileSync, writeFileSync } from "node:fs";
const here = new URL("./", import.meta.url);
const read = (name) => readFileSync(new URL(name, here), "utf8");
const facts = read("facts.mjs").replace(/^\/\/.*\n/gm, "").replaceAll("export ", "");
const record = JSON.parse(read("base-facts.json"));
const manifest = JSON.parse(process.argv[4]);
const { browser, "react-native": native, "size-limit": size, ...manifestRest } = manifest;
const base = JSON.stringify({ ...record, manifestRest });
for (const [template, out] of [["behaviour-template.mjs", process.argv[2]], ["kept-template.mjs", process.argv[3]]]) {
  writeFileSync(out, read(template).replace("__BASE__", () => base).replace("__FACTS__", () => facts));
}
