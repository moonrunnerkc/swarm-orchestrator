import assert from 'node:assert/strict'
import { existsSync } from 'node:fs'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
assert.equal(existsSync(new URL('../../format/index.js', import.meta.url)), true)
assert.equal(existsSync(new URL('../../format.js', import.meta.url)), false)
assert.equal(require('../../generate')('abc', 8).length, 8)
console.log('visible check passed')
