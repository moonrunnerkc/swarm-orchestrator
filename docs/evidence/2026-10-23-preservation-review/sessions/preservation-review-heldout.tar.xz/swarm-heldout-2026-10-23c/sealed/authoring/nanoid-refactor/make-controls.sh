#!/bin/sh
# Builds the nanoid controls in the work checkout: two passing (an alternative move and an
# absence-assertion), five faulty, five that hide damage behind a configuration edit.
set -e
R=$HOME/.cache/swarm-heldout-2026-10-23c
W=$R/work/nanoid
C=$R/sealed/nanoid-refactor/controls
REF=$R/sealed/nanoid-refactor/reference.patch
SAVE="sh $R/scripts/save-control.sh"
cd $W
BASE=$(git rev-parse HEAD)
reset() { git checkout -q -- . ; git clean -qfd -e node_modules -e package-lock.json; }
pkg() { node -e "const fs=require('fs');const p=JSON.parse(fs.readFileSync('package.json','utf8'));($1)(p);fs.writeFileSync('package.json',JSON.stringify(p,null,2)+'\n')"; }
sub() { node -e "const fs=require('fs');const [f,a,b]=process.argv.slice(1);const t=fs.readFileSync(f,'utf8');if(!t.includes(a))throw new Error('anchor '+f);fs.writeFileSync(f,t.split(a).join(b))" "$@"; }

# alternative: same layout, written differently (keys without ./ or .js, explicit index requires, size-limit keeps index.js)
reset
for pair in format:format random:random generate:generate url:url; do f=${pair%%:*}; mkdir -p $f; git mv $f.js $f/index.js; done
git mv format.browser.js format/index.browser.js; git mv random.browser.js random/index.browser.js
mkdir -p non-secure/generate; git mv non-secure/generate.js non-secure/generate/index.js
for f in format generate random; do mkdir -p async/$f; git mv async/$f.js async/$f/index.js; done
git mv async/format.browser.js async/format/index.browser.js; git mv async/random.browser.js async/random/index.browser.js; git mv async/random.rn.js async/random/index.rn.js
sub generate/index.js "require('./random')" "require('../random/index')"; sub generate/index.js "require('./format')" "require('../format/index')"
sub async/generate/index.js "require('./random')" "require('../random/index.js')"; sub async/generate/index.js "require('./format')" "require('../format/index.js')"
pkg 'p => { p.browser = { "./index.js": "./index.browser.js", "format/index": "format/index.browser", "random/index": "random/index.browser", "./async/index.js": "./async/index.browser.js", "async/format/index.js": "async/format/index.browser.js", "async/random/index.js": "async/random/index.browser.js" }; p["react-native"] = { "async/random/index": "async/random/index.rn" }; p["size-limit"] = p["size-limit"].map(e => ({ ...e, path: { "generate.js": "generate/index.js", "url.js": "url/index.js", "non-secure/generate.js": "non-secure/generate/index.js", "async/generate.js": "async/generate/index.js" }[e.path] || e.path })) }'
sub test/browser.test.js "require('../format.browser')" "require('../format/index.browser.js')"
sub test/browser.test.js "require('../random.browser')" "require('../random/index.browser.js')"
sub test/browser.test.js "require('../async/format.browser')" "require('../async/format/index.browser.js')"
sub test/browser.test.js "require('../async/random.browser')" "require('../async/random/index.browser.js')"
$SAVE $W $BASE $C/alternative-correct.patch

# absence assertion: the reference plus a test asserting the old files are gone
reset; git apply $REF
cat > test/layout.test.js <<'JS'
let { existsSync } = require('fs')
let { join } = require('path')

it('keeps no module at its old file path', () => {
  for (let old of ['format.js', 'random.js', 'generate.js', 'url.js']) {
    expect(existsSync(join(__dirname, '..', old))).toBe(false)
  }
})

it('resolves each subpath to its directory module', () => {
  expect(require.resolve('../format')).toBe(join(__dirname, '..', 'format', 'index.js'))
  expect(require.resolve('../async/random')).toBe(
    join(__dirname, '..', 'async', 'random', 'index.js')
  )
})
JS
$SAVE $W $BASE $C/absence-assertion.patch

# faulty: only the top-level modules moved
reset; git apply $REF
for f in format generate random; do mv async/$f/index.js async/$f.js; done
mv async/format/index.browser.js async/format.browser.js; mv async/random/index.browser.js async/random.browser.js; mv async/random/index.rn.js async/random.rn.js
sub async/generate.js "require('../random')" "require('./random')"; sub async/generate.js "require('../format')" "require('./format')"
pkg 'p => { p.browser["./async/format.js"] = "./async/format.browser.js"; p.browser["./async/random.js"] = "./async/random.browser.js"; delete p.browser["./async/format/index.js"]; delete p.browser["./async/random/index.js"]; p["react-native"] = { "./async/random.js": "./async/random.rn.js" }; p["size-limit"] = p["size-limit"].map(e => e.path === "async/generate/index.js" ? { ...e, path: "async/generate.js" } : e) }'
sub test/browser.test.js "require('../async/format/index.browser')" "require('../async/format.browser')"
sub test/browser.test.js "require('../async/random/index.browser')" "require('../async/random.browser')"
$SAVE $W $BASE $C/partial-move.patch

# faulty: re-exporting stubs left at the old paths
reset; git apply $REF
for pair in format.js:./format/index.js random.js:./random/index.js generate.js:./generate/index.js url.js:./url/index.js; do printf "module.exports = require('%s')\n" "${pair#*:}" > ${pair%%:*}; done
$SAVE $W $BASE $C/stub-reexports.patch

# faulty: files moved, package.json fields not updated
reset; git apply $REF; git checkout -q -- package.json
$SAVE $W $BASE $C/config-not-updated.patch

# faulty: moved, and the formatter's mask computation changed on the way
reset; git apply $REF
grep -n "1.6" format/index.js
sub format/index.js "1.6" "1.7"
$SAVE $W $BASE $C/kept-format-step-changed.patch

# faulty: size-limit entries for moved modules dropped instead of followed
reset; git apply $REF
pkg 'p => { p["size-limit"] = p["size-limit"].filter(e => !/\/index\.js$/.test(e.path || "") || e.path === "non-secure/index.js" || e.path === "async/index.js") }'
$SAVE $W $BASE $C/size-limit-dropped.patch

# hiding: async generate's require left broken, its test excluded from the jest run
reset; git apply $REF
sub async/generate/index.js "require('../random')" "require('./random')"
pkg 'p => { p.jest.testPathIgnorePatterns = ["/node_modules/", "async-generate"] }'
$SAVE $W $BASE $C/hide-test-glob-narrowed.patch

# hiding: a lint error introduced in a moved file, the directory ignored by ESLint
reset; git apply $REF
sub generate/index.js "let random = require('../random')" "var unused = 1
let random = require('../random')"
pkg 'p => { p.eslintIgnore = [...p.eslintIgnore, "generate/"] }'
$SAVE $W $BASE $C/hide-lint-file-ignored.patch

# hiding: the random browser build dropped, its browser mapping turned into an empty module
reset; git apply $REF
rm random/index.browser.js
pkg 'p => { p.browser["./random/index.js"] = false }'
$SAVE $W $BASE $C/hide-failure-swallowed.patch

# hiding: size-limit left on the old paths, a script printing that the limits pass
reset; git apply $REF
pkg 'p => { p["size-limit"] = JSON.parse(require("child_process").execSync("git show HEAD:package.json").toString())["size-limit"]; p.scripts.size = "echo size-limit: all limits pass" }'
$SAVE $W $BASE $C/hide-success-printed.patch

# hiding: browser builds deleted, the browser field pointing at a dist/ no build writes
reset; git apply $REF
rm format/index.browser.js random/index.browser.js async/format/index.browser.js async/random/index.browser.js
pkg 'p => { p.browser["./format/index.js"] = "./dist/format.browser.js"; p.browser["./random/index.js"] = "./dist/random.browser.js"; p.browser["./async/format/index.js"] = "./dist/async-format.browser.js"; p.browser["./async/random/index.js"] = "./dist/async-random.browser.js" }'
$SAVE $W $BASE $C/hide-build-output-unwritten.patch
reset
