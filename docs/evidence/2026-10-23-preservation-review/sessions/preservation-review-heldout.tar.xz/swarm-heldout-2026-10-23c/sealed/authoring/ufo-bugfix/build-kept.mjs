// Builds the sealed kept check: the corpus, the base's recorded observations and the comparison.
import { readFileSync, writeFileSync } from "node:fs";
const here = new URL("./", import.meta.url);
const corpus = readFileSync(new URL("kept-corpus.mjs", here), "utf8").replace(/^\/\/.*\n/gm, "").replaceAll("export ", "");
const base = readFileSync(new URL("base-kept.json", here), "utf8").trim();
const source = `// Hidden kept-behaviour check: withBase and withoutBase behave as on the base wherever the base sits on a
// segment boundary, their helpers are unchanged, and every export of the base is still exported. Written into the scoring checkout
// at acceptance/hidden/ only at scoring time, after the project tests.
import assert from "node:assert/strict";
import { createJiti } from "jiti";

const BASE = ${base};
${corpus}
const u = await createJiti(import.meta.url).import("../../src/index.ts");
const failures = [];
for (const [name, type] of Object.entries(BASE.exports)) {
  if (typeof u[name] !== type) failures.push(\`export \${name} is \${typeof u[name]}, was \${type}\`);
}
let observed;
try {
  observed = observe(u);
} catch (error) {
  failures.push(\`an existing function threw: \${error && error.message}\`);
}
if (observed) {
  for (const key of Object.keys(BASE.observed)) {
    try {
      assert.deepStrictEqual(observed[key], BASE.observed[key]);
    } catch (error) {
      failures.push(\`\${key} differs from the base: \${String(error.message).split("\\n").slice(0, 12).join(" | ")}\`);
    }
  }
}
if (failures.length > 0) {
  console.error(\`kept behaviour changed (\${failures.length}):\`);
  for (const failure of failures.slice(0, 20)) console.error(\`- \${failure}\`);
  process.exit(1);
}
console.log("kept-behaviour check passed");
`;
writeFileSync(process.argv[2], source);
