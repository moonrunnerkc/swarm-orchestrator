// The kept-behaviour corpus for ufo-bugfix-base-prefix-boundary: base and input pairs where the
// base occupies whole path segments (or is absent, empty, "/" or followed by "?"), plus the
// helpers withBase relies on. Shared by the generator (run on the base) and the sealed check.
export const bases = ["/admin", "/admin/", "/", "", "/a/b", "/a/b/", "/api", "https://x.com/base", "/base/", "/foo"];
export const inputs = [
  "/admin", "/admin/", "/admin/x", "/admin/x/y/", "/admin?q=1", "/admin/?q=1", "/a/b", "/a/b/c",
  "/a/b?x", "/a/b/", "/api", "/api/v1", "/api?test", "/api/?test", "https://x.com/base/p", "https://test.com",
  "", "/", "/x", "/bar", "/base", "/base/a", "x/y", "?q", "/foo/bar", "//cdn.com/x", "/b/admin",
];
export const segmentBoundary = (base, input) => {
  const trimmed = base.endsWith("/") && base.length > 1 ? base.slice(0, -1) : base;
  if (trimmed === "" || trimmed === "/" || !input.startsWith(trimmed)) return true;
  const next = input[trimmed.length];
  return next === undefined || next === "/" || next === "?";
};
export function observe(u) {
  const pairs = [];
  for (const base of bases) for (const input of inputs) if (segmentBoundary(base, input)) pairs.push([base, input]);
  return {
    pairs,
    withBase: pairs.map(([base, input]) => u.withBase(input, base)),
    withoutBase: pairs.map(([base, input]) => u.withoutBase(input, base)),
    joinURL: inputs.map((input) => bases.map((base) => u.joinURL(base, input))),
    withoutTrailingSlash: inputs.map((input) => u.withoutTrailingSlash(input)),
    isEmptyURL: inputs.map((input) => u.isEmptyURL(input)),
    hasProtocol: inputs.map((input) => u.hasProtocol(input)),
  };
}
