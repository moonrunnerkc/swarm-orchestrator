// The kept-behaviour corpus for ufo-feature-filter-query: existing query and URL functions over
// fixed inputs. Shared by the generator (run on the base) and the sealed kept check.
export const inputs = [
  "/foo", "/foo?", "/foo?bar=1", "/foo?bar=1&baz=2", "/foo?a=1&a=2&bar=3#frag",
  "https://user:pw@example.com:8080/p/a?bar=1&q=%20x+y#h", "?bar=1&c=3", "//cdn.example.com/x?bar=1&y",
  "/x?a=%2F&bar", "/foo#h?bar=1", "file:///C:/x?bar=1&k=v", "file:///C:/x", "/x?bar", "/p?x=1&&bar=2&",
  "/p?__proto__=1&bar=2&z=3&constructor=4", "/p?caf%C3%A9=1&bar=2", "http://a.com/b?x=a%26b&bar=&y=%3D",
  "http://example.com", "", "/a b?c d=e f", "/p?a[]=1&a[]=2", "/p?=x&y=",
];
export const queries = [
  {}, { a: null }, { bar: undefined }, { x: [1, "2"] }, { n: 0, b: false, t: true }, { o: { k: 1 } },
  { "": "e" }, { bar: "new", extra: "a b&c" }, { a: [] }, { s: "x/y?z#w" },
];
export const searches = ["", "?", "a=1", "?a=1&a=2&a=3", "a&b=&c=1", "%5Bk%5D=v", "a=1=2", "+x=+y", "__proto__=1&constructor=2&ok=3"];
export const objects = [
  {}, { a: "1" }, { a: ["1", "2"] }, { a: undefined, b: null, c: "" }, { n: 1, f: false }, { "a b": "c d" },
  { o: { x: 1 } }, { arr: [null, undefined, "z"] },
];
export function observe(u) {
  const plain = (value) => JSON.parse(JSON.stringify(value));
  const protoFree = (value) => !("toString" in value) && !("hasOwnProperty" in value);
  return {
    withQuery: inputs.map((input) => queries.map((query) => u.withQuery(input, query))),
    getQuery: inputs.map((input) => {
      const value = u.getQuery(input);
      return { value: plain(value), protoFree: protoFree(value) };
    }),
    parseQuery: searches.map((search) => {
      const value = u.parseQuery(search);
      return { value: plain(value), protoFree: protoFree(value) };
    }),
    stringifyQuery: objects.map((object) => u.stringifyQuery(object)),
    parseURL: inputs.map((input) => plain(u.parseURL(input))),
    roundTrip: inputs.map((input) => u.stringifyParsedURL(u.parseURL(input))),
  };
}
