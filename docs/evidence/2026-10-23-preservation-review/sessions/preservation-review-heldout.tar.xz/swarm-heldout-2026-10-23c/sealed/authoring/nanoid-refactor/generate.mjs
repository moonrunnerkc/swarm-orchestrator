// Run on the base checkout: records the public behaviour, the ESLint configuration and ignore
// state of every moved file at its old path, the normalized sources, the browser, react-native
// and size-limit fields, and the names of every test the base's suite runs.
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync, mkdtempSync } from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { join } from "node:path";
import * as fsModule from "node:fs";
import * as pathModule from "node:path";
import { bundled, moves, normalizeSource, observe } from "./facts.mjs";
const root = process.argv[2];
const out = process.argv[3];
const require = createRequire(join(root, "package.json"));
const behaviour = await observe(
  (subpath) => require(join(root, subpath)),
  (subpath) => require(bundled(fsModule, pathModule, root, subpath, "browser")),
);
const sha = (text) => createHash("sha256").update(text).digest("hex");
const sources = Object.fromEntries(moves.map(([from]) => [from, sha(normalizeSource(readFileSync(join(root, from), "utf8")))]));
const { CLIEngine } = require("eslint");
const engine = new CLIEngine({ cwd: root });
const lint = Object.fromEntries(moves.map(([from]) => [from, { ignored: engine.isPathIgnored(join(root, from)), rules: engine.getConfigForFile(join(root, from)).rules }]));
const manifest = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
const report = join(mkdtempSync(join(tmpdir(), "nanoid-jest-")), "report.json");
try {
  execFileSync("npx", ["jest", "--json", `--outputFile=${report}`], { cwd: root, stdio: "ignore" });
} catch {}
const jest = JSON.parse(readFileSync(report, "utf8"));
const tests = jest.testResults.flatMap((file) => file.assertionResults.filter((one) => one.status === "passed").map((one) => `${file.name.slice(root.length + 1)} :: ${one.fullName}`)).sort();
writeFileSync(out, `${JSON.stringify({ behaviour, sources, lint, browser: manifest.browser, reactNative: manifest["react-native"], sizeLimit: manifest["size-limit"], eslintConfig: manifest.eslintConfig, eslintIgnore: manifest.eslintIgnore, tests })}\n`);
console.log(`recorded ${tests.length} passing tests, ${moves.length} moved modules`);
