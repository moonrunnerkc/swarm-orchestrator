// Hidden kept-behaviour check: every public entry point, loaded through its package subpath (and
// the package's own browser field for the browser builds, as a bundler does), behaves as on the
// base for fixed inputs, and every test the base's suite passed still runs and passes. Written
// into the scoring checkout at acceptance/hidden/ only at scoring time, after the project tests.
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import * as fs from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const BASE = __BASE__;
__FACTS__
const root = fileURLToPath(new URL("../../", import.meta.url)).replace(/\/$/, "");
const require = createRequire(path.join(root, "package.json"));
const failures = [];
try {
  const observed = await observe(
    (subpath) => require(path.join(root, subpath)),
    (subpath) => require(bundled(fs, path, root, subpath, "browser")),
  );
  for (const key of Object.keys(BASE.behaviour)) {
    try {
      assert.deepStrictEqual(observed[key], BASE.behaviour[key]);
    } catch (error) {
      failures.push(`${key} differs from the base: ${String(error.message).split("\n").slice(0, 8).join(" | ")}`);
    }
  }
} catch (error) {
  failures.push(`the public entry points do not load as before: ${error && error.message}`);
}
try {
  const report = path.join(fs.mkdtempSync(path.join(tmpdir(), "nanoid-kept-")), "report.json");
  try {
    execFileSync("npx", ["jest", "--json", `--outputFile=${report}`], { cwd: root, stdio: "ignore" });
  } catch {}
  const jest = JSON.parse(fs.readFileSync(report, "utf8"));
  const passed = new Set(jest.testResults.flatMap((file) => file.assertionResults.filter((one) => one.status === "passed").map((one) => `${path.relative(root, file.name)} :: ${one.fullName}`)));
  const missing = BASE.tests.filter((name) => !passed.has(name));
  if (missing.length > 0) failures.push(`${missing.length} test(s) the base's suite passed no longer run and pass: ${missing.slice(0, 8).join("; ")}`);
} catch (error) {
  failures.push(`the test suite could not be read: ${error && error.message}`);
}
if (failures.length > 0) {
  console.error(`kept behaviour changed (${failures.length}):`);
  for (const failure of failures.slice(0, 20)) console.error(`- ${failure}`);
  process.exit(1);
}
console.log("kept-behaviour check passed");
