// Shared by the generator (run on the base) and the sealed checks of nanoid-refactor-module-subdirectories.
export const moves = [
  ["format.js", "format/index.js"],
  ["format.browser.js", "format/index.browser.js"],
  ["random.js", "random/index.js"],
  ["random.browser.js", "random/index.browser.js"],
  ["generate.js", "generate/index.js"],
  ["url.js", "url/index.js"],
  ["non-secure/generate.js", "non-secure/generate/index.js"],
  ["async/format.js", "async/format/index.js"],
  ["async/format.browser.js", "async/format/index.browser.js"],
  ["async/generate.js", "async/generate/index.js"],
  ["async/random.js", "async/random/index.js"],
  ["async/random.browser.js", "async/random/index.browser.js"],
  ["async/random.rn.js", "async/random/index.rn.js"],
];
export const unmoved = ["index.js", "index.browser.js", "async/index.js", "async/index.browser.js", "non-secure/index.js"];
// Package subpaths users require, and the module each resolves to after the move.
export const subpaths = [
  ["", "index.js"], ["format", "format/index.js"], ["random", "random/index.js"], ["generate", "generate/index.js"],
  ["url", "url/index.js"], ["non-secure", "non-secure/index.js"], ["non-secure/generate", "non-secure/generate/index.js"],
  ["async", "async/index.js"], ["async/format", "async/format/index.js"], ["async/generate", "async/generate/index.js"],
  ["async/random", "async/random/index.js"],
];
// Module source with the specifier of every require() call blanked, so a move that only rewrites
// relative specifiers compares equal.
export const normalizeSource = (text) =>
  text.replace(/\r\n?/g, "\n").replace(/require\(\s*(['"])[^'"]*\1\s*\)/g, "require(<specifier>)");
export const movedPath = (path) => {
  const clean = path.replace(/^\.\//, "");
  const hit = moves.find(([from]) => from === clean);
  return hit ? hit[1] : clean;
};
// Deterministic inputs for the public functions.
export function seededRandom(seed) {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 4294967296;
  };
}
export const byteSource = (seed) => {
  const next = seededRandom(seed);
  return (size) => {
    const bytes = new Uint8Array(size);
    for (let i = 0; i < size; i++) bytes[i] = Math.floor(next() * 256);
    return bytes;
  };
};
export const alphabets = ["0123456789abcdef", "abc", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-", "1234567890", "xy"];
export const sizes = [1, 5, 10, 21, 64];
// A file path inside the package resolved as Node and bundlers resolve a relative module path.
export function resolveFile(fs, path, root, spec) {
  const base = path.resolve(root, spec);
  for (const candidate of [base, `${base}.js`, path.join(base, "index.js")]) {
    if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
  }
  return null;
}
// The file a bundler loads for a package subpath: Node's resolution, then the package's own
// browser (or react-native) field, keyed by the file it replaces.
export function bundled(fs, path, root, subpath, field) {
  const file = resolveFile(fs, path, root, subpath === "" ? "." : `./${subpath}`);
  if (file === null) throw new Error(`subpath ${JSON.stringify(subpath)} does not resolve`);
  const map = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"))[field] ?? {};
  for (const [key, value] of Object.entries(map)) {
    if (resolveFile(fs, path, root, key) === file) {
      if (typeof value !== "string") throw new Error(`${field} maps ${key} to ${JSON.stringify(value)}`);
      const target = resolveFile(fs, path, root, value);
      if (target === null) throw new Error(`${field} maps ${key} to missing ${value}`);
      return target;
    }
  }
  return file;
}
export async function observe(node, browser) {
  const out = {};
  out.url = node("url");
  const format = node("format");
  const formatBrowser = browser("format");
  out.format = [];
  out.formatBrowser = [];
  for (const alphabet of alphabets) for (const size of sizes) {
    out.format.push(format(byteSource(alphabet.length * 31 + size), alphabet, size));
    out.formatBrowser.push(formatBrowser(byteSource(alphabet.length * 17 + size), alphabet, size));
  }
  const asyncFormat = node("async/format");
  const asyncFormatBrowser = browser("async/format");
  out.asyncFormat = [];
  out.asyncFormatBrowser = [];
  for (const alphabet of alphabets) for (const size of sizes) {
    const bytes = byteSource(alphabet.length * 7 + size);
    out.asyncFormat.push(await asyncFormat((n) => Promise.resolve(bytes(n)), alphabet, size));
    const bytes2 = byteSource(alphabet.length * 13 + size);
    out.asyncFormatBrowser.push(await asyncFormatBrowser((n) => Promise.resolve(bytes2(n)), alphabet, size));
  }
  const realRandom = Math.random;
  try {
    Math.random = seededRandom(42);
    const nonSecureGenerate = node("non-secure/generate");
    out.nonSecureGenerate = alphabets.map((alphabet) => nonSecureGenerate(alphabet, 12));
    Math.random = seededRandom(7);
    const nonSecure = node("non-secure");
    out.nonSecure = sizes.map((size) => nonSecure(size));
  } finally {
    Math.random = realRandom;
  }
  out.randomLengths = sizes.map((size) => node("random")(size).length);
  const shape = (alphabet, id) => [id.length, [...id].every((ch) => alphabet.includes(ch))];
  out.generateShapes = alphabets.map((alphabet) => shape(alphabet, node("generate")(alphabet, 30)));
  out.asyncGenerateShapes = [];
  for (const alphabet of alphabets) out.asyncGenerateShapes.push(shape(alphabet, await node("async/generate")(alphabet, 30)));
  out.indexShape = shape(out.url, node("")());
  out.asyncShape = shape(out.url, await node("async")());
  const describe = (value) => (typeof value === "function" ? `function/${value.length}` : typeof value === "string" ? `string/${value.length}` : typeof value);
  out.exports = {};
  for (const subpath of ["", "format", "random", "generate", "url", "non-secure", "non-secure/generate", "async", "async/format", "async/generate", "async/random"]) {
    out.exports[`node:${subpath}`] = describe(node(subpath));
  }
  for (const subpath of ["format", "random", "async/format", "async/random"]) out.exports[`browser:${subpath}`] = describe(browser(subpath));
  return out;
}
