import assert from "node:assert/strict";
import { createJiti } from "jiti";

const { filterQuery } = await createJiti(import.meta.url).import(
  "../../src/index.ts",
);

assert.equal(
  filterQuery("/foo?bar=1&baz=2", (key) => key !== "bar"),
  "/foo?baz=2",
);
console.log("visible check passed");
