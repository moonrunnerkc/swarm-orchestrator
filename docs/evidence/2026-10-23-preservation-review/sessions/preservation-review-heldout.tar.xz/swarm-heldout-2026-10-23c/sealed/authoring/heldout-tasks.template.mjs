/**
 * Fresh block 3 (2026-10-23): three tasks selected by
 * docs/evidence/2026-10-23-preservation-review/fresh-block-selection-rule.md (registered in
 * c494db30b), one per family, in the shape of block 2's module. Task text was written from the
 * base's observed behaviour and the upstream change without naming it. Hidden behaviour checks
 * are read from this sealed directory by absolute path and written into the scoring checkout
 * under acceptance/hidden/ only at scoring.
 *
 * ufo commits only a pnpm lockfile and nanoid (at its base) only a yarn.lock, so its install is `npm install` pinned to the registry as it
 * stood before the block was registered; the frozen lockfile for each launch workspace is under
 * ~/.cache/swarm-study-2026-10-23c/heldout-inputs/<task-id>/. Its npm test runs `pnpm lint`
 * first, and under that resolution prettier already reports src/punycode.ts on the unchanged
 * base, so the project test argv is npm test's vitest step. nanoid's npm test runs jest-ci with a
 * 100% coverage threshold (missed on the unchanged base under Node 24), eslint-ci, size-limit and
 * a networked yarn spelling check, so its project test argv is npx jest.
 */
import { readFileSync } from "node:fs";

const sealed = "/Users/brad/.cache/swarm-heldout-2026-10-23c/sealed";
const hiddenSource = (path) => readFileSync(`${sealed}/${path}`, "utf8");

const pinnedInstall = [
  "npm",
  "install",
  "--ignore-scripts",
  "--no-audit",
  "--no-fund",
  "--before=2026-10-23T00:00:00.000Z",
];

const ufo = {
  repository: "unjs/ufo",
  install: [pinnedInstall],
  build: [],
  projectTest: ["npx", "vitest", "run", "--typecheck"],
  visiblePrefix: "",
};

// nanoid's repository commits a yarn.lock, which npm 11 rewrites during any install; the tracked
// file is restored after the install so a prepared tree carries no change the task did not make.
const nanoid = {
  repository: "ai/nanoid",
  install: [pinnedInstall, ["git", "checkout", "--quiet", "--", "yarn.lock"]],
  build: [],
  projectTest: ["npx", "jest"],
  visiblePrefix: "",
};

const check = (repo, source) => ({
  path: "acceptance/visible/check.mjs",
  command: `${repo.visiblePrefix}node acceptance/visible/check.mjs`,
  source,
});

const hiddenFiles = (directory) => [
  { path: "acceptance/hidden/behaviour-check.mjs", source: hiddenSource(`${directory}/behaviour-check.mjs`) },
  { path: "acceptance/hidden/kept-check.mjs", source: hiddenSource(`${directory}/kept-check.mjs`) },
];
const hiddenArgv = [
  ["node", "acceptance/hidden/behaviour-check.mjs"],
  ["node", "acceptance/hidden/kept-check.mjs"],
];

export const tasks = [
  {
    id: "ufo-feature-filter-query",
    ...ufo,
    workType: "feature",
    baseCommit: "7959de5b49f52e7eb2919a33a9bfe30911e05712",
    upstreamCommit: "3c4b43de1128f2c04c2131db9a7e9fe2c7daf0d5",
    hidden: {
      testFiles: ["test/query.test.ts"],
      argv: ["npx", "vitest", "run", "test/query.test.ts"],
      files: hiddenFiles("ufo-feature"),
      extraArgv: hiddenArgv,
    },
    immutable: [],
    taskText: __TEXT_ufo-feature__,
    visible: check(ufo, __VISIBLE_ufo-feature__),
  },
  {
    id: "ufo-bugfix-base-prefix-boundary",
    ...ufo,
    workType: "bugfix",
    baseCommit: "5fb179d51384301ffb66b48e213863a27cadd1ff",
    upstreamCommit: "eb29945470c8629309764f026a36e7f477a9a1ff",
    hidden: {
      testFiles: ["test/base.test.ts"],
      argv: ["npx", "vitest", "run", "test/base.test.ts"],
      files: hiddenFiles("ufo-bugfix"),
      extraArgv: hiddenArgv,
    },
    immutable: [],
    taskText: __TEXT_ufo-bugfix__,
    visible: check(ufo, __VISIBLE_ufo-bugfix__),
  },
  {
    id: "nanoid-refactor-module-subdirectories",
    ...nanoid,
    workType: "refactor",
    baseCommit: "a58703bd9ae5355af23fc871d9b955127334d21f",
    upstreamCommit: "a069b8f22a52a22f78fa03325d9aae2e12219263",
    hidden: {
      // The upstream commit's only test change follows the moved paths, so none is overlaid: the
      // candidate's own suite runs, then the behaviour and kept-behaviour checks.
      testFiles: [],
      argv: ["npx", "jest"],
      files: hiddenFiles("nanoid-refactor"),
      extraArgv: hiddenArgv,
    },
    immutable: [],
    taskText: __TEXT_nanoid-refactor__,
    visible: check(nanoid, __VISIBLE_nanoid-refactor__),
  },
];
