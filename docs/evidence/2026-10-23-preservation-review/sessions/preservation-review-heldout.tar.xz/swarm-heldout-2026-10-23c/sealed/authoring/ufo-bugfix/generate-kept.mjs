// Run on the base checkout: records the kept behaviour and the base's exports.
import { createRequire } from "node:module";
import { writeFileSync } from "node:fs";
import { observe } from "./kept-corpus.mjs";
const root = process.argv[2] + "/";
const { createJiti } = createRequire(root + "package.json")("jiti");
const u = await createJiti(root).import(root + "src/index.ts");
const exportsOf = Object.fromEntries(Object.keys(u).sort().map((key) => [key, typeof u[key]]));
writeFileSync(process.argv[3], JSON.stringify({ exports: exportsOf, observed: observe(u) }) + "\n");
