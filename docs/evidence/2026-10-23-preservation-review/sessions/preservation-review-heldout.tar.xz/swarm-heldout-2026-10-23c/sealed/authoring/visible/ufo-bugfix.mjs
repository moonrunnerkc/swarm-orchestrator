import assert from "node:assert/strict";
import { createJiti } from "jiti";

const { withoutBase } = await createJiti(import.meta.url).import(
  "../../src/index.ts",
);

assert.equal(withoutBase("/admin-dashboard", "/admin"), "/admin-dashboard");
console.log("visible check passed");
