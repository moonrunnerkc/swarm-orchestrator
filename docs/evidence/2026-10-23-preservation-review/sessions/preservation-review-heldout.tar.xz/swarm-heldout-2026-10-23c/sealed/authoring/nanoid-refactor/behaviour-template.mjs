// Hidden behaviour check: the thirteen modules moved to <name>/index*.js with nothing left at the
// old paths and their code unchanged apart from require specifiers; every package subpath
// resolving to its moved module; the browser, react-native and size-limit fields naming the moved
// files with the same mappings and limits; the rest of package.json as on the base; and ESLint
// applying the same rules to each moved file and ignoring none. Written into the scoring checkout
// at acceptance/hidden/ only at scoring time, after the project tests.
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import * as fs from "node:fs";
import { createRequire } from "node:module";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const BASE = __BASE__;
__FACTS__
const root = fileURLToPath(new URL("../../", import.meta.url)).replace(/\/$/, "");
const require = createRequire(path.join(root, "package.json"));
const sha = (text) => createHash("sha256").update(text).digest("hex");
const failures = [];
const check = (name, fn) => {
  try {
    fn();
  } catch (error) {
    failures.push(`${name}: ${String(error && error.message).split("\n").slice(0, 6).join(" | ")}`);
  }
};
const manifest = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));

for (const [from, to] of moves) {
  check(`${from} -> ${to}`, () => {
    assert.ok(!fs.existsSync(path.join(root, from)), `${from} still exists`);
    assert.ok(fs.existsSync(path.join(root, to)), `${to} is missing`);
    assert.equal(sha(normalizeSource(fs.readFileSync(path.join(root, to), "utf8"))), BASE.sources[from], `${to} differs from ${from} beyond its require specifiers`);
  });
}
for (const file of unmoved) check(`${file} stays`, () => assert.ok(fs.existsSync(path.join(root, file)), `${file} is missing`));
for (const [subpath, file] of subpaths) {
  check(`require("nanoid${subpath ? `/${subpath}` : ""}") resolves to ${file}`, () => {
    assert.equal(require.resolve(path.join(root, subpath)), path.join(root, file));
  });
}
// Every require between the package's modules resolves to an existing module file.
check("relative requires resolve", () => {
  const broken = [];
  for (const file of [...moves.map(([, to]) => to), ...unmoved]) {
    const full = path.join(root, file);
    if (!fs.existsSync(full)) continue;
    for (const match of fs.readFileSync(full, "utf8").matchAll(/require\(\s*(['"])(\.[^'"]*)\1\s*\)/g)) {
      if (resolveFile(fs, path, path.dirname(full), match[2]) === null) broken.push(`${file} -> ${match[2]}`);
    }
  }
  assert.deepEqual(broken, []);
});

const mapOf = (field, value) => {
  const out = {};
  for (const [key, target] of Object.entries(value ?? {})) {
    const from = resolveFile(fs, path, root, key);
    if (from === null) throw new Error(`${field} key ${key} names no file`);
    if (typeof target !== "string") throw new Error(`${field} maps ${key} to ${JSON.stringify(target)}`);
    const to = resolveFile(fs, path, root, target);
    if (to === null) throw new Error(`${field} maps ${key} to missing ${target}`);
    out[path.relative(root, from)] = path.relative(root, to);
  }
  return out;
};
for (const [field, base] of [["browser", BASE.browser], ["react-native", BASE.reactNative]]) {
  check(`package.json ${field} follows the move`, () => {
    const expected = Object.fromEntries(Object.entries(base).map(([key, value]) => [movedPath(key), movedPath(value)]));
    assert.deepEqual(mapOf(field, manifest[field]), expected);
  });
}
check("package.json size-limit follows the move", () => {
  const entry = (one, follow) => {
    const { path: file, ...rest } = one;
    const named = file ?? "index.js";
    const resolved = resolveFile(fs, path, root, follow ? movedPath(named) : named);
    if (resolved === null) throw new Error(`size-limit names missing ${named}`);
    return JSON.stringify([path.relative(root, resolved), rest]);
  };
  assert.ok(Array.isArray(manifest["size-limit"]), "size-limit is not a list");
  assert.deepEqual(manifest["size-limit"].map((one) => entry(one, false)).sort(), BASE.sizeLimit.map((one) => entry(one, true)).sort());
});
check("the rest of package.json is as on the base", () => {
  const strip = (object) => {
    const { browser, "react-native": native, "size-limit": size, ...rest } = object;
    return rest;
  };
  assert.deepEqual(strip(manifest), BASE.manifestRest);
});
check("ESLint lints every moved file with the rules its old path had", () => {
  const { CLIEngine } = require("eslint");
  const engine = new CLIEngine({ cwd: root });
  const problems = [];
  for (const [from, to] of moves) {
    const full = path.join(root, to);
    if (!fs.existsSync(full)) continue;
    if (engine.isPathIgnored(full)) problems.push(`${to} is ignored`);
    try {
      assert.deepEqual(engine.getConfigForFile(full).rules, BASE.lint[from].rules);
    } catch {
      problems.push(`${to} gets different rules from ${from}`);
    }
  }
  const files = moves.map(([, to]) => path.join(root, to)).filter((file) => fs.existsSync(file));
  const report = engine.executeOnFiles(files);
  if (report.errorCount > 0) problems.push(`${report.errorCount} ESLint error(s) in the moved files`);
  assert.deepEqual(problems, []);
});

if (failures.length > 0) {
  console.error(`${failures.length} behaviour check(s) failed:`);
  for (const failure of failures.slice(0, 40)) console.error(`- ${failure}`);
  process.exit(1);
}
console.log("behaviour check passed");
