/**
 * Builds block 3's sealed registry (repository order, exposure checks, every candidate considered
 * with its decision and reason, and for the accepted tasks the validation results and digests)
 * and the public summary (identity, install and test argv, task text, visible check,
 * deliverables, lockfile digest, digests and validation counts only).
 *   node build-registry.mjs
 */
import { createHash } from "node:crypto";
import { readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const root = "/Users/brad/.cache/swarm-heldout-2026-10-23c";
const sealed = join(root, "sealed");
const inputs = "/Users/brad/.cache/swarm-study-2026-10-23c/heldout-inputs";
const { tasks } = await import(join(sealed, "heldout-tasks.mjs"));
const { deliverableLines } = await import("/Users/brad/projects/swarm-review-2026-10-23/scripts/comparison/arms.mjs");
const sha256 = (bytes) => `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
const json = (path) => JSON.parse(readFileSync(path, "utf8"));

const meta = {
  "ufo-feature-filter-query": { directory: "ufo-feature", family: 1, familyName: "bounded API change with preservation" },
  "ufo-bugfix-base-prefix-boundary": { directory: "ufo-bugfix", family: 2, familyName: "bug fix with preservation" },
  "nanoid-refactor-module-subdirectories": { directory: "nanoid-refactor", family: 3, familyName: "mechanical transformation that reaches configuration" },
};
const order = json(join(root, "scan/repository-order.json"));
const considered = json(join(root, "scan/considered.json"));
const commitExposure = json(join(root, "scan/commit-exposure.json"));
const exposureOf = (sha) => commitExposure.rows.find((row) => row.changeCommit === sha)?.matches ?? null;

const touched = (patchText) => {
  const paths = [...patchText.matchAll(/^diff --git a\/(.+?) b\/(.+)$/gm)].map((match) => match[2]);
  const authored = paths.filter((path) => !/^(docs?|\.github)\//.test(path) && !/\.md$/i.test(path) && !/(^|\/)(CHANGELOG|CHANGES|readme|license)/i.test(path) && !/(package-lock\.json|yarn\.lock|pnpm-lock\.yaml)$/.test(path));
  const tests = authored.filter((path) => /(^|\/)(test|tests|spec)\//.test(path) || /\.(test|spec)\.[cm]?[jt]sx?$/.test(path));
  return { paths: paths.length, authored: authored.length, nonTestSource: authored.length - tests.length };
};

const accepted = [];
const rows = considered.map((candidate) => {
  const task = tasks.find((one) => one.upstreamCommit === candidate.changeCommit);
  const base = { ...candidate, exposureMatches: exposureOf(candidate.changeCommit) };
  if (task === undefined) return base;
  const { directory } = meta[task.id];
  const validation = json(join(sealed, "validation", `${task.id}.json`));
  const reference = readFileSync(join(sealed, directory, "reference.patch"), "utf8");
  const controlDirectory = join(sealed, directory, "controls");
  const row = {
    ...base,
    id: task.id,
    workType: task.workType,
    referenceDigest: sha256(reference),
    referenceMatchesUpstreamDiff: validation.sealedReferenceMatches,
    filesTouched: touched(reference),
    timings: validation.timings,
    lint: validation.lint,
    referenceLint: { applicable: validation.reference.static.applicable, baseExit: validation.reference.static.baseExit, deliveredExit: validation.reference.static.deliveredExit, introducedFailure: validation.reference.static.introducedFailure },
    base_: { visible: validation.base.visible.passed, hidden: validation.base.hidden.verdict, hiddenBasis: validation.base.hidden.basis, executed: validation.base.executed, kept: validation.base.kept?.verdict ?? null, keptBasis: validation.base.kept?.basis ?? null },
    reference_: { visible: validation.reference.visible.passed, projectTestExit: validation.reference.visible.projectTestExit, hidden: validation.reference.hidden.verdict, hiddenBasis: validation.reference.hidden.basis, policy: validation.reference.hidden.policy },
    valid: validation.valid,
    controls: validation.controls.map((control) => ({
      name: control.name,
      kind: control.kind,
      digest: control.digest,
      digestMatchesFile: sha256(readFileSync(join(controlDirectory, control.name))) === control.digest,
      expected: control.expected,
      hidden: control.hidden.verdict,
      hiddenBasis: control.hidden.basis,
      policyOk: control.hidden.policy?.ok ?? null,
      visible: control.visible.passed,
      asExpected: control.hidden.verdict === control.expected,
    })),
    controlFilesOnDisk: readdirSync(controlDirectory).filter((name) => name.endsWith(".patch")).sort(),
    hiddenFiles: (task.hidden.files ?? []).map((file) => {
      const sealedSource = join(sealed, directory, file.path.split("/").pop());
      return { path: file.path, sealedSource, digest: sha256(file.source), matchesSealedFile: sha256(readFileSync(sealedSource)) === sha256(file.source) };
    }),
    overlaidUpstreamTestFiles: task.hidden.testFiles,
  };
  accepted.push(row);
  return row;
});

const lockfiles = Object.fromEntries(tasks.map((task) => [task.id, { name: `${task.id}/package-lock.json`, digest: sha256(readFileSync(join(inputs, task.id, "package-lock.json"))) }]));
const registry = {
  schema: "swarm-heldout-2026-10-23c.registry.v1",
  builtAt: new Date().toISOString(),
  rule: "docs/evidence/2026-10-23-preservation-review/fresh-block-selection-rule.md (registered in c494db30b), with block 2's conditions (docs/evidence/2026-10-23-controller/heldout-2-selection-rule.md) and block 1's (docs/evidence/2026-10-22-adaptive/heldout-selection-rule.md)",
  repositoryOrder: { ...order, digest: sha256(readFileSync(join(root, "scan/repository-order.json"))) },
  heads: {
    "unjs/ufo": "f06c800d0c59f2a4a1b9ba65eb6cb61a84419be6",
    "postcss/postcss": "d1908579d6af4155ee5f759030184fb4c2b575ec",
    "jprichardson/node-fs-extra": "1e223d3b1e26b7ebef7f402acf0e3b5533cc5833",
    "micromatch/picomatch": "9fab7bf61913ea334c4203ed321c426cfde44a42",
    "ljharb/qs": "234d5051f5071efaa025a7ca9e4d34a56a460a1b",
    "Rich-Harris/magic-string": "993d27d8aee16d2ca46646a5c3c0b290c8084323",
    "unjs/pathe": "bc7477a01f0bd60ada017add8142c9f9d69ccdc5",
    "unjs/defu": "82632b66f5914e9946edce300e10633a3d5c0cb7",
    "ai/nanoid": "35ea7d02c9f01d7f3d2293cc97829ff16d1e8117",
  },
  spanGuard: "Families 1 and 2 were both taken from unjs/ufo, so ufo's family-3 pool was refused as a whole (the block must span two repositories); its family-3 candidates were not read.",
  notReached: "Family 1 and 2: every repository after unjs/ufo. Family 3: every repository after ai/nanoid, and nanoid's candidates older than a069b8f22.",
  repositoryExposure: json(join(root, "scan/repo-exposure.json")).repositories.map(({ repository, matchCount, matches }) => ({ repository, matchCount, matches })),
  commitExposure: { commit: commitExposure.commit, scannedTrackedFiles: commitExposure.scannedTrackedFiles, expandedArchives: commitExposure.expandedArchives, matched: commitExposure.rows.filter((row) => row.matches.length > 0).map((row) => ({ changeCommit: row.changeCommit, matches: row.matches })) },
  interpretations: [
    "ufo's npm test runs pnpm lint (eslint, then prettier -c src test) before vitest; under the pinned --before resolution prettier reports src/punycode.ts on both unchanged bases, so the project test argv is npm test's own vitest step, npx vitest run --typecheck, and lint is reported, not required (staticVerdict: base exit 1, reference exit 1, nothing introduced).",
    "nanoid's npm test is jest-ci --coverage && eslint-ci . && size-limit && yarn spell; jest's 100% statement threshold is missed at the unchanged base under Node 24 (99.66%), and the spelling step needs yarn and a network service, so the project test argv is npx jest. The project declares no lint script; npx eslint . passes on the base and the hidden check runs ESLint over the moved files itself.",
    "nanoid's base tracks yarn.lock, which npm 11 rewrites on npm install and on npm ci; the task's install restores it with git checkout after the pinned install, so a prepared tree has no change the task did not make.",
    "ufo declares pnpm in packageManager; the comparison's taskEnvironment requires that release provisioned, so pnpm 10.7.1 and 10.28.0 were installed under ~/.cache/swarm-capability-tools/ (pnpm-10.33.2 was also provisioned while checking the rejected 5cd9e6767).",
    "Scorers were read from /Users/brad/projects/swarm-review-2026-10-23: checks.mjs, change-policy.mjs, schema.mjs and validate.mjs are unchanged from c494db30b to 3f3881bd0; workspace.mjs gained, at 028ef2e20 (committed during validation), only an .aider* patch exclusion and a snapshotPatch helper, neither used by visibleVerdict, hiddenVerdict, lintVerdict or staticVerdict for these patches.",
    "Each task's hidden evaluator runs a behaviour check and a separate kept-behaviour check (acceptance/hidden/kept-check.mjs); validation runs the kept-behaviour check alone on the base, where it passes for all three.",
  ],
  lockfiles,
  isolation: "Reference commits live in ~/.cache/swarm-comparison/mirrors (unjs__ufo.git, ai__nanoid.git, and the considered postcss__postcss.git, jprichardson__node-fs-extra.git, micromatch__picomatch.git, ljharb__qs.git, Rich-Harris__magic-string.git, unjs__pathe.git, unjs__defu.git), which launch-config.mjs protectedRootsOf denies to every launch. This sealed directory (~/.cache/swarm-heldout-2026-10-23c) must be added to the block's manifest isolation.protectedRoots before the first launch; the frozen lockfiles are under ~/.cache/swarm-study-2026-10-23c/heldout-inputs.",
  candidates: rows,
};
writeFileSync(join(sealed, "registry.json"), `${JSON.stringify(registry, null, 2)}\n`);

const counts = (row) => {
  const of = (kind) => row.controls.filter((c) => c.kind === kind);
  const faulty = row.controls.filter((c) => c.kind.startsWith("faulty") && c.kind !== "faulty-configuration-hiding");
  const hiding = of("faulty-configuration-hiding");
  return {
    baseFailsVisible: row.base_.visible === false,
    baseFailsHidden: row.base_.hidden === "fail" && row.base_.executed,
    keptBehaviourCheckPassesOnBase: row.base_.kept === "pass",
    referencePassesVisibleAndProjectTests: row.reference_.visible === true && row.reference_.projectTestExit === 0,
    referencePassesHidden: row.reference_.hidden === "pass",
    referencePassesPolicy: row.reference_.policy?.ok === true,
    referenceLint: row.referenceLint.applicable ? (row.referenceLint.introducedFailure ? "introduces a failure" : row.referenceLint.baseExit === 0 ? "passes" : "fails on the base already; nothing introduced") : "no lint script",
    alternativePasses: `${of("alternative").filter((c) => c.asExpected).length}/${of("alternative").length}`,
    absenceAssertionPasses: `${of("absence-assertion").filter((c) => c.asExpected).length}/${of("absence-assertion").length}`,
    faultyControlsFail: `${faulty.filter((c) => c.asExpected).length}/${faulty.length}`,
    faultyThatBreakKeptBehaviourFail: `${of("faulty-breaks-kept-behaviour").filter((c) => c.asExpected).length}/${of("faulty-breaks-kept-behaviour").length}`,
    ...(hiding.length > 0 ? { configurationHidingControlsFail: `${hiding.filter((c) => c.asExpected).length}/${hiding.length}` } : {}),
    valid: row.valid,
  };
};
const familyKey = { 1: "api-change", 2: "bugfix", 3: "mechanical-transformation-reaching-configuration" };
const summary = {
  schema: "swarm-heldout-2026-10-23c.public-summary.v1",
  builtAt: registry.builtAt,
  sealedModuleDigest: sha256(readFileSync(join(sealed, "heldout-tasks.mjs"))),
  registryDigest: sha256(readFileSync(join(sealed, "registry.json"))),
  tasks: tasks.map((task) => {
    const row = accepted.find((one) => one.id === task.id);
    return {
      id: task.id,
      repository: task.repository,
      family: familyKey[meta[task.id].family],
      workType: task.workType,
      baseCommit: row.baseCommit,
      install: task.install,
      projectTest: task.projectTest,
      taskText: task.taskText,
      visibleCheck: { path: task.visible.path, command: task.visible.command, source: task.visible.source },
      deliverables: deliverableLines(task),
      harnessLockfile: lockfiles[task.id],
      hiddenFileDigests: row.hiddenFiles.map((file) => file.digest),
      controlPatchDigests: row.controls.map((control) => control.digest).sort(),
      validation: counts(row),
    };
  }),
};
writeFileSync(join(root, "public-summary.json"), `${JSON.stringify(summary, null, 2)}\n`);
console.log(`${rows.length} candidates recorded; ${summary.tasks.length} tasks in the public summary`);
for (const row of accepted) console.log(row.id, row.valid, row.controls.every((c) => c.asExpected && c.digestMatchesFile), row.hiddenFiles.every((f) => f.matchesSealedFile), JSON.stringify(row.filesTouched), JSON.stringify(counts(row)));
