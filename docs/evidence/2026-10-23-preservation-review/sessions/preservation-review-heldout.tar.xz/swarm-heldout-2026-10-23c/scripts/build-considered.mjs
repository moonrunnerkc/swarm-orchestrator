// Every candidate considered for block 3, in the order considered, with its decision and reason.
import { readFileSync, writeFileSync } from "node:fs";
const root = "/Users/brad/.cache/swarm-heldout-2026-10-23c";
const json = (p) => JSON.parse(readFileSync(`${root}/${p}`, "utf8"));
const rows = [];
const add = (family, repository, c, decision, reason) =>
  rows.push({ family, repository, changeCommit: c.changeCommit, baseCommit: c.baseCommit, date: c.date, subject: c.subject, decision, reason });
const find = (file, prefix) => json(file).candidates.find((c) => c.changeCommit.startsWith(prefix));

// Family 1, unjs/ufo.
add(1, "unjs/ufo", find("scan/history/ufo-1.json", "8515b2439"), "rejected", "documentation only: README and JSDoc comment lines; no option, method or signature changes");
add(1, "unjs/ufo", find("scan/history/ufo-1.json", "3c4b43de1"), "accepted", "first family-1 candidate in order passing every condition; task ufo-feature-filter-query");
// Family 2, unjs/ufo (span guard satisfied: family 3 can still come from a later repository).
add(2, "unjs/ufo", find("scan/history/ufo-2.json", "5cd9e6767"), "rejected", "the base does not install with the rule's command: npm install --ignore-scripts --before=2026-10-23T00:00:00Z fails with ERESOLVE (devDependency typescript ^6.0.3 against unbuild 3.6.1's peerOptional typescript ^5.9.2); the repository commits only pnpm-lock.yaml, and the rule names no other install");
add(2, "unjs/ufo", find("scan/history/ufo-2.json", "eb2994547"), "accepted", "first family-2 candidate in order passing every condition; task ufo-bugfix-base-prefix-boundary");

const specific = {
  "89a6b7440": "moves SECURITY.md into docs/, a documentation file; edits no configuration, build or script file",
  "2524fd7ba": "renames documentation files only; edits no configuration, build or script file",
  "b869683ef": "moves the tests while replacing the test runner (gulp/mocha to Jest) and its package.json configuration: it changes how the checks run, which the allowed-change policy rejects for the reference, and is not a behaviour-unchanged transformation of the check suite",
  "4d74d4a4c": "moves HTTP download code out of the repository into a dependency and rewrites the gulpfile; one benchmark script moves but no configuration names it; not a behaviour-unchanged move within the project",
  "a6c575f55": "moves test fixture files; edits no configuration, build or script file",
  "9bb85af7b": "rewrites the raw-property code across CoffeeScript modules (one file renamed with new content); not a mechanical move, and edits no configuration, build or script file",
  "8f79dcd22": "moves and collapses lib/ folders, but the reference edits no configuration, build or script file (nothing in package.json or any script names the moved paths)",
  "32a5daf7b": "an explicitly partial move ('started moving tests inline') of two test files with test.js and .npmignore following; after it the project's own npm test (mocha test --recursive) no longer runs the moved tests, so the reference itself narrows the test run, the shape of the rule's 'test glob narrowed' control",
  "2dcf16f3c": "moves three modules into lib/ with substantial content changes (parse.js and scan.js rewritten), and edits no configuration file although package.json main still names index.js; not mechanical",
  "669218be4": "moves and splits test files and edits vitest.config.ts, a runner configuration file the allowed-change policy protects, so the reference cannot pass the policy",
  "2fbf3b4db": "replaces the test runner with Vitest (new vitest.config.js, package.json test script): changes how the checks run, which the allowed-change policy rejects",
  "f2270ee53": "renames the public touch() method to createFile() (a public API change, not behaviour-unchanged); edits no configuration file",
  "a069b8f22": null,
};
const generic = (c) =>
  c.renames.length === 0
    ? `no file is moved or renamed and no path is renamed, so no configuration, build or script file names a moved path (${c.files} file(s): ${c.configTouched.length > 0 ? "a tooling, dependency or configuration change" : "a code, test or documentation change"})`
    : `moves or renames ${c.renames.length} file(s) under ${[...new Set(c.renames.map((r) => r.split("/")[0]))].join(", ")} but edits no configuration, build or script file naming them`;
const fam3 = [
  ["postcss/postcss", "scan/history/postcss-3-screen.json", null],
  ["jprichardson/node-fs-extra", "scan/history/node-fs-extra-3-screen.json", null],
  ["micromatch/picomatch", "scan/history/picomatch-3-screen.json", null],
  ["ljharb/qs", "scan/history/qs-3-screen.json", null],
  ["Rich-Harris/magic-string", "scan/history/magic-string-3-screen.json", null],
  ["unjs/pathe", "scan/history/pathe-3-screen.json", null],
  ["unjs/defu", "scan/history/defu-3-screen.json", null],
  ["ai/nanoid", "scan/history/nanoid-3-screen.json", "a069b8f22"],
];
const overrides = {
  "f849b3961": "a feature (an option added to move()); the keyword matches the method name",
  "60266e750": "changes every module's export shape to named exports (a module interface change, not behaviour-unchanged) and edits no configuration file naming a moved path",
  "0e22897fd": "a breaking build migration to pure ESM and TypeScript (feat!), not behaviour-unchanged; no file renamed",
  "4c7548a54": "changes the package's exports to ESM named exports (breaking, not behaviour-unchanged); no file renamed",
  "55a21be8a": "a breaking feature (built-in glob matcher); no file renamed",
};
for (const [repository, file, stop] of fam3) {
  for (const c of json(file).candidates) {
    const short = c.changeCommit.slice(0, 9);
    if (stop !== null && short === stop) {
      add(3, repository, c, "accepted", "first family-3 candidate in order passing every condition; task nanoid-refactor-module-subdirectories");
      break;
    }
    add(3, repository, c, "rejected", specific[short] ?? overrides[short] ?? generic(c));
  }
}
writeFileSync(`${root}/scan/considered.json`, `${JSON.stringify(rows, null, 1)}\n`);
const count = (f) => rows.filter((r) => r.family === f).length;
console.log(`${rows.length} considered (family 1: ${count(1)}, family 2: ${count(2)}, family 3: ${count(3)}); accepted ${rows.filter((r) => r.decision === "accepted").length}`);
