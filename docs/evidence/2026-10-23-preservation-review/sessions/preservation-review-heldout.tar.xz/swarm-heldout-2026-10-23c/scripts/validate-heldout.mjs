/**
 * Validates one block-3 held-out task with the comparison's own scorers and no model: the base
 * fails the visible check and (executed, not short-circuited) the hidden evaluator; the hidden
 * check of the kept behaviour passes on the base on its own; the upstream reference passes the
 * visible check, the project tests, the hidden evaluator, the allowed-change policy and (where
 * the base passes lint) the project's lint; every control patch is scored by the same hidden
 * evaluator (and the visible check). Wall times of the base's install and project tests come
 * from the scorer's own command log.
 *
 *   node validate-heldout.mjs <task-id> <sealed-subdirectory> [--controls-only]
 *
 * Results go to sealed/validation/<task-id>.json and one line of sealed/validation-log.jsonl.
 * Adapted from block 2's script: the scorers are read from the review worktree at the rule's
 * registration commit (read-only), the reference's lint is read with staticVerdict, the kept
 * behaviour check runs alone on the base, and control kinds include configuration-hiding.
 */
import { createHash } from "node:crypto";
import { appendFileSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const repo = "/Users/brad/projects/swarm-review-2026-10-23/scripts";
const { commandLog } = await import(`${repo}/campaign/exec.mjs`);
const { hiddenVerdict, lintVerdict, staticVerdict, visibleVerdict } = await import(`${repo}/comparison/checks.mjs`);
const { referencePatch } = await import(`${repo}/comparison/validate.mjs`);
const { taskSchema } = await import(`${repo}/comparison/schema.mjs`);
const { ensureMirror, resolveFull } = await import(`${repo}/comparison/workspace.mjs`);

const root = "/Users/brad/.cache/swarm-heldout-2026-10-23c";
const sealed = join(root, "sealed");
const { tasks } = await import(join(sealed, "heldout-tasks.mjs"));

const [id, directory] = process.argv.slice(2);
const task = tasks.find((one) => one.id === id);
if (task === undefined) throw new Error(`no task ${id}`);
taskSchema.parse(task);
const only = process.argv.includes("--controls-only");
const onlyControl = process.argv.find((word) => word.startsWith("--control="))?.slice(10);

const sha256 = (bytes) => `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
const log = commandLog(join(sealed, "blobs"));
const started = Date.now();
const stamp = () => `${Math.round((Date.now() - started) / 1000)}s`;
const say = (line) => console.log(`[${stamp()}] ${line}`);

await ensureMirror(log, task);
const { base, upstream } = await resolveFull(log, task);
const reference = await referencePatch(log, task, base, upstream);
const sealedReference = readFileSync(join(sealed, directory, "reference.patch"), "utf8");
const row = {
  task: task.id,
  repository: task.repository,
  workType: task.workType,
  baseCommit: base,
  upstreamCommit: upstream,
  validatedAt: new Date().toISOString(),
  referenceDigest: sha256(reference),
  sealedReferenceMatches: sha256(reference) === sha256(sealedReference),
};

const summarizeVisible = (verdict) => ({
  passed: verdict.passed,
  checkExit: verdict.checkExit,
  projectTestExit: verdict.projectTestExit,
  detail: verdict.detail.slice(-3000),
});
const summarizeHidden = (verdict) => ({
  verdict: verdict.verdict,
  basis: verdict.basis,
  policy: verdict.policy ?? null,
  displaced: verdict.displaced ?? [],
  detail: (verdict.detail ?? "").slice(-3000),
});

// The kept-behaviour check alone, over the base: the same sealed file the evaluator runs, as the
// only hidden step (no overlay, a no-op argv, then the project tests as the evaluator runs them).
const keptFile = (task.hidden.files ?? []).find((file) => file.path.endsWith("kept-check.mjs"));
const keptTask = keptFile && {
  ...task,
  hidden: { testFiles: [], argv: ["node", "-e", "0"], files: [keptFile], extraArgv: [["node", keptFile.path]] },
};

if (!only) {
  const mark = log.commands.length;
  const baseVisible = await visibleVerdict(log, task, base, "");
  say(`base visible passed=${baseVisible.passed}`);
  const baseRun = log.commands.slice(mark);
  const installMs = baseRun
    .filter((command) => task.install.some((argv) => argv.join(" ") === command.argv.join(" ")))
    .reduce((sum, command) => sum + command.wallMs, 0);
  const projectTest = baseRun.find((command) => command.argv.join(" ") === task.projectTest.join(" "));
  row.timings = {
    baseInstallMs: installMs,
    baseProjectTestMs: projectTest?.wallMs ?? null,
    baseProjectTestExit: projectTest?.exitCode ?? null,
  };
  const baseHidden = await hiddenVerdict(log, task, base, upstream, "", { executeEmpty: true });
  say(`base hidden ${baseHidden.verdict}: ${baseHidden.basis}`);
  const baseKept = keptTask ? await hiddenVerdict(log, keptTask, base, upstream, "", { executeEmpty: true }) : null;
  say(`base kept-behaviour check ${baseKept?.verdict ?? "absent"}: ${baseKept?.basis ?? ""}`);
  const referenceVisible = await visibleVerdict(log, task, base, reference);
  say(`reference visible passed=${referenceVisible.passed} projectTestExit=${referenceVisible.projectTestExit}`);
  const referenceHidden = await hiddenVerdict(log, task, base, upstream, reference);
  say(`reference hidden ${referenceHidden.verdict}: ${referenceHidden.basis}`);
  const lint = await lintVerdict(log, task, base);
  say(`visible-check lint ok=${lint.ok} applicable=${lint.applicable}: ${lint.detail.split("\n")[0]}`);
  const referenceStatic = await staticVerdict(log, task, base, reference);
  say(`reference lint applicable=${referenceStatic.applicable} baseExit=${referenceStatic.baseExit} deliveredExit=${referenceStatic.deliveredExit}`);
  row.base = {
    visible: summarizeVisible(baseVisible),
    hidden: summarizeHidden(baseHidden),
    executed: !baseHidden.basis.startsWith("the final tree is the base"),
    kept: baseKept && summarizeHidden(baseKept),
  };
  row.reference = {
    visible: summarizeVisible(referenceVisible),
    hidden: summarizeHidden(referenceHidden),
    static: { ...referenceStatic, detail: referenceStatic.detail.slice(-2000) },
  };
  row.lint = lint;
}

// Control kinds by file name: an alternative correct implementation and an absence-assertion
// control must pass; every other control (faulty, and for a transformation the
// configuration-hiding ones, named hide-*) must fail.
const controlKind = (name) =>
  name.startsWith("alternative")
    ? "alternative"
    : name.startsWith("absence")
      ? "absence-assertion"
      : name.startsWith("hide-")
        ? "faulty-configuration-hiding"
        : name.startsWith("kept-")
          ? "faulty-breaks-kept-behaviour"
          : "faulty";
row.controls = [];
const controlDirectory = join(sealed, directory, "controls");
for (const name of readdirSync(controlDirectory).filter((file) => file.endsWith(".patch")).sort()) {
  if (onlyControl !== undefined && name !== onlyControl) continue;
  const patch = readFileSync(join(controlDirectory, name), "utf8");
  const kind = controlKind(name);
  const hidden = await hiddenVerdict(log, task, base, upstream, patch);
  say(`control ${name} hidden ${hidden.verdict}: ${hidden.basis}`);
  const visible = await visibleVerdict(log, task, base, patch);
  say(`control ${name} visible passed=${visible.passed}`);
  row.controls.push({
    name,
    digest: sha256(patch),
    kind,
    expected: kind.startsWith("faulty") ? "fail" : "pass",
    hidden: summarizeHidden(hidden),
    visible: summarizeVisible(visible),
  });
}

row.valid = only
  ? null
  : row.base.visible.passed === false &&
    row.base.hidden.verdict === "fail" &&
    row.base.executed &&
    (keptTask === undefined || row.base.kept?.verdict === "pass") &&
    row.reference.visible.passed === true &&
    row.reference.hidden.verdict === "pass" &&
    row.reference.hidden.policy?.ok === true &&
    row.lint.ok &&
    !row.reference.static.introducedFailure;
row.controlsAsExpected = row.controls.every((control) => control.hidden.verdict === control.expected);
row.wallMs = Date.now() - started;
row.commands = log.commands.map(({ argv, cwd, exitCode, signal, wallMs, stdoutDigest, stderrDigest }) => ({
  argv, cwd, exitCode, signal, wallMs, stdoutDigest, stderrDigest,
}));

mkdirSync(join(sealed, "validation"), { recursive: true });
const suffix = only ? (onlyControl ? `.control-${onlyControl}` : ".controls") : "";
const out = join(sealed, "validation", `${task.id}${suffix}.json`);
writeFileSync(out, `${JSON.stringify(row, null, 2)}\n`);
appendFileSync(
  join(sealed, "validation-log.jsonl"),
  `${JSON.stringify({
    task: task.id,
    at: row.validatedAt,
    valid: row.valid,
    controlsAsExpected: row.controlsAsExpected,
    referenceDigest: row.referenceDigest,
    sealedReferenceMatches: row.sealedReferenceMatches,
    hiddenFileDigests: (task.hidden.files ?? []).map((file) => sha256(file.source)),
    base: row.base && { visible: row.base.visible.passed, hidden: row.base.hidden.verdict, basis: row.base.hidden.basis, executed: row.base.executed, kept: row.base.kept?.verdict ?? null },
    reference: row.reference && {
      visible: row.reference.visible.passed,
      projectTestExit: row.reference.visible.projectTestExit,
      hidden: row.reference.hidden.verdict,
      policy: row.reference.hidden.policy?.ok ?? null,
      lint: { applicable: row.reference.static.applicable, baseExit: row.reference.static.baseExit, deliveredExit: row.reference.static.deliveredExit },
    },
    lint: row.lint && { ok: row.lint.ok, applicable: row.lint.applicable, detail: row.lint.detail.split("\n")[0] },
    timings: row.timings,
    controls: row.controls.map((control) => ({
      name: control.name, kind: control.kind, digest: control.digest, expected: control.expected,
      hidden: control.hidden.verdict, basis: control.hidden.basis, visible: control.visible.passed,
    })),
    wallMs: row.wallMs,
  })}\n`,
);
say(`valid=${row.valid} controlsAsExpected=${row.controlsAsExpected} -> ${out}`);
