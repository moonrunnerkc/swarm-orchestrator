#!/bin/sh
# Saves the working tree's change against a base as a control patch, new files included.
# A package-lock.json the base does not track (the harness's frozen one) is never part of it.
#   save-control.sh <checkout> <base> <out.patch>
set -e
cd "$1"
extra=""
git cat-file -e "$2:package-lock.json" 2>/dev/null || extra=":(exclude)package-lock.json"
git add -A
git diff --cached --binary "$2" -- . ':(exclude)node_modules' ':(exclude)acceptance' $extra > "$3"
git reset -q
echo "$(wc -c < "$3") bytes -> $3"
