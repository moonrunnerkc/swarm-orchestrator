// Builds sealed/heldout-tasks.mjs from the template, inlining each task text
// (authoring/text/<name>.txt, one paragraph) and visible check (authoring/visible/<name>.mjs).
import { readFileSync, writeFileSync } from "node:fs";
const authoring = "/Users/brad/.cache/swarm-heldout-2026-10-23c/sealed/authoring";
let source = readFileSync(`${authoring}/heldout-tasks.template.mjs`, "utf8");
source = source.replace(/__TEXT_([a-z0-9-]+)__/g, (_, name) => JSON.stringify(readFileSync(`${authoring}/text/${name}.txt`, "utf8").trim()));
source = source.replace(/__VISIBLE_([a-z0-9-]+)__/g, (_, name) => JSON.stringify(readFileSync(`${authoring}/visible/${name}.mjs`, "utf8")));
writeFileSync("/Users/brad/.cache/swarm-heldout-2026-10-23c/sealed/heldout-tasks.mjs", source);
console.log("built");
