// Family-3 screen for one repository: every first-parent commit whose subject has a family-3
// keyword, with its renames (R/C status), files touched and configuration/build/script files
// touched. A keyword match is necessary, not sufficient; the decision is recorded separately.
//   node screen3.mjs <owner/name> <head> <out.json>
import { execFileSync } from "node:child_process";
import { writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
const pattern = /\b(rename|renames|renamed|renaming|move|moves|moved|moving|refactor\w*|migrat\w*)\b/i;
const [repository, head, out] = process.argv.slice(2);
const mirror = join(homedir(), ".cache/swarm-comparison/mirrors", `${repository.replace("/", "__")}.git`);
const git = (...args) => execFileSync("git", ["--git-dir", mirror, ...args], { encoding: "utf8", maxBuffer: 256 << 20 });
const config = /(^|\/)(package\.json|tsconfig[^/]*\.json|jsconfig\.json|[^/]*\.config\.[cm]?[jt]s|\.eslintrc[^/]*|eslint\.config\.[cm]?js|\.prettierignore|\.eslintignore|\.npmignore|biome\.jsonc?|rollup[^/]*|webpack[^/]*|babel\.config[^/]*|\.babelrc|Makefile|build\.config\.[jt]s|[^/]*\.(sh)|scripts\/[^/]+)$/;
const rows = [];
for (const line of git("log", "--first-parent", "--format=%ct%x09%H%x09%P%x09%s", head).trim().split("\n")) {
  const [time, sha, parents, ...subject] = line.split("\t");
  const text = subject.join("\t");
  if (!pattern.test(text)) continue;
  const parent = parents.split(" ")[0];
  if (!parent) continue;
  const status = git("diff", "--name-status", "-M", parent, sha).trim().split("\n").filter(Boolean).map((r) => r.split("\t"));
  const renames = status.filter((r) => /^[RC]/.test(r[0])).map((r) => `${r[1]} -> ${r[2]}`);
  const paths = status.map((r) => r[r.length - 1]);
  rows.push({ changeCommit: sha, baseCommit: parent, date: new Date(Number(time) * 1000).toISOString(), subject: text, files: paths.length, renames, configTouched: paths.filter((p) => config.test(p)), paths: paths.slice(0, 40) });
}
writeFileSync(out, `${JSON.stringify({ repository, head, candidates: rows }, null, 1)}\n`);
for (const r of rows) console.log(`${r.changeCommit.slice(0, 9)} ${r.date.slice(0, 10)} f=${r.files} R=${r.renames.length} cfg=${r.configTouched.length} ${r.subject.slice(0, 80)}`);
